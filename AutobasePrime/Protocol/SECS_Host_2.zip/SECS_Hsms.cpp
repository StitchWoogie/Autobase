#include "stdafx.h"
#include "SECS_HostDef.h"


void makeAndSendSecsHsmsControl(LOCAL_PORT_STRUCT *pt, BYTE code)
{
	int			buf_pos = 0;
	BYTE		data[20];

	buf_pos = setDwordvalToBuf(data, 0, 10);// size field
	data[buf_pos++] = 0xFF;
	data[buf_pos++] = 0xFF;
	data[buf_pos++] = 0x00;
	data[buf_pos++] = 0x00;
	data[buf_pos++] = 0x00;// 
	data[buf_pos++] = code;// S type
	buf_pos = setDwordvalToBuf(data, buf_pos, localVars->dTns);
	PlcDeviceWriteContinue(&pt->device, (char*)data, buf_pos);
	setInitRecvStatus(pt);
	DisplaySendCodeNextLine(pt->no);
}

int makeSecsHeaderHsms(LOCAL_PORT_STRUCT *pt, BYTE *data, WORD station, bool bReadRequest)// add 2016-12-08, bool bReadRequest
{
	int			buf_pos = 4;
	
	buf_pos = makeSecsHeaderEquipAndStation(pt, data, station, buf_pos);
	data[buf_pos++] = 0x00;// 
	data[buf_pos++] = 0x00;// S type	
	if(bReadRequest) {										// add 2016-12-08
		if(localVars->bSaveHeaderData) localVars->dTns++;	// add 2016-12-05
	}
	return setDwordvalToBuf(data, buf_pos, localVars->dTns);
}

void makeDataReadBufHsms(LOCAL_PORT_STRUCT *pt, WORD station, char *device, bool bReadRequest)// add 2016-12-08, bool bReadRequest
{
	int			buf_pos = 0;	
	
	getStreamFunctionData(device, localVars->cStream, localVars->cFunction);
	makeSecsHeaderHsms(pt, localVars->saveBuf, station, bReadRequest);// add 2016-12-08, bReadRequest
	localVars->nSendSave = makeSfMemoryDataToBuf(pt, &localVars->saveBuf[HSMS_HEADER_SIZE]);
	buf_pos = HSMS_HEADER_SIZE + localVars->nSendSave;
	setDwordvalToBuf(localVars->saveBuf, 0, buf_pos-4);
	if(buf_pos > MAX_SECS_SAVE_BUF+HSMS_HEADER_SIZE) buf_pos = MAX_SECS_SAVE_BUF+HSMS_HEADER_SIZE;
	if(buf_pos > 0) PlcDeviceWriteContinue(&pt->device, (char*)localVars->saveBuf, buf_pos);
	setInitRecvStatus(pt);
	DisplaySendCodeNextLine(pt->no);
}


bool checkAndSendSecsHsmsControl(LOCAL_PORT_STRUCT *pt)
{
	BYTE		code = HSMS_SELECT_RESPONSE;

	switch(localVars->cRecvHsmsControl) {
		case HSMS_SELECT_REQUEST :  localVars->bHsmsSelect = true; break;
		case HSMS_LINK_TEST_REQUEST : break;
		case HSMS_SELECT_RESPONSE : localVars->bHsmsSelect = true; return false;	
		case HSMS_LINK_TEST_RESPONSE : return false;
		case HSMS_DESELECT_REQUEST : localVars->bHsmsSelect = false; break;
		case HSMS_DESELECT_RESPONSE :
		case HSMS_SEPARATE_REQUEST : localVars->bHsmsSelect = false; return false;
		default : return false;
	}
	switch(localVars->cRecvHsmsControl) {
		case HSMS_SELECT_REQUEST : code = HSMS_SELECT_RESPONSE; break;		
		case HSMS_LINK_TEST_REQUEST : code = HSMS_LINK_TEST_RESPONSE; break;
		case HSMS_DESELECT_REQUEST : code = HSMS_DESELECT_RESPONSE; break;
		default : return false;
	}
	makeAndSendSecsHsmsControl(pt, code);
	return true;
}

bool checkAndGetTcpIpConnectionTime(LOCAL_PORT_STRUCT *pt)
{
	BYTE buf[100];
	int retn = PlcDeviceGetInfo(&pt->device, DEVICE_INFO_TCPIP_CONNECT_TIME, buf, 100);
	if(retn < 9) return false;
	localVars->sHsmsConnTime.year = (WORD)buf[1] * 0x100L + (WORD)buf[0];
	//int		year = localVars->sHsmsConnTime.year;
	localVars->sHsmsConnTime.month = buf[2];
	localVars->sHsmsConnTime.day = buf[3];
	localVars->sHsmsConnTime.hour = buf[4];
	localVars->sHsmsConnTime.minute = buf[5];
	localVars->sHsmsConnTime.second = buf[6];
	localVars->sHsmsConnTime.milliSecond = (WORD)buf[8] * 0x100L + (WORD)buf[7];
	//year = localVars->sHsmsConnTime.milliSecond;
	return true;
}

bool checkTcpIpConnectionTimeChanged(LOCAL_PORT_STRUCT *pt)
{
	if(localVars->bHsmsTcpConnectionFlag == false) return false;

	HSMS_CONNECTION_TIME	oldTime = localVars->sHsmsConnTime;
	checkAndGetTcpIpConnectionTime(pt);
	if(localVars->sHsmsConnTime.year != oldTime.year) return true;
	if(localVars->sHsmsConnTime.month != oldTime.month) return true;
	if(localVars->sHsmsConnTime.day != oldTime.day) return true;
	if(localVars->sHsmsConnTime.hour != oldTime.hour) return true;
	if(localVars->sHsmsConnTime.minute != oldTime.minute) return true;
	if(localVars->sHsmsConnTime.second != oldTime.second) return true;
	if(localVars->sHsmsConnTime.milliSecond != oldTime.milliSecond) return true;
	return false;
}


bool checkLinkRequestTimeoutAndSendData(LOCAL_PORT_STRUCT *pt, bool bRead)
{
	if(bRead == false) return false;
	if(localVars->timeoutLinkTest.IsTimeOut(localVars->nLinkTestTimeout * 1000)) {
		localVars->timeoutLinkTest.Reset();
		localVars->dTns++;// ���� ��ȣ�� ID �� �����ϸ� �ȵȴ�.// add 2016-12-05,
		makeAndSendSecsHsmsControl(pt, HSMS_LINK_TEST_REQUEST);
		localVars->cSendHsmsControl = HSMS_LINK_TEST_REQUEST;
		localVars->bSendControlCode = true;
		return true;
	}
	return false;
}

bool checkConnectAndSendSelectRequest(LOCAL_PORT_STRUCT *pt, bool bRead)
{
	setStartInitFlag(pt);
	if(checkTcpIpConnectionTimeChanged(pt)) localVars->bHsmsSelect = false;// �� connection �� �Ǿ���
	if(localVars->bHsmsSelect == false && localVars->bActiveDevice) {
		localVars->dTns++;// ���� ��ȣ�� ID �� �����ϸ� �ȵȴ�.
		makeAndSendSecsHsmsControl(pt, HSMS_SELECT_REQUEST);
		localVars->cSendHsmsControl = HSMS_SELECT_REQUEST;
		localVars->bSendControlCode = true;
		return true;
	}
	if(checkLinkRequestTimeoutAndSendData(pt, bRead)) return true;// link test code send
	return false;
}

void checkAndGetControlCodeHsms(LOCAL_PORT_STRUCT *pt)
{
	localVars->bHsmsControl = (pt->commCountCurr == localVars->nMinSize && localVars->recvBuf[9] != 0x00) ? true : false;
	//localVars->bHsmsControl = (localVars->recvBuf[4] == 0xFF && localVars->recvBuf[5] == 0xFF && localVars->recvBuf[9] != 0x00) ? true : false;
	if(localVars->bHsmsControl) {
		localVars->cRecvHsmsControl = localVars->recvBuf[9];
		checkAndSendSecsHsmsControl(pt);
		setInitRecvStatus(pt);
	}
}

int checkRecvCodeErrorSizeHsms(LOCAL_PORT_STRUCT *pt)
{
	//CString		message;
	
	localVars->bEqualStation = false;
	if(pt->commCountCurr < localVars->nMinSize) {
		setInitRecvStatus(pt);
		return COMMUNICATION_CODE_BAD;
		//message.Format("Received Data Size Too Short. Recv Size = %d, Need Size >= %d", pt->commCountCurr, localVars->nMinSize);
		//PlcScanSetErrorString(pt, (char*)(LPCSTR)message);
		//return COMMUNICATION_ERR_STRING_AND_CODEBAD;
	}

	localVars->dTns = getDwordVal(&localVars->recvBuf[10]);
	checkAndGetControlCodeHsms(pt);
	
	localVars->bRespRequire = false;
	if(localVars->bHsmsControl == false && localVars->recvBuf[6] & 0x80) localVars->bRespRequire = true;
	if(localVars->bRespRequire) {
		localVars->cRecvStream = (localVars->recvBuf[6] & 0x7F);
		localVars->cRecvFunction = localVars->recvBuf[7];
		if(localVars->cRecvFunction % 2 == 0) localVars->bRespRequire = false;
	}
	localVars->nRecvStation = getWordVal(&localVars->recvBuf[4]);
	if(localVars->bSendDataPacket) {
		localVars->bEqualStation = (localVars->nSendStation == localVars->nRecvStation) ? true : false;
	}
	return COMMUNICATION_OK;
}

int checkReturnDataCodeHsms(LOCAL_PORT_STRUCT *pt)
{
	if(localVars->bSendControlCode == false && localVars->bReadRequest == false) {
		if(localVars->bReadOkFlag) return COMMUNICATION_OK;		// Read ������ �������� �ʰ�, ���� �����Ͱ� ���� ��
		else return COMMUNICATION_OK_NOCOUNT;					// Read ������ �������� �ʰ�, ���� �����Ͱ� ���� ��
	}
	return -1;
}

static bool getNeededPacketSizeHsms(LOCAL_PORT_STRUCT *pt)
{
	if(localVars->bSize) return false;
	pt->commCountNeed = getDwordVal(&localVars->recvBuf[0]) + 4;
	localVars->bSize = true;
	if(pt->commCountCurr < pt->commCountNeed) return true;
	return false;	
}

void readDataToMemoryHsms(LOCAL_PORT_STRUCT *pt)
{	
	if(localVars->bHsmsControl || pt->commCountCurr < localVars->nMinSize) return;

	int			buf_pos = 6, target = 0;
	BYTE		cStream, cFunction;

	localVars->bReadOkFlag = true;
	cStream = (localVars->recvBuf[buf_pos++] & 0x7F);
	cFunction = localVars->recvBuf[buf_pos++];
	target = getReadStartPos(pt, localVars->nRecvStation, cStream, cFunction);
	if(localVars->bReadRequest) {
		localVars->bReadDone = (localVars->cSendStream == cStream && (BYTE)(localVars->cSendFunction + 1) == cFunction && localVars->bEqualStation) ? true : false;
	}
	if(target == -1) return;

	localVars->readDataSt.cStream = cStream;
	localVars->readDataSt.cFunction = cFunction;
	localVars->readDataSt.nSavePos = pt->commCountCurr;
	buf_pos = HSMS_HEADER_SIZE;

	if(localVars->bSaveHeaderData == true) target = savePacketHeraderDataToMemory(pt, target); // add 2016-11-22 for stream, function, tns saving
	readUserDataToMemory(pt, target, buf_pos);
}


int ProtocolReadHsms(LOCAL_PORT_STRUCT *pt)
{
	int  				count, retn;
	
	if(pt->bReadingFlag == OFF) {
		if(checkConnectAndSendSelectRequest(pt, true) == false) {
			if(checkEachReadScheduleTimeOut(pt) != -1) sendPeriodicReadOrSendData(pt, false);
		}
		if(localVars->bSendDataPacket && localVars->bReadRequest == false) return COMMUNICATION_OK;// Read ������ �����ϰ� ���� �����Ͱ� ���� ������ ����
		setInitRecvStatus(pt);
		pt->timeout->Reset();
		pt->bReadingFlag = ON;
	}

	while(1) {
		if(pt->commCountCurr >= MAX_SECS_RECV_BUF) return COMMUNICATION_ERR_SIZE_TOO_BIG;
		if(pt->timeout->IsTimeOut(pt->MAX_TIME_OUT_READ)) {
			if(localVars->bReadRequest == false && localVars->bReadOkFlag) return COMMUNICATION_OK;
			if(localVars->bSendControlCode == false && localVars->bSendDataPacket == false) return COMMUNICATION_OK_NOCOUNT;
			if(localVars->bHsmsTcpConnectionFlag == false && localVars->bActiveDevice) localVars->bHsmsSelect = (localVars->bHsmsSelect) ? false : true;// active device �� �������� �� �ð��ʰ��� ����, �ѹ��� select = true, �ѹ��� select = false
			return COMMUNICATION_TIME_OUT;
		}		
		
		count = PlcDeviceReadContinue(&pt->device, (char*)&localVars->recvBuf[pt->commCountCurr], 1);
		if(count == 0) {
			if(pt->commCountCurr == 0) {
				retn = checkReturnDataCodeHsms(pt);
				if(retn != -1) return retn;
			}
			return COMMUNICATION_WAITING;
		}
		pt->commCountCurr += count;
		
		if(pt->commCountCurr >= pt->commCountNeed) {// �ʿ��� ����Ʈ ����ŭ ����Ÿ�� ��� �޾Ҵ�.			
			if(getNeededPacketSizeHsms(pt)) continue;
			DisplayRecvCodeNextLine(pt->no);
			if(checkRecvCodeErrorSizeHsms(pt) != COMMUNICATION_OK) continue;
			
			readDataToMemoryHsms(pt);
			if(localVars->bRespRequire) {
				sprintf(localVars->sSendStream, "%1d.%1d", localVars->cRecvStream, localVars->cRecvFunction+1);
				if(localVars->bWaitSendOkSignal) checkWaitOkSignal(pt);						// add 2014-09-17 for receipe ������ ������ ���� �������α׷��� OK ��ȣ�� ���� ���ΰ�?
				makeDataReadBufHsms(pt, localVars->nRecvStation, localVars->sSendStream, false);// add 2016-12-08, false
				localVars->bRespRequire = false;
				continue;
			}
			if(localVars->bReadDone && localVars->bReadRequest) return COMMUNICATION_OK;
			if(localVars->bSendControlCode) return COMMUNICATION_OK_NOCOUNT;
			retn = checkReturnDataCodeHsms(pt);
			if(retn != -1) return retn;
			setInitRecvStatus(pt);
			continue;
		}
	}
}


void sendControlCodeOrdReadWriteCommand(LOCAL_PORT_STRUCT *pt, WORD station, char *device)
{
	if(checkConnectAndSendSelectRequest(pt, false) == false) sendReadWriteRequestDataReal(pt, station, device, false);
}


int WriteWordHsms(LOCAL_PORT_STRUCT *pt, int station, char *device)
{
	int				count;
	TimeOutClass	timeout;	
	
	sendControlCodeOrdReadWriteCommand(pt, station, device);
	if(localVars->bSendDataPacket && localVars->bReadRequest == false) return COMMUNICATION_OK;// Read ������ �����ϰ� ���� �����Ͱ� ���� ������ ����
	timeout.Reset();

	while(1) {
		if(pt->commCountCurr >= MAX_SECS_RECV_BUF) return COMMUNICATION_ERR_SIZE_TOO_BIG;
		if(pt->timeout->IsTimeOut(pt->MAX_TIME_OUT_WRITE)) {
			if(localVars->bHsmsTcpConnectionFlag == false && localVars->bActiveDevice) localVars->bHsmsSelect = (localVars->bHsmsSelect) ? false : true;// active device �� �������� �� �ð��ʰ��� ����, �ѹ��� select = true, �ѹ��� select = false
			return COMMUNICATION_TIME_OUT;
		}
		
		count = PlcDeviceReadContinue(&pt->device, (char*)&localVars->recvBuf[pt->commCountCurr], 1);
		if(count == 0) continue;
		pt->commCountCurr += count;

		// �ʿ��� ����Ʈ ����ŭ ����Ÿ�� ��� �޾Ҵ�.
		if(pt->commCountCurr >= pt->commCountNeed) {
			if(getNeededPacketSizeHsms(pt)) continue;
			DisplayRecvCodeNextLine(pt->no);
			if(checkRecvCodeErrorSizeHsms(pt) != COMMUNICATION_OK) continue;			
			
			readDataToMemoryHsms(pt);
			if(localVars->bRespRequire) {
				sprintf(localVars->sSendStream, "%1d.%1d", localVars->cRecvStream, localVars->cRecvFunction+1);
				if(localVars->bWaitSendOkSignal) checkWaitOkSignal(pt);						// add 2014-09-17 for receipe ������ ������ ���� �������α׷��� OK ��ȣ�� ���� ���ΰ�?
				makeDataReadBufHsms(pt, station, localVars->sSendStream, false);// add 2016-12-08, false
				localVars->bRespRequire = false;
				continue;
			}
			if(localVars->bSendDataPacket == false) {
				sendControlCodeOrdReadWriteCommand(pt, station, device);
				continue;
			}
			if(localVars->bReadDone) return COMMUNICATION_OK;
			setInitRecvStatus(pt);
			continue;
		}
	}
}
