#include "stdafx.h"
#include "SECS_HostDef.h"


BYTE getDataCodeHeader(BYTE dataType, BYTE size)
{
	if(size >= 4) size = 3;
	switch(dataType)
	{
		case DATA_TYPE_LIST	:
		case DATA_TYPE_BINARY :
		case DATA_TYPE_BOOLEAN :
		case DATA_TYPE_ASCII :
		case DATA_TYPE_JIS_8 :
		case DATA_TYPE_8_BYTE_SIGN_INTEGER :
		case DATA_TYPE_1_BYTE_SIGN_INTEGER :
		case DATA_TYPE_2_BYTE_SIGN_INTEGER :
		case DATA_TYPE_4_BYTE_SIGN_INTEGER :
		case DATA_TYPE_8_BYTE_FLOAT :
		case DATA_TYPE_4_BYTE_FLOAT :
		case DATA_TYPE_8_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_1_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_2_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_4_BYTE_UNSIGN_INTEGER :
			return dataType * 4 + (size % 4);
		default : return 0;						// unknown data type
	}
}

int makeStringData(BYTE *data, int buf_pos, char *str)
{
	int		len = (int)strlen(str);
	if(len < 0) len = 0;
	//if(len > 256) len = 256;

	if(buf_pos + len >= MAX_SECS_SAVE_BUF) return buf_pos;
	data[buf_pos++] = len;
	if(len <= 0) return buf_pos;

	sprintf((char *)&data[buf_pos], "%s", str);
	return buf_pos + len;
}

int makeInt8Data(BYTE *data, int buf_pos, BYTE val)
{
	if(buf_pos + 1 >= MAX_SECS_SAVE_BUF) return buf_pos;
	data[buf_pos+0] = val;
	return buf_pos + 1;
}

int makeInt16Data(BYTE *data, int buf_pos, WORD val)
{
	if(buf_pos + 2 >= MAX_SECS_SAVE_BUF) return buf_pos;
	data[buf_pos+0] = HIBYTE(val);
	data[buf_pos+1] = LOBYTE(val);
	return buf_pos + 2;
}

int makeInt32Data(BYTE *data, int buf_pos, DWORD val)
{
	if(buf_pos + 4 >= MAX_SECS_SAVE_BUF) return buf_pos;
	WORD imsi = HIWORD(val);
	data[buf_pos+0] = HIBYTE(imsi);
	data[buf_pos+1] = LOBYTE(imsi);
	imsi = LOWORD(val);
	data[buf_pos+2] = HIBYTE(imsi);
	data[buf_pos+3] = LOBYTE(imsi);
	return buf_pos + 4;
}

int makeInt64Data(BYTE *data, int buf_pos, unsigned __int64 val)
{
	buf_pos = makeInt32Data(data, buf_pos, (DWORD)(val >> 32));
	return makeInt32Data(data, buf_pos, (DWORD)val);
}

int makeFloat32Data(BYTE *data, int buf_pos, float val)
{
	if(buf_pos + 4 >= MAX_SECS_SAVE_BUF) return buf_pos;
	char	imsi[10];
	memcpy(imsi, &val, 4);
	for(int i = 0; i < 4; i++) data[buf_pos+i] = imsi[(3-i) % 4];
	return buf_pos + 4;
}

int makefloat64Data(BYTE *data, int buf_pos, double val)
{
	if(buf_pos + 8 >= MAX_SECS_SAVE_BUF) return buf_pos;
	char	imsi[10];
	memcpy(imsi, &val, 8);
	for(int i = 0; i < 8; i++) data[buf_pos+i] = imsi[(7-i) % 8];
	return buf_pos + 8;
}

int addDataCodeHeader(BYTE *data, int buf_pos, int nDataType, int nDataSize)
{
	if(buf_pos + 2 >= MAX_SECS_SAVE_BUF) return buf_pos;
	int		size = 0;
	switch(nDataType)
	{
		case DATA_TYPE_LIST	:
		case DATA_TYPE_BINARY :
		case DATA_TYPE_BOOLEAN :
		case DATA_TYPE_ASCII :
		case DATA_TYPE_JIS_8 :
		case DATA_TYPE_1_BYTE_SIGN_INTEGER :
		case DATA_TYPE_1_BYTE_UNSIGN_INTEGER : size = nDataSize; break;
		case DATA_TYPE_2_BYTE_SIGN_INTEGER :
		case DATA_TYPE_2_BYTE_UNSIGN_INTEGER : size = nDataSize*2; break;
		case DATA_TYPE_4_BYTE_SIGN_INTEGER :		
		case DATA_TYPE_4_BYTE_FLOAT :		
		case DATA_TYPE_4_BYTE_UNSIGN_INTEGER : size = nDataSize*4; break;
		case DATA_TYPE_8_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_8_BYTE_SIGN_INTEGER :
		case DATA_TYPE_8_BYTE_FLOAT : size = nDataSize*8; break;
		default : return buf_pos;
	}
	if(size < 256) {
		data[buf_pos+0] = getDataCodeHeader(nDataType, 1);
		data[buf_pos+1] = (BYTE)size;// byte size
		return buf_pos+2;
	}
	else {
		if(buf_pos + 3 >= MAX_SECS_SAVE_BUF) return buf_pos;
		data[buf_pos+0] = getDataCodeHeader(nDataType, 2);
		data[buf_pos+1] = HIBYTE(size);// byte size
		data[buf_pos+2] = LOBYTE(size);
		return buf_pos+3;
	}
}

int addRealDataCode(SECS_ONE_DATA *list, BYTE *data, int buf_pos, int nDataType)
{
	int		i;

	if(list->bTagVal) {
		CString		curr = "";
		if(Tag9GetCurr(list->tag, curr) == false) curr = "***";
		switch(nDataType)
		{
			case DATA_TYPE_LIST	: return buf_pos;
			case DATA_TYPE_BINARY : 
			case DATA_TYPE_BOOLEAN : return makeInt8Data(data, buf_pos, (BYTE)atoi(curr));
			case DATA_TYPE_ASCII :
			case DATA_TYPE_JIS_8 : return makeStringData(data, buf_pos, (char *)curr.GetBuffer());
			case DATA_TYPE_1_BYTE_SIGN_INTEGER :
			case DATA_TYPE_1_BYTE_UNSIGN_INTEGER : return makeInt8Data(data, buf_pos, (BYTE)atoi(curr));
			case DATA_TYPE_2_BYTE_SIGN_INTEGER :
			case DATA_TYPE_2_BYTE_UNSIGN_INTEGER : return makeInt16Data(data, buf_pos, (WORD)atoi(curr));
			case DATA_TYPE_4_BYTE_SIGN_INTEGER :
			case DATA_TYPE_4_BYTE_UNSIGN_INTEGER : return makeInt32Data(data, buf_pos, (DWORD)atol(curr));
			case DATA_TYPE_4_BYTE_FLOAT : return makeFloat32Data(data, buf_pos, (float)atof(curr));
			case DATA_TYPE_8_BYTE_UNSIGN_INTEGER :
			case DATA_TYPE_8_BYTE_SIGN_INTEGER : return makeInt64Data(data, buf_pos, (unsigned __int64)_atoi64(curr));
			case DATA_TYPE_8_BYTE_FLOAT : return makefloat64Data(data, buf_pos, (double)atof(curr));
			default : return buf_pos;
		}
		return buf_pos;
	}
	switch(nDataType)
	{
		case DATA_TYPE_LIST	: return buf_pos;
		case DATA_TYPE_BINARY : 
		case DATA_TYPE_BOOLEAN :
			if(buf_pos + 1 >= MAX_SECS_SAVE_BUF) return buf_pos;
			data[buf_pos+0] = list->val[0]; return buf_pos+1;
		case DATA_TYPE_ASCII :
		case DATA_TYPE_JIS_8 : return makeStringData(data, buf_pos, (char *)list->string);
		case DATA_TYPE_1_BYTE_SIGN_INTEGER :
		case DATA_TYPE_1_BYTE_UNSIGN_INTEGER : 
			if(buf_pos + 1 >= MAX_SECS_SAVE_BUF) return buf_pos;
			data[buf_pos+0] = list->val[0]; return buf_pos+1;
		case DATA_TYPE_2_BYTE_SIGN_INTEGER :
		case DATA_TYPE_2_BYTE_UNSIGN_INTEGER : 
			if(buf_pos + 2 >= MAX_SECS_SAVE_BUF) return buf_pos;
			for(i = 0; i < 2; i++) data[buf_pos+i] = list->val[i]; return buf_pos+2;
		case DATA_TYPE_4_BYTE_SIGN_INTEGER :		
		case DATA_TYPE_4_BYTE_FLOAT :		
		case DATA_TYPE_4_BYTE_UNSIGN_INTEGER : 
			if(buf_pos + 4 >= MAX_SECS_SAVE_BUF) return buf_pos;
			for(i = 0; i < 4; i++) data[buf_pos+i] = list->val[i]; return buf_pos+4;
		case DATA_TYPE_8_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_8_BYTE_SIGN_INTEGER :
		case DATA_TYPE_8_BYTE_FLOAT : 
			if(buf_pos + 8 >= MAX_SECS_SAVE_BUF) return buf_pos;
			for(i = 0; i < 8; i++) data[buf_pos+i] = list->val[i]; return buf_pos+8;
		default : return buf_pos;
	}
}

int addOneSfListDataCode(SECS_REAL_DATA *list, BYTE *data, int buf_pos)
{
	int		i;

	if(list->nDataCount <= 0) return buf_pos;
	buf_pos = addDataCodeHeader(data, buf_pos, list->nDataType, list->nDataCount);
	if(isAsciiData(list->nDataType)) {
		buf_pos = addRealDataCode(list->data, data, buf_pos-1, list->nDataType);// data size�� �ٽ� ����ϹǷ� buf_pos - 1 �� �Է�
	}
	else {
		for(i = 0; i < list->nDataCount; i++) buf_pos = addRealDataCode(&list->data[i], data, buf_pos, list->nDataType);
	}
	return buf_pos;
}

int makeSfMemoryDataCode(SECS_DATA *list, BYTE *data, int buf_pos)
{
	int		i;

	if(list->nDataType == DATA_TYPE_LIST) {
		if(list->nList <= 0) return buf_pos;
		buf_pos = addDataCodeHeader(data, buf_pos, list->nDataType, list->nList);
		for(i = 0; i < list->nList; i++) {
			buf_pos = makeSfMemoryDataCode((SECS_DATA *)&list->list[i], data, buf_pos);
		}
	}
	else buf_pos = addOneSfListDataCode(&list->realData, data, buf_pos);
	return buf_pos;
}

int makeS1F2Message(BYTE *data)
{
	int		buf_pos = 0;
	//if(bHost) {
	//	data[buf_pos++] = getDataCodeHeader(DATA_TYPE_LIST, 0);// list 0��
	//	return buf_pos;
	//}
	data[buf_pos++] = getDataCodeHeader(DATA_TYPE_LIST, 1);// list, Byte data size = 1 (always)
	data[buf_pos++] = 0x02;// list 2��
	data[buf_pos++] = getDataCodeHeader(DATA_TYPE_ASCII, 1);// MDLN, Byte data size = 1 (always)
	buf_pos = makeStringData(data, buf_pos, "AUTOBASE Secs Host");
	data[buf_pos++] = getDataCodeHeader(DATA_TYPE_ASCII, 1);// SOFTREV, Byte data size = 1 (always)
	buf_pos = makeStringData(data, buf_pos, "1.0");
	return buf_pos;
}

int makeS2F18Message(BYTE *data)
{
	SYSTEMTIME	t;
	char		buf[50];
	int			buf_pos = 0;

	GetLocalTime(&t);
	data[buf_pos++] = getDataCodeHeader(DATA_TYPE_ASCII, 1);// MDLN, Byte data size = 1 (always)
	sprintf(buf, "%04d%02d%02d%02d%02d%02d%02d", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
	buf[16] = 0;
	buf_pos = makeStringData(data, buf_pos, buf);
	return buf_pos;
}

int seekSfMemoryData(LOCAL_PORT_STRUCT *pt, BYTE cStream, BYTE cFunction)
{
	int			i;

	for(i = 0; i < MAX_STREAM_FUNCTION_DATA; i++) {
		if(localVars->sfData[i].bExist == false) continue;
		if(localVars->sfData[i].cStream != cStream) continue;
		if(localVars->sfData[i].cFunction != cFunction) continue;
		return i;
	}
	return -1;
}

int getDefaultStreamFunctionData(LOCAL_PORT_STRUCT *pt, BYTE *data)
{
	if(localVars->cStream == 1 && localVars->cFunction == 2) return makeS1F2Message(data);
	if(localVars->cStream == 2 && localVars->cFunction == 18) return makeS2F18Message(data);
	return 0;
}

int makeSfMemoryDataToBuf(LOCAL_PORT_STRUCT *pt, BYTE *data)
{
	int		buf_pos = 0, memPos = seekSfMemoryData(pt, localVars->cStream, localVars->cFunction);
	//if(memPos == -1 || localVars->sfData[memPos].nList <= 0) return getDefaultStreamFunctionData(pt, data);
	if(memPos == -1) return getDefaultStreamFunctionData(pt, data);
	
	if(localVars->sfData[memPos].nDataType == DATA_TYPE_LIST) {
		if(localVars->sfData[memPos].nList > 0) buf_pos = addDataCodeHeader(data, buf_pos, localVars->sfData[memPos].nDataType, localVars->sfData[memPos].nList);
		for(int i = 0; i < localVars->sfData[memPos].nList; i++) buf_pos = makeSfMemoryDataCode(&localVars->sfData[memPos].list[i], data, buf_pos);
	}
	else {
		buf_pos = addOneSfListDataCode(&localVars->sfData[memPos].realData, data, buf_pos);
	}
	return buf_pos;
}




/*int makeS1F11Message(BYTE *data, int buf_pos, bool bHost)
{
	//if(bHost) {
	//	data[buf_pos++] = getDataCodeHeader(DATA_TYPE_LIST, 0);// list 0��
	//	return buf_pos;
	//}
	data[buf_pos++] = getDataCodeHeader(DATA_TYPE_LIST, 1);// list, Byte data size = 1 (always)
	data[buf_pos++] = 0x01;// list 1��
	data[buf_pos++] = getDataCodeHeader(DATA_TYPE_2_BYTE_UNSIGN_INTEGER, 1);// SVID, Byte data size = 1 (always)
	data[buf_pos++] = 0x02;// size = 2 byte
	buf_pos = makeInt16Data(data, buf_pos, 11);
	return buf_pos;
}

int makeStream1Message(LOCAL_PORT_STRUCT *pt, BYTE *data, int buf_pos, BYTE function, bool bHost)
{
	int		oldPos = buf_pos;
	buf_pos = makeSfMemoryData(pt, data, buf_pos, 1, function, bHost);
	if(buf_pos != oldPos) return buf_pos;

	switch(function) {
		case 1  : break;
		case 2  : return makeS1F2Message(data, buf_pos, bHost);
		case 11 : return makeS1F11Message(data, buf_pos, bHost);
		default: break;
	}
	return buf_pos;//0;
}


int makeS2F18Message(BYTE *data, int buf_pos, bool bHost)
{
	SYSTEMTIME	t;
	char		buf[50];

	GetLocalTime(&t);
	data[buf_pos++] = getDataCodeHeader(DATA_TYPE_ASCII, 1);// MDLN, Byte data size = 1 (always)
	sprintf(buf, "%04d%02d%02d%02d%02d%02d%02d", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
	buf[16] = 0;
	buf_pos = makeStringData(data, buf_pos, buf);
	return buf_pos;
}

int makeStream2Message(BYTE *data, int buf_pos, BYTE function, bool bHost)
{
	switch(function) {
		case 1 : break;
		case 18 : return makeS2F18Message(data, buf_pos, bHost);
		default: 
			break;
	}
	return buf_pos;//0;
}*/
