// stdafx.cpp : source file that includes just the standard includes
// SECS_Host.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


