// SECS_Host.h : main header file for the SECS_Host DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

// CSECS_HostApp
// See SECS_Host.cpp for the implementation of this class
//

class CSECS_HostApp : public CWinApp
{
public:
	CSECS_HostApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
