#if	!defined (__SECS_HOSTDEF_H)
#define	__SECS_HOSTDEF_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <compiler.hpp>


#include <totaldef.h>
#include <tools.h>
#include <glib.h>
#include <crc.hpp>
#include <math.h>
//#include <io.h>

#include "..\..\catlib\totalcfg.h"
#include "..\..\catlib\cattag.h"
#include "..\..\PLC_SCAN\plc_scan.h"
#include "..\..\PLC_SCAN\DLL\\dll_lib\dll_lib.h"


#define		MAX_STREAM_COUNT 128
#define		MAX_FUNCTION_COUNT 256
#define		MAX_ITEM_TYPE	15
#define		MAX_ARRAY_COUNT	256

#define		MAX_READ_SCHEDULE 256
#define		MAX_ONE_PACKET_DATA 244
#define		MAX_SECS_SEND_BUF 258
#define		MAX_SECS_SAVE_BUF 30000
#define		MAX_SECS_RECV_BUF 30000
#define		MAX_STREAM_FUNCTION_DATA 256
#define		HSMS_HEADER_SIZE 14
#define		MAX_WAIT_OK_TAG 100		// add by kdy 2014-11-19




enum {
	DATA_TYPE_LIST	=					0x00,
	DATA_TYPE_BINARY =					0x08,
	DATA_TYPE_BOOLEAN =					0x09,
	DATA_TYPE_ASCII =					0x10,
	DATA_TYPE_JIS_8 =					0x11,
	DATA_TYPE_8_BYTE_SIGN_INTEGER =		0x18,
	DATA_TYPE_1_BYTE_SIGN_INTEGER =		0x19,
	DATA_TYPE_2_BYTE_SIGN_INTEGER =		0x1A,
	DATA_TYPE_4_BYTE_SIGN_INTEGER =		0x1C,
	DATA_TYPE_8_BYTE_FLOAT =			0x20,
	DATA_TYPE_4_BYTE_FLOAT =			0x24,
	DATA_TYPE_8_BYTE_UNSIGN_INTEGER =	0x28,
	DATA_TYPE_1_BYTE_UNSIGN_INTEGER =	0x29,
	DATA_TYPE_2_BYTE_UNSIGN_INTEGER =	0x2A,
	DATA_TYPE_4_BYTE_UNSIGN_INTEGER =	0x2C,

	DATA_UNKNOWN_TYPE =					-1,
};


enum {
	READ_ENQ_STATUS,
	READ_BLOCK_DATA_STATUS,	
	//ACK_STATUS,
	READ_EOT_STATUS,
	//SEND_BLOCK_DATA_STATUS,
	READ_ACK_STATUS,
};

enum {
	HSMS_DATA_CODE = 0,
	HSMS_SELECT_REQUEST = 1,
	HSMS_SELECT_RESPONSE = 2,
	HSMS_DESELECT_REQUEST = 3,
	HSMS_DESELECT_RESPONSE = 4,
	HSMS_LINK_TEST_REQUEST = 5,
	HSMS_LINK_TEST_RESPONSE = 6,
	HSMS_SEPARATE_REQUEST = 9,
};

enum {
	COMMAND_NONE,
};



typedef struct {
	bool	bTagVal;// false = real Value, true = tag Value
	char	tag[81];// tag name, changed 2016-09-13, tag[40] -> tag[81]
	BYTE	val[8];// �ִ� 8byte data
	BYTE	*string;
} SECS_ONE_DATA;

typedef struct {
	int				nDataType;
	int				nDataCount;
	SECS_ONE_DATA	*data;
	//BYTE			*string;
} SECS_REAL_DATA;

struct SECS_DATA {
	SECS_DATA		*list;
	WORD			nList;		// list ������ ����
	int				nDataType;	// ������ ����
	SECS_REAL_DATA	realData;
};

typedef struct {
	bool			bExist;		// ������ ���ǰ� �Ǿ� �ִ���?
	BYTE			cStream;	// stream no 0 ~ 127
	BYTE			cFunction;	// Function No0 ~ 255
	SECS_DATA		*list;
	WORD			nList;		// list ������ ����
	int				nDataType;	// ������ ����
	SECS_REAL_DATA	realData;
	int				nFileNo;	// ����� ���Ϲ�ȣ, �����Ϳ����� ���
	bool			bChange;	// ���� ����Ǿ�����?, �����Ϳ����� ���
} STREAM_FUNCTION_DATA;

typedef struct {
	WORD	nStation;	// station no = 0 ~ 32767
	BYTE	cStream;	// stream no 0 ~ 127
	BYTE	cFunction;	// Function No	
	WORD	nPacketNo;	// ��Ŷ��ȣ
	WORD	nOldPacketNo;// ���� ��Ŷ��ȣ
	int		nSavePos;
} READ_DATA_STRUCT;

typedef struct {//9byte = year(2)+month(1)+day(1)+hour(1)+minute(1)+second(1)+milisecond(2);
	WORD	year;
	BYTE	month;
	BYTE	day;
	BYTE	hour;
	BYTE	minute;
	BYTE	second;
	WORD	milliSecond;	
} HSMS_CONNECTION_TIME;


typedef struct {		// add by kdy 2014-11-19
	BYTE	cUse;		// use flag
	BYTE	cStream;	// stream no 
	BYTE	cFunction;	// Function No
	char	tag[81];	// tag name, changed 2016-09-13, tag[40] -> tag[81]
} WAIT_OK_ONE_DATA;

typedef struct {
	BYTE	cStream;	// stream no 
	BYTE	cFunction;	// Function No
	BYTE	cSendStream;// stream no 
	BYTE	cSendFunction;// Function No
	BYTE	cRecvStream;// stream no 
	BYTE	cRecvFunction;// Function No
	BYTE	cSendHsmsControl;// Hsms �� sended control code
	BYTE	cRecvHsmsControl;// Hsms �� received control code
	WORD	nBlockNo;	// Block No
	WORD	nSendSave;	// ����� ���� �������� ����
	WORD	nMinSize;
	WORD	nSendStation;// send station
	WORD	nRecvStation;// receive station np
	WORD	nLinkTestTimeout;// link test timeout default = 10��
	DWORD	dTns;		// transation

	bool	bHsms;		// Serial(true) or TCP(HSMS)�ΰ�
	bool	bSize;
	bool	bRespRequire;
	bool	bEndPacket;
	bool	bSendEnd;
	bool	bEquip;		// Host or Equipment
	bool	bSendControlCode;// control code send ?
	bool	bHsmsControl;// control code?
	bool	bHsmsSelect;// Hsms Slected?
	bool	bSendDataPacket;// ��Ŷ�� �����ߴ°�?
	bool	bReadRequest;// read reauest ������ ���� ���ΰ�?
	bool	bReadDone;	// �бⰡ �Ϸ�Ǿ���.
	bool	bEqualStation;// send/ receive station equal
	bool	bReadOkFlag;// �б� ������ ������ Ȯ���ϴ� �÷���
	bool	bActiveDevice;// Hsms protocol ���� active?(passive == TCP Server)
	bool	bReadWriteRequest;// read write request for serial communication
	bool	bUseConflictSolution;// ENQ �浹 �� Host ��忡�� �纸�� �� ������?(������ true ��� ����, �ڷ� ��)
	bool	bHsmsTcpConnectionFlag;// PLC_SCAN ���α׷����� TCP/IP connection time �� �о��°�(version 9 �̻󿡼� �� on)
	bool	bWaitSendOkSignal; // add 2014-09-12 for receipe ������ ������ ���� �������α׷��� OK ��ȣ�� ���� ���ΰ�?
	bool	bSaveHeaderData;// add 2016-11-22 for stream, function, tns saving
	int		nCommand;
	int		nStatus;
	int		nReadStreamFunction;// ���� stream/function data�� ��, �ִ� = MAX_STREAM_FUNCTION_DATA
	int		nCurrentReadPos;	// �ֱ����� �б��� read pos
	//DWORD	nResponseOkMemoryPos; // add 2014-09-17 for receipe OK memory address, ���θ޸𸮴� waiting ���� �ܺΰ��� ���� �� ���� ������ �ȵ�, 2014-11-07 �ٽ� ����
	DWORD	nResponseCheckTimeout;// add 2014-09-12 for receipe ������ ������ ���� timeout
	char	sSendStream[81];
	char    sResponseOkTag[81];	  // add 2014-11-07 for receipe OK memory tag
	char    sCurrWaitOkTag[81];	  // add by kdy 2014-11-19
	WAIT_OK_ONE_DATA waitOkData[MAX_WAIT_OK_TAG];// add by kdy 2014-11-19
	

	HSMS_CONNECTION_TIME	sHsmsConnTime;
	
	READ_DATA_STRUCT readDataSt;
	BYTE	sendBuf[MAX_SECS_SEND_BUF];
	BYTE	saveBuf[MAX_SECS_SAVE_BUF+HSMS_HEADER_SIZE];
	BYTE	recvBuf[MAX_SECS_RECV_BUF];
	STREAM_FUNCTION_DATA sfData[MAX_STREAM_FUNCTION_DATA];
	TimeOutMiliSecClass	timeout[MAX_READ_SCHEDULE];
	TimeOutMiliSecClass	timeoutLinkTest;
} LOCAL_VARS_STRUCT;

#define localVars ((LOCAL_VARS_STRUCT*)pt->hLocalProtocol)

extern char sWorkDir[MAX_PATH];
extern char	itemType_buf[MAX_ITEM_TYPE][10];


int Tag9GetCurr(const char *tag, CString &curr);
WORD getWordVal(BYTE *data);
DWORD getDwordVal(BYTE *data);
_int64 get8ByteVal(BYTE *data);
float getFloat4Val(BYTE *data);
double getFloat8Val(BYTE *data);
double getStringDoulbeVal(BYTE *data, WORD size);
int setDwordvalToBuf(BYTE *data, int buf_pos, DWORD val);
void PokeValueAll(LOCAL_PORT_STRUCT *pt, int target, double val);
void PokeValueAll(LOCAL_PORT_STRUCT *pt, int target, WORD val);
void PokeValueAll(LOCAL_PORT_STRUCT *pt, int target, DWORD val);
void PokeValueAll(LOCAL_PORT_STRUCT *pt, int target, _int64 val);
void PokeValueAllAscii(LOCAL_PORT_STRUCT *pt, int target, BYTE *data, WORD size);

bool checkAndGetTcpIpConnectionTime(LOCAL_PORT_STRUCT *pt);
void setInitRecvStatus(LOCAL_PORT_STRUCT *pt);
void setStartInitFlag(LOCAL_PORT_STRUCT *pt);
int makeSecsHeaderEquipAndStation(LOCAL_PORT_STRUCT *pt, BYTE *data, WORD station, int buf_pos);
int getReadStartPos(LOCAL_PORT_STRUCT *pt, WORD station, BYTE cRecvStream, BYTE cRecvFunction);
int readUserDataToMemory(LOCAL_PORT_STRUCT *pt, int &target, int &buf_pos);
int checkEachReadScheduleTimeOut(LOCAL_PORT_STRUCT *pt);
int checkReturnDataCode(LOCAL_PORT_STRUCT *pt);
void makeDataReadBufHsms(LOCAL_PORT_STRUCT *pt, WORD station, char *device, bool bReadRequest);// add 2016-12-08, bool bReadRequest
void sendReadWriteRequestDataReal(LOCAL_PORT_STRUCT *pt, WORD station, char *type, bool bSerial);
void sendPeriodicReadOrSendData(LOCAL_PORT_STRUCT *pt, bool bSerial);
int ProtocolReadHsms(LOCAL_PORT_STRUCT *pt);
int WriteWordHsms(LOCAL_PORT_STRUCT *pt, int station, char *device);
bool getStreamFunctionData(char *device, BYTE &cStream, BYTE &cFunction);
bool getStreamFunctionNoFormFile(FILE *in, BYTE &cStream, BYTE &cFunction);
bool getStreamFunctionFileReal(STREAM_FUNCTION_DATA *sf, int ptNo, int no);
bool isGetTagData(char *buf);
bool setOneTagStringData(SECS_ONE_DATA *data, char *buf);
void getReadvalueString(SECS_REAL_DATA *list, CString *data, bool bTree);
bool setOneTagData(SECS_ONE_DATA *data, char *buf, int nDataType);

int makeSfMemoryDataToBuf(LOCAL_PORT_STRUCT *pt, BYTE *data);
bool getOneRealSfData(SECS_REAL_DATA *realData, char *buf, int nDataType, int nDataSize);
void getStreamFunctionFile(LOCAL_PORT_STRUCT *pt);
void setDefaultSfData(STREAM_FUNCTION_DATA *sf, int pos, BYTE cStream, BYTE cFunction);
bool saveOneSfDataToFile(STREAM_FUNCTION_DATA *sf, char *filename);
void deleteSfMemory(LOCAL_PORT_STRUCT *pt);
bool isAsciiData(int nDataType);
int getSecsDataType(char *data);
int getSecsDataTypeNo(char *data);
int getSecsDataNoToDataType(int no);
bool getStringToDataValue(CString data, CString &val);
int getStringToItemCount(CString data);
int getStringToItemCountToBuf(CString data, int nDataType);
CString setStringDataDeleteEmptyData(CString data);
int getDataTypeToBufNo(int nDataType);
bool getOneListData(SECS_DATA *listData, FILE *in, int &pos);
bool getOneRealSfData(SECS_REAL_DATA *realData, char *buf, int nDataType, int nDataSize);
bool getOneRealSfDataWithoutHeader(SECS_REAL_DATA *realData, char *buf, int nDataType, int nDataSize);
void deleteSfMemoryStringBuf(SECS_REAL_DATA *data);
void deleteSfMemoryReal(SECS_DATA *listData);

int makeS1F2Message(BYTE *data, int buf_pos, bool bHost);
int makeStream1Message(LOCAL_PORT_STRUCT *pt, BYTE *data, int buf_pos, BYTE function, bool bHost);
int makeStream2Message(BYTE *data, int buf_pos, BYTE function, bool bHost);

void checkWaitOkSignal(LOCAL_PORT_STRUCT *pt);
int savePacketHeraderDataToMemory(LOCAL_PORT_STRUCT *pt, int target);// add 2016-11-22


#endif