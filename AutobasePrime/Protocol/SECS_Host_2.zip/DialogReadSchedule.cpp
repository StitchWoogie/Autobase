// DialogReadSchedule.cpp : implementation file
//

#include "stdafx.h"
#include "SECS_Host.h"
#include "SECS_HostDef.h"
#include "DialogReadSchedule.h"
#include ".\dialogreadschedule.h"

extern char		mem_buf[3][10];

// CDialogReadSchedule dialog

IMPLEMENT_DYNAMIC(CDialogReadSchedule, CDialog)
CDialogReadSchedule::CDialogReadSchedule(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogReadSchedule::IDD, pParent)
	, m_station(0)
	, m_bufAddr(0)
	, m_readSize(0)
	, m_bUsePeriodicRead(FALSE)
	, m_periodicRead(0)
{
}

CDialogReadSchedule::~CDialogReadSchedule()
{
}

void CDialogReadSchedule::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_MEMORY_TYPE, m_comboMemory);
	DDX_Text(pDX, IDC_EDIT_SCHEDULE_READ_STATION, m_station);
	DDV_MinMaxUInt(pDX, m_station, 0, 255);
	DDX_Control(pDX, IDC_SPIN_SCHEDULE_READ_STATION, m_spinStation);
	DDX_Control(pDX, IDC_COMBO_FUNCTION, m_comboStream);
	DDX_Control(pDX, IDC_COMBO_FUNCTION2, m_comboFunction);
	DDX_Text(pDX, IDC_EDIT_SCHEDULE_BUF_ADDR, m_bufAddr);
	DDV_MinMaxUInt(pDX, m_bufAddr, 0, 65535);
	DDX_Control(pDX, IDC_SPIN_SCHEDULE_BUF_ADDR, m_spinBufAddr);
	DDX_Text(pDX, IDC_EDIT_SCHEDULE_READ_SIZE, m_readSize);
	DDV_MinMaxUInt(pDX, m_readSize, 1, 1);
	DDX_Control(pDX, IDC_SPIN_SCHEDULE_READ_SIZE, m_spinReadSize);
	DDX_Check(pDX, IDC_CHECK_PERIODIC_READ, m_bUsePeriodicRead);
	DDX_Text(pDX, IDC_EDIT_SCHEDULE_PEDIODIC_READ, m_periodicRead);
	DDV_MinMaxUInt(pDX, m_periodicRead, 0, 6000000);
	DDX_Control(pDX, IDC_SPIN_SCHEDULE_PERIODIC_READ, m_spinPeriodicRead);
}


BEGIN_MESSAGE_MAP(CDialogReadSchedule, CDialog)
	ON_BN_CLICKED(IDC_CHECK_PERIODIC_READ, OnBnClickedCheckPeriodicRead)
END_MESSAGE_MAP()


// CDialogReadSchedule message handlers

BOOL CDialogReadSchedule::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	int			i;
	char		imsi[10];
	
	m_spinStation.SetRange(0, 255);
	m_spinBufAddr.SetRange32(0, 65535);
	m_spinReadSize.SetRange(1, 1);
	m_spinPeriodicRead.SetRange32(1, 6000000);
	
	for(i = 0; i < 3; i++) m_comboMemory.AddString(mem_buf[i]);
	m_comboMemory.SetCurSel(m_memory%3);
	for(i = 0; i < MAX_STREAM_COUNT; i++) {
		sprintf(imsi, "%03d", i);
		m_comboStream.AddString(imsi);
	}
	m_comboStream.SetCurSel(m_stream%MAX_STREAM_COUNT);
	for(i = 0; i < MAX_FUNCTION_COUNT; i++) {
		sprintf(imsi, "%03d", i);
		m_comboFunction.AddString(imsi);
	}
	m_comboFunction.SetCurSel(m_function%MAX_FUNCTION_COUNT);
	EnableDisable();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDialogReadSchedule::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class
	m_memory = m_comboMemory.GetCurSel();
	m_stream = m_comboStream.GetCurSel();
	m_function = m_comboFunction.GetCurSel();
	UpdateData(1);
	if(m_bUsePeriodicRead == false) {
		m_periodicRead = 0;
		UpdateData(0);
	}
	CDialog::OnOK();
}

void CDialogReadSchedule::EnableDisable()
{
	bool	flag = (m_bUsePeriodicRead) ? true : false;
	GetDlgItem(IDC_EDIT_SCHEDULE_PEDIODIC_READ)->EnableWindow(flag);
	GetDlgItem(IDC_SPIN_SCHEDULE_PERIODIC_READ)->EnableWindow(flag);
}

void CDialogReadSchedule::OnBnClickedCheckPeriodicRead()
{
	// TODO: Add your control notification handler code here
	UpdateData(1);
	EnableDisable();
	if(m_bUsePeriodicRead && m_periodicRead <= 0) {
		m_periodicRead = 1000;
		UpdateData(0);
	}
}
