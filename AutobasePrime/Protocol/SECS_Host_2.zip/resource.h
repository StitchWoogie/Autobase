//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SECS_Host.rc
//
#define IDD_DIALOG_DELETE_CONFIRM       6000
#define IDC_LIST_SELECT_TAG             6000
#define IDC_TREE_SF_EDIT                6001
#define IDD_DIALOG_OPTION               6002
#define IDC_BUTTON_SF_EDIT              6003
#define IDD_DIALOG_READ_SCHEDULE        6004
#define IDD_DIALOG_SF_EDIT_MAIN         6005
#define IDC_EDIT_ITEM_VALUE             6006
#define IDD_DIALOG_EDIT_SF              6007
#define IDC_EDIT_ITEM_COUNT             6008
#define IDD_DIALOG1                     6008
#define IDD_DIALOG_SELECT_TAG           6008
#define IDD_DIALOG_WAIT_OK_TAG          6009
#define IDC_EDIT_ITEM_TOTAL_VALUE       6010
#define IDD_DIALOG_SELECT_SF_AND_TAG    6010
#define IDC_EDIT_ITEM_CURR_VALUE        6011
#define IDC_SPIN_ADD_EDIT_POS           6012
#define IDC_LIST_TAG                    6013
#define IDC_SPIN_SCHEDULE_BUF_ADDR      6014
#define IDC_COMBO_ITEM_SELECTED         6015
#define IDC_SPIN_SCHEDULE_READ_SIZE     6016
#define IDC_SPIN_SCHEDULE_READ_STATION  6017
#define IDC_SPIN_SCHEDULE_PERIODIC_READ 6018
#define IDC_RADIO_ANALOG_INPUT          6018
#define IDC_RADIO_ANALOG_OUTPUT         6019
#define IDC_RADIO_DIGITAL_INPUT         6020
#define IDC_RADIO_DIGITAL_OUTPUT        6021
#define IDC_CHECK_PERIODIC_READ         6021
#define IDC_RADIO_STRING                6022
#define IDC_EDIT_LINK_TEST_TIME         6022
#define IDC_LIST_READ_SCHEDULE          6023
#define IDC_RADIO_TAG_STRING_TAG        6023
#define IDC_RADIO_TAG_STRING            6023
#define IDC_BUTTON_EDIT                 6024
#define IDC_COMBO_MEMORY_TYPE           6025
#define IDC_SPIN_SCHEDULE_LINK_TEST_TIME 6025
#define IDC_BUTTON_DELETE               6026
#define IDC_BUTTON_ADD                  6027
#define IDC_EDIT_SCHEDULE_BUF_ADDR      6028
#define IDC_CHECK_CONFLICT_YIELD        6028
#define IDC_EDIT_SCHEDULE_READ_SIZE     6029
#define IDC_BUTTON_ADD_DATA             6029
#define IDC_TEXT_ENQ_CONTENTION         6029
#define IDC_EDIT_SCHEDULE_READ_STATION  6030
#define IDC_BUTTON_DELETE_DATA          6030
#define IDC_CHECK_USE_RESPONSE_OK       6030
#define IDC_TEXT_READ_SCHEDULE          6031
#define IDC_EDIT_SCHEDULE_PEDIODIC_READ 6031
#define IDC_EDIT_RESPONSE_OK_TAG        6031
#define IDC_COMBO_FUNCTION              6032
#define IDC_EDIT_CHECK_TIMEOUT          6032
#define IDC_COMBO_ITEM_TYPE             6033
#define IDC_SPIN_CHECK_TIMEOUT          6033
#define IDC_COMBO_FUNCTION2             6034
#define IDC_BUTTON_TAG_SELECTION        6034
#define IDC_EDIT_STATUS_TAG_NAME        6034
#define IDC_TEXT_DELETE_CONFIRM         6035
#define IDC_BUTTON_STATUS_TAG           6035
#define IDC_BUTTON_TAG_ADD              6036
#define IDC_RADIO_STRING_TAG2           6036
#define IDC_BUTTON_UPDATE_DATA          6037
#define IDC_BUTTON_WAIT_OK_FOR_EACH_SF  6037
#define IDC_BUTTON_TAG_VALUE_ADD        6038
#define IDC_CHECK1                      6038
#define IDC_RADIO_HOST_MODE             6039
#define IDC_RADIO_EQUIP_MODE            6040
#define IDC_RADIO_SERIAL_MODE           6042
#define IDC_RADIO_HSMS_MODE             6043
#define IDC_CHECK_USE_CHECK_SUM         17000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        6011
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6039
#define _APS_NEXT_SYMED_VALUE           6000
#endif
#endif
