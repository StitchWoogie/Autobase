// DialogSelectSfAndTag.cpp : implementation file
//

#include "stdafx.h"
#include "SECS_Host.h"
#include "SECS_HostDef.h"
#include "DialogSelectSfAndTag.h"
#include "..\..\catlib\CatTag9.h"
#include "..\..\catlib\CatTag.h"
#include ".\dialogselectsfandtag.h"



// CDialogSelectSfAndTag dialog

IMPLEMENT_DYNAMIC(CDialogSelectSfAndTag, CDialog)
CDialogSelectSfAndTag::CDialogSelectSfAndTag(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogSelectSfAndTag::IDD, pParent)
{
}

CDialogSelectSfAndTag::~CDialogSelectSfAndTag()
{
}

void CDialogSelectSfAndTag::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_SELECT_TAG, m_list);
	DDX_Control(pDX, IDC_COMBO_FUNCTION, m_comboStream);
	DDX_Control(pDX, IDC_COMBO_FUNCTION2, m_comboFunction);
}


BEGIN_MESSAGE_MAP(CDialogSelectSfAndTag, CDialog)
	ON_BN_CLICKED(IDC_RADIO_ANALOG_INPUT, OnBnClickedRadioAnalogInput)
	ON_BN_CLICKED(IDC_RADIO_DIGITAL_INPUT, OnBnClickedRadioDigitalInput)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_SELECT_TAG, OnNMDblclkListSelectTag)
END_MESSAGE_MAP()


// CDialogSelectSfAndTag message handlers

void CDialogSelectSfAndTag::checkCurrPos()
{
	if(m_currSel < 0 || m_currSel >= m_list.GetItemCount()) m_currSel = 0;
}

void CDialogSelectSfAndTag::GetCurrSelPosFromTagName()
{
	TagPublicStruct		*tp;
	DWORD				i, pos = 0, count = blockTagList9.GetCount();
	
	m_tagType = 2;
	m_currSel = 0;
	for(i = 0; i < count; i++) {
		tp = (TagPublicStruct*)blockTagList9.GetPtr(i);		
		if(strnicmp(tp->tag, mTagName, strlen(tp->tag)) == 0) {
			if(tp->nTagType == TAG_TYPE_AI) m_tagType = 0;
			else							m_tagType = 2;
			break;
		}
	}
	if(i >= count) return;

	for(i = 0; i < count; i++) {
		tp = (TagPublicStruct*)blockTagList9.GetPtr(i);
		if(isTagTypeMached(tp->nTagType)) {
			if(strnicmp(tp->tag, mTagName, strlen(tp->tag)) == 0) {
				m_currSel = pos;
				break;
			}
			pos++;			
		}
	}
}


bool CDialogSelectSfAndTag::isTagTypeMached(int nTagType)
{
	if(m_tagType == 0 && nTagType == TAG_TYPE_AI) return true;
	if(m_tagType == 2 && nTagType == TAG_TYPE_DI) return true;
	return false;
}

void CDialogSelectSfAndTag::GetCurrentTag()
{
	TagPublicStruct		*tp;
	char				buf[81];
	DWORD				i, pos = 0;
	
	m_list.DeleteAllItems();
	for(i = 0; i < blockTagList9.GetCount(); i++) {
		tp = (TagPublicStruct*)blockTagList9.GetPtr(i);
		if(isTagTypeMached(tp->nTagType)) {
			sprintf(buf, "%05d", pos);
			m_list.InsertItem(pos, buf);
			m_list.SetItemText(pos, 1, tp->tag);
			m_list.SetItemText(pos, 2, tp->description);
			pos++;			
		}
	}
}

int CDialogSelectSfAndTag::GetSelectPosition()
{
	int		i;

	for(i = 0; i < m_list.GetItemCount(); i++) {
		if(m_list.GetItemState(i, LVIS_SELECTED)) {
			return i;
		}
	}
	return -1;
}

BOOL CDialogSelectSfAndTag::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	int			i;
	char		imsi[10];

	GetCurrSelPosFromTagName();
	for(i = 0; i < MAX_STREAM_COUNT; i++) {
		sprintf(imsi, "%03d", i);
		m_comboStream.AddString(imsi);
	}
	m_comboStream.SetCurSel(m_stream%MAX_STREAM_COUNT);
	for(i = 0; i < MAX_FUNCTION_COUNT; i++) {
		sprintf(imsi, "%03d", i);
		m_comboFunction.AddString(imsi);
	}
	m_comboFunction.SetCurSel(m_function%MAX_FUNCTION_COUNT);

	m_list.InsertColumn(0, "No", LVCFMT_CENTER, 60);
	m_list.InsertColumn(1, "Tag Name", LVCFMT_LEFT, 200);
	m_list.InsertColumn(2, "Description", LVCFMT_LEFT, 200);
	if(m_tagType != 2) m_tagType = 0;
	CheckRadioButton(IDC_RADIO_ANALOG_INPUT, IDC_RADIO_STRING, IDC_RADIO_ANALOG_INPUT+m_tagType);
	GetCurrentTag();
	
	checkCurrPos();
	m_list.SetItemState(m_currSel, LVIS_SELECTED, LVIS_SELECTED);
	m_list.EnsureVisible(m_currSel, false);
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDialogSelectSfAndTag::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class
	m_stream = m_comboStream.GetCurSel();
	m_function = m_comboFunction.GetCurSel();

	//UpdateData(true);
	int			pos = GetSelectPosition();
	m_tagType = (IsDlgButtonChecked(IDC_RADIO_DIGITAL_INPUT)) ? 2 : 0;
	if(blockTagList9.GetCount() <= 0 || pos == -1) {
		MessageBox("Tag Selection Error.", "Selection Error");
		return;
	}
	m_list.GetItemText(pos, 1, mTagName, sizeof(mTagName));
	if((int)strlen(mTagName) <= 0) {
		MessageBox("Tag Name is Empty or Null.", "Tag Error");
		return;
	}
	CDialog::OnOK();
}

void CDialogSelectSfAndTag::OnBnClickedRadioAnalogInput()
{
	// TODO: Add your control notification handler code here
	if(m_tagType == 0) return;

	m_tagType = 0;
	GetCurrentTag();
	checkCurrPos();
	m_list.SetItemState(m_currSel, LVIS_SELECTED, LVIS_SELECTED);
	m_list.EnsureVisible(m_currSel, false);
}

void CDialogSelectSfAndTag::OnBnClickedRadioDigitalInput()
{
	// TODO: Add your control notification handler code here
	if(m_tagType == 2) return;

	m_tagType = 2;
	GetCurrentTag();
	checkCurrPos();
	m_list.SetItemState(m_currSel, LVIS_SELECTED, LVIS_SELECTED);
	m_list.EnsureVisible(m_currSel, false);
}

void CDialogSelectSfAndTag::OnNMDblclkListSelectTag(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	*pResult = 0;
	OnOK();
}
