// DialogWaitOkTagSf.cpp : implementation file
//

#include "stdafx.h"
#include <io.h>
#include "SECS_Host.h"
#include "DialogWaitOkTagSf.h"
#include "SECS_HostDef.h"
#include "DialogSelectSfAndTag.h"
#include ".\dialogwaitoktagsf.h"

extern char sWorkDir[MAX_PATH];

// CDialogWaitOkTagSf dialog

IMPLEMENT_DYNAMIC(CDialogWaitOkTagSf, CDialog)
CDialogWaitOkTagSf::CDialogWaitOkTagSf(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogWaitOkTagSf::IDD, pParent)
{
}

CDialogWaitOkTagSf::~CDialogWaitOkTagSf()
{
}

void CDialogWaitOkTagSf::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_READ_SCHEDULE, m_list);
}


BEGIN_MESSAGE_MAP(CDialogWaitOkTagSf, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_EDIT, OnBnClickedButtonEdit)
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnBnClickedButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnBnClickedButtonDelete)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_READ_SCHEDULE, OnNMDblclkListReadSchedule)
END_MESSAGE_MAP()


// CDialogWaitOkTagSf message handlers

int CDialogWaitOkTagSf::GetSelectPosition()
{
	int		i;

	for(i = 0; i < m_list.GetItemCount(); i++) {
		if(m_list.GetItemState(i, LVIS_SELECTED)) {
			return i;
		}
	}

	return -1;
}

void CDialogWaitOkTagSf::getWaitOkTagFromFileToList()
{
	FILE				*in;
	CommaBlockString	comma;
	int					pos = 0;
	char				filename[MAXPATH], imsi[81];// changed 2016-09-13, imsi[40] -> size[81]
	CString				buf;
	BYTE				sf;
	
	//for(int i = 0; i < MAX_WAIT_OK_TAG; i++) localVars->waitOkData[i].cUse = 0;

	sprintf(filename, "%s\\SCAN\\waitOk%03d.ini", sWorkDir, ptNo);
	in = fopen(filename, "rb");
	if(in == NULL) return;

	while(TextGetOneLine(in, buf)) {
		if(buf.GetLength() <= 0) continue;
		if(pos >= MAX_WAIT_OK_TAG) break;

		comma.Set(buf);
		comma.GetBYTE(sf);
		sprintf(imsi, "%03d", sf);
		m_list.InsertItem(pos, imsi);
		if(comma.IsEOS()) {
			pos++;
			continue;
		}
		comma.GetBYTE(sf);
		sprintf(imsi, "%03d", sf);
		m_list.SetItemText(pos, 1, imsi);
		if(comma.IsEOS()) {
			pos++;
			continue;
		}
		comma.GetString(imsi, (int)sizeof(imsi));
		m_list.SetItemText(pos, 2, imsi);
		pos++;
	}
	fclose(in);
}

BOOL CDialogWaitOkTagSf::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	m_list.InsertColumn(0, "Stream", LVCFMT_CENTER, 100);
	m_list.InsertColumn(1, "Function", LVCFMT_CENTER, 100);
	m_list.InsertColumn(2, "Tag", LVCFMT_CENTER, 250);
	getWaitOkTagFromFileToList();
	bChange = false;
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDialogWaitOkTagSf::saveWaitOkTagFromFileToList()
{
	FILE				*out;
	int					i, stream, function, count;
	char				filename[MAXPATH], imsi[81];// changed 2016-09-13, imsi[40] -> size[81]

	sprintf(filename, "%s\\SCAN\\waitOk%03d.ini", sWorkDir, ptNo);
	count = m_list.GetItemCount();
	if(count <= 0) {
		if(access(filename, 0) == 0) {
			DeleteFile(filename);
		}
		return;
	}		
	
	out = fopen(filename, "wb");
	if(out == NULL) {
		MessageBox("File writing Error.", "Writing Error");
		return;
	}
	for(i = 0; i < m_list.GetItemCount(); i++) {
		if(i >= MAX_WAIT_OK_TAG) break;
		m_list.GetItemText(i, 0, imsi, sizeof(imsi));
		stream = atoi(imsi);
		m_list.GetItemText(i, 1, imsi, sizeof(imsi));
		function = atoi(imsi);
		m_list.GetItemText(i, 2, imsi, sizeof(imsi));
		fprintf(out, "%d, %d, %s, %c%c", stream, function, imsi, 0x0D, 0x0A);		
	}
	fclose(out);
}

void CDialogWaitOkTagSf::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class
	if(bChange)	saveWaitOkTagFromFileToList();
	CDialog::OnOK();
}

void CDialogWaitOkTagSf::OnBnClickedButtonEdit()
{
	// TODO: Add your control notification handler code here
	CDialogSelectSfAndTag dialog;

	int pos = GetSelectPosition();
	if(pos == -1) return;
	
	getCurrReadData(pos, dialog);
	int retn = (int)dialog.DoModal();
	if(retn == IDOK) {
		char	imsi[20];
		sprintf(imsi, "%03d", dialog.m_stream);
		m_list.SetItemText(pos, 0, imsi);
		sprintf(imsi, "%03d", dialog.m_function);
		m_list.SetItemText(pos, 1, imsi);
		m_list.SetItemText(pos, 2, dialog.mTagName);
		bChange = true;
	}
}

void CDialogWaitOkTagSf::getCurrReadData(int pos, CDialogSelectSfAndTag &dialog)
{
	char				imsi[80];
	
	m_list.GetItemText(pos, 0, imsi, sizeof(imsi));
	dialog.m_stream = atoi(imsi);
	m_list.GetItemText(pos, 1, imsi, sizeof(imsi));
	dialog.m_function = atoi(imsi);
	m_list.GetItemText(pos, 2, imsi, sizeof(imsi));
	memset(dialog.mTagName, 0, sizeof(dialog.mTagName));
	int	len = (int)strlen(imsi);
	if(len < sizeof(dialog.mTagName)) len = sizeof(dialog.mTagName);
	if(len > 0)	memcpy(dialog.mTagName, imsi, len);
}

bool CDialogWaitOkTagSf::checkEqualStreamFunction(BYTE stream, BYTE function)
{
	int					i;
	char				imsi[20], imsi2[20];	

	for(i = 0; i <= MAX_WAIT_OK_TAG; i++) {
		m_list.GetItemText(i, 0, imsi, sizeof(imsi));
		m_list.GetItemText(i, 1, imsi2, sizeof(imsi2));
		if(atoi(imsi) == stream && atoi(imsi2) == function) return true;	
	}
	return false;
}

void CDialogWaitOkTagSf::OnBnClickedButtonAdd()
{
	// TODO: Add your control notification handler code here
	CDialogSelectSfAndTag dialog;

	if((m_list.GetItemCount() + 1) >= MAX_WAIT_OK_TAG) {
		MessageBox("Wait OK Tag Array Overflow.", "Array Overflow");
		return;
	}
	int pos = GetSelectPosition();	
	if(pos == -1) {
		dialog.m_stream = 1;// stream = 1
		dialog.m_function = 2;// stream = 2
		memset(dialog.mTagName, 0, sizeof(dialog.mTagName));
	}
	else {
		getCurrReadData(pos, dialog);
	}
	pos = m_list.GetItemCount();

	int retn = (int)dialog.DoModal();
	if(retn == IDOK) {
		if(checkEqualStreamFunction(dialog.m_stream, dialog.m_function)) {
			MessageBox("EqualStream/Function Exist.", "Stream/unction Input Error");
			return;
		}
		char	imsi[20];

		sprintf(imsi, "%03d", dialog.m_stream);
		m_list.InsertItem(pos, imsi);
		sprintf(imsi, "%03d", dialog.m_function);
		m_list.SetItemText(pos, 1, imsi);
		m_list.SetItemText(pos, 2, dialog.mTagName);
		bChange = true;
	}
}

void CDialogWaitOkTagSf::OnBnClickedButtonDelete()
{
	// TODO: Add your control notification handler code here
	int pos = GetSelectPosition();
	if(pos == -1) return;
	m_list.DeleteItem(pos);
	bChange = true;
}
void CDialogWaitOkTagSf::OnNMDblclkListReadSchedule(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	*pResult = 0;
	OnBnClickedButtonEdit();
}
