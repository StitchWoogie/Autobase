#include "stdafx.h"
#include "SECS_HostDef.h"

static void setWordVal(BYTE *data, WORD wVal)
{
	data[0] = HIBYTE(wVal);
	data[1] = LOBYTE(wVal);
}


static void setDwordVal(BYTE *data, DWORD dVal)
{
	setWordVal(data, HIWORD(dVal));
	setWordVal(&data[2], LOWORD(dVal));
}

static void setInt64Val(BYTE *data, unsigned __int64 i64Val)
{
	setDwordVal(data, (DWORD)(i64Val >> 32));
	setDwordVal(&data[4], (DWORD)i64Val);
}

static void setFloat32Val(BYTE *data, float fVal)
{
	char	imsi[10];
	int		i, pos = 7;

	memcpy(imsi, &fVal, 4);
	for(i = 0, pos = 3; i < 4; i++, pos--) data[i] = imsi[pos % 4];
}

static void setFloat64Val(BYTE *data, double dVal)
{
	char	imsi[10];
	int		i, pos = 7;

	memcpy(imsi, &dVal, 8);
	for(i = 0, pos = 7; i < 8; i++, pos--) data[i] = imsi[pos % 8];
}


int getSecsDataTypeNo(char *data)
{
	for(int i = 0; i < MAX_ITEM_TYPE; i++) if(_strnicmp(data, itemType_buf[i], (int)strlen(itemType_buf[i])) == 0) return i;
	return MAX_ITEM_TYPE;
}

int getSecsDataType(char *data)
{
	int		no = getSecsDataTypeNo(data);
	switch(no) {
		case 0 : return DATA_TYPE_LIST;
		case 1 : return DATA_TYPE_BINARY;
		case 2 : return DATA_TYPE_BOOLEAN;
		case 3 : return DATA_TYPE_ASCII;
		case 4 : return DATA_TYPE_JIS_8;
		case 5 : return DATA_TYPE_1_BYTE_SIGN_INTEGER;
		case 6 : return DATA_TYPE_2_BYTE_SIGN_INTEGER;
		case 7 : return DATA_TYPE_4_BYTE_SIGN_INTEGER;
		case 8 : return DATA_TYPE_8_BYTE_SIGN_INTEGER;
		case 9 : return DATA_TYPE_1_BYTE_UNSIGN_INTEGER;
		case 10 : return DATA_TYPE_2_BYTE_UNSIGN_INTEGER;
		case 11 : return DATA_TYPE_4_BYTE_UNSIGN_INTEGER;
		case 12 : return DATA_TYPE_8_BYTE_UNSIGN_INTEGER;
		case 13 : return DATA_TYPE_4_BYTE_FLOAT;
		case 14 : return DATA_TYPE_8_BYTE_FLOAT;
		default : break;
	}
	return DATA_UNKNOWN_TYPE;
}

int getSecsDataNoToDataType(int no)
{
	switch(no) {
		case 0 : return DATA_TYPE_LIST;
		case 1 : return DATA_TYPE_BINARY;
		case 2 : return DATA_TYPE_BOOLEAN;
		case 3 : return DATA_TYPE_ASCII;
		case 4 : return DATA_TYPE_JIS_8;
		case 5 : return DATA_TYPE_1_BYTE_SIGN_INTEGER;
		case 6 : return DATA_TYPE_2_BYTE_SIGN_INTEGER;
		case 7 : return DATA_TYPE_4_BYTE_SIGN_INTEGER;
		case 8 : return DATA_TYPE_8_BYTE_SIGN_INTEGER;
		case 9 : return DATA_TYPE_1_BYTE_UNSIGN_INTEGER;
		case 10 : return DATA_TYPE_2_BYTE_UNSIGN_INTEGER;
		case 11 : return DATA_TYPE_4_BYTE_UNSIGN_INTEGER;
		case 12 : return DATA_TYPE_8_BYTE_UNSIGN_INTEGER;
		case 13 : return DATA_TYPE_4_BYTE_FLOAT;
		case 14 : return DATA_TYPE_8_BYTE_FLOAT;
		default : break;
	}
	return DATA_UNKNOWN_TYPE;
}

int getDataTypeToBufNo(int nDataType)
{
	switch(nDataType) {
		case DATA_TYPE_LIST : return 0;
		case DATA_TYPE_BINARY : return 1;
		case DATA_TYPE_BOOLEAN : return 2;
		case DATA_TYPE_ASCII : return 3;
		case DATA_TYPE_JIS_8 : return 4;
		case DATA_TYPE_1_BYTE_SIGN_INTEGER : return 5;
		case DATA_TYPE_2_BYTE_SIGN_INTEGER : return 6;
		case DATA_TYPE_4_BYTE_SIGN_INTEGER : return 7;
		case DATA_TYPE_8_BYTE_SIGN_INTEGER : return 8;
		case DATA_TYPE_1_BYTE_UNSIGN_INTEGER : return 9;
		case DATA_TYPE_2_BYTE_UNSIGN_INTEGER : return 10;
		case DATA_TYPE_4_BYTE_UNSIGN_INTEGER : return 11;
		case DATA_TYPE_8_BYTE_UNSIGN_INTEGER : return 12;
		case DATA_TYPE_4_BYTE_FLOAT : return 13;
		case DATA_TYPE_8_BYTE_FLOAT : return 14;
		default : break;
	}
	return 15;
}

bool isAsciiData(int nDataType)
{
	switch(nDataType) {
		case DATA_TYPE_ASCII :
		case DATA_TYPE_JIS_8 : return true;
	}
	return false;
}

bool isGetTagData(char *buf)
{
	int		len = (int)strlen(buf);
	if(len <= 2) return false; // \ + $ + tag name �ּ� 1 = 3

	if(buf[0] == '\\' && buf[1] == '$') return true;
	return false;
}

bool setOneTagStringData(SECS_ONE_DATA *data, char *buf)
{
	int		len = (int)strlen(buf);
	
	data->bTagVal = true;
	if(len <= 2) return false;
	if(data->bTagVal) {
		if(len > 81) len = 81;//, changed 2016-09-13, 41 -> 81
		memcpy(data->tag, &buf[2], len-2);
		data->tag[len-2] = 0;
	}		
	return true;
}

bool setOneTagData(SECS_ONE_DATA *data, char *buf, int nDataType)
{
	int		len = (int)strlen(buf);
	
	data->bTagVal = isGetTagData(buf);
	if(len <= 0) return false;
	if(data->bTagVal) {
		setOneTagStringData(data, buf);
		return true;
	}
	switch(nDataType) {
		case DATA_TYPE_BINARY : data->val[0] = (BYTE)atoi(buf); return true;
		case DATA_TYPE_BOOLEAN : data->val[0] = (atoi(buf)) ? true : false; return true;
		case DATA_TYPE_8_BYTE_SIGN_INTEGER : 
		case DATA_TYPE_8_BYTE_UNSIGN_INTEGER : setInt64Val(data->val, _atoi64(buf)); return true;
		case DATA_TYPE_1_BYTE_SIGN_INTEGER : 
		case DATA_TYPE_1_BYTE_UNSIGN_INTEGER : data->val[0] = (BYTE)atoi(buf); return true;
		case DATA_TYPE_2_BYTE_SIGN_INTEGER :
		case DATA_TYPE_2_BYTE_UNSIGN_INTEGER : setWordVal(data->val, (WORD)atoi(buf)); return true;
		case DATA_TYPE_4_BYTE_SIGN_INTEGER : 
		case DATA_TYPE_4_BYTE_UNSIGN_INTEGER : setDwordVal(data->val, (DWORD)atol(buf)); return true;
		case DATA_TYPE_8_BYTE_FLOAT : setFloat64Val(data->val, (float)atof(buf)); return true;
		case DATA_TYPE_4_BYTE_FLOAT : setFloat32Val(data->val, (float)atof(buf)); return true;
		default : return false;
	}
	return true;
}

bool getStreamFunctionData(char *device, BYTE &cStream, BYTE &cFunction)
{	
	cStream = 0x01;
	cFunction = 0x01;
	if(strlen(device) <= 0) return false;

	CommaBlockString	comma;
	int					imsi;
	
	comma.Set(device);
	comma.SetBlockCode('.');
	if(comma.IsEOS()) return false;
	comma.GetInt(imsi);
	if(imsi >= 0 && imsi <= 255) cStream = imsi;
	
	if(comma.IsEOS()) return false;
	comma.GetInt(imsi);
	if(imsi >= 0 && imsi <= 255) cFunction = imsi;
	return true;
}

bool getStreamFunctionNoFormFile(FILE *in, BYTE &cStream, BYTE &cFunction)
{
	int					pos = 0;
	char				buf[50];
	
	while(TextGetOneLine(in, buf, sizeof(buf))) {
		pos++;
		if(pos > 2000) return false;		// changed 2016-08-26, 1000->2000
		if((int)strlen(buf) <= 0) continue;
		if(getStreamFunctionData(buf, cStream, cFunction)) break;
	}
	return true;
}

bool getOneRealSfData(SECS_REAL_DATA *realData, char *buf, int nDataType, int nDataSize)
{
	CommaBlockString	comma;
	CString				imsi;
	int					i, len;
	bool				bTag;
	
	if(nDataSize <= 0) return false;
	comma.Set(buf);
	if(comma.IsEOS()) return false;
	comma.GetString(imsi);// data type
	if(comma.IsEOS()) return false;
	comma.GetString(imsi);// data size
	
	realData->nDataType = nDataType;
	realData->nDataCount = 0;
	switch(nDataType) {
		case DATA_TYPE_ASCII :
		case DATA_TYPE_JIS_8 :
			if(comma.IsEOS()) return false;
			comma.GetString(imsi);// data size
			len = imsi.GetLength();
			if(len <= 0) return false;

			realData->data = new SECS_ONE_DATA[1];
			memset(realData->data, 0, sizeof(realData->data));
			bTag = isGetTagData((char *)imsi.GetString());
			if(bTag) {
				realData->nDataCount = nDataSize;
				realData->data->string = new BYTE[nDataSize+1];
				realData->data->string[0] = 0;
				setOneTagStringData(&realData->data[0], (char *)imsi.GetString());
			}
			else {
				realData->nDataCount = len;
				realData->data->string = new BYTE[len+1];
				memcpy(realData->data->string, (char *)imsi.GetString(), len);
				realData->data->string[len] = 0;
			}
			realData->data->bTagVal = bTag;
			return true;
		case DATA_TYPE_BINARY :			
		case DATA_TYPE_BOOLEAN :
		case DATA_TYPE_8_BYTE_SIGN_INTEGER :
		case DATA_TYPE_1_BYTE_SIGN_INTEGER :
		case DATA_TYPE_2_BYTE_SIGN_INTEGER :
		case DATA_TYPE_4_BYTE_SIGN_INTEGER :
		case DATA_TYPE_8_BYTE_FLOAT :
		case DATA_TYPE_4_BYTE_FLOAT :
		case DATA_TYPE_8_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_1_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_2_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_4_BYTE_UNSIGN_INTEGER :
			realData->nDataCount = nDataSize;
			realData->data = new SECS_ONE_DATA[nDataSize];
			memset(realData->data, 0, sizeof(realData->data));
			for(i = 0; i < nDataSize; i++) {
				if(comma.IsEOS()) return true;
				comma.GetString(imsi);// data size
				setOneTagData(&realData->data[i], (char *)imsi.GetString(), nDataType);
			}
			return true;
	}
	return true;
}

bool getOneListData(SECS_DATA *listData, FILE *in, int &pos)
{
	CommaBlockString	comma;
	int					i, nDataType, nDataSize;
	CString				buf, imsi;
	
	while(TextGetOneLine(in, buf)) {
		if(pos++ > 2000) return false;		// changed 2016-08-26, 1000->2000
		if(buf.GetLength() <= 0) continue;

		comma.Set(buf);
		if(comma.IsEOS()) continue;
		comma.GetString(imsi);
		if(imsi.GetLength() <= 0) continue;
		nDataType = getSecsDataType((char *)imsi.GetString());
		if(nDataType == DATA_UNKNOWN_TYPE) continue;
		if(comma.IsEOS()) continue;
		comma.GetInt(nDataSize);
		if(nDataType == DATA_TYPE_LIST) {
			if(nDataSize < 0) continue;
		}
		else {
			if(nDataSize <= 0) continue;
		}
		
		listData->nDataType = nDataType;
		if(nDataType == DATA_TYPE_LIST) {
			listData->nList = nDataSize;
			if(nDataSize > 0) {
				listData->list = (SECS_DATA *)calloc(nDataSize, sizeof(struct SECS_DATA));
				for(i = 0; i < nDataSize; i++) getOneListData((SECS_DATA *)&listData->list[i], in, pos);
			}
		}
		else {
			listData->nList = 0;
			getOneRealSfData(&listData->realData, (char *)buf.GetString(), nDataType, nDataSize);
		}
		break;
	}
	return true;
}



bool getStreamFunctionFileReal(STREAM_FUNCTION_DATA *sf, int ptNo, int no)
{
	FILE				*in;
	CommaBlockString	comma;
	int					i, pos = 0, nDataType, nDataSize;
	char				filename[MAXPATH];
	CString				buf, imsi;
	
	sprintf(filename, "%s\\SCAN\\%03d\\SF%03d.ini", sWorkDir, ptNo, no);
	in = fopen(filename, "rb");
	if(in == NULL) return false;
	if(getStreamFunctionNoFormFile(in, sf->cStream, sf->cFunction) == false) {
		fclose(in);	
		return false;
	}

	while(TextGetOneLine(in, buf)) {		
		if(pos++ > 2000) break;		// changed 2016-08-26, 1000->2000
		if(buf.GetLength() <= 0) continue;

		comma.Set(buf);
		if(comma.IsEOS()) continue;
		comma.GetString(imsi);
		if(imsi.GetLength() <= 0) continue;
		nDataType = getSecsDataType((char *)imsi.GetString());
		if(nDataType == DATA_UNKNOWN_TYPE) continue;
		if(comma.IsEOS()) continue;
		comma.GetInt(nDataSize);
		if(nDataType == DATA_TYPE_LIST) {
			if(nDataSize < 0) continue;
		}
		else {
			if(nDataSize <= 0) continue;
		}
		
		sf->nDataType = nDataType;
		if(nDataType == DATA_TYPE_LIST) {
			sf->nList = nDataSize;
			if(nDataSize > 0) {
				sf->list = (SECS_DATA *)calloc(nDataSize, sizeof(struct SECS_DATA));			
				for(i = 0; i < nDataSize; i++) getOneListData((SECS_DATA *)&sf->list[i], in, pos);
			}
		}
		else {
			sf->nList = 0;
			getOneRealSfData(&sf->realData, (char *)buf.GetString(), nDataType, nDataSize);			
		}
		sf->bExist = true;
		sf->bChange = false;
		sf->nFileNo = no;
	}
	fclose(in);	
	return true;
}



CString setStringDataDeleteEmptyData(CString data)
{
	CString		buf = "";
	if((int)strlen(data) <= 0) return buf;

	CommaBlockString	comma;
	CString				imsi = "";
	int					pos = 0;
	
	comma.Set(data);
	comma.SetBlockCode(',');
	while(1) {
		if(comma.IsEOS()) return buf;
		comma.GetString(imsi);
		if(imsi.GetLength() <= 0) continue;
		if(pos == 0) buf = imsi;
		else buf.AppendFormat(", %s", imsi);
		if(pos >= MAX_ARRAY_COUNT) return buf;
		pos++;
	}
	return buf;
}

int getStringToItemCount(CString data)
{
	if((int)strlen(data) <= 0) return 0;

	CommaBlockString	comma;
	char				imsi[20];
	
	comma.Set(data);
	comma.SetBlockCode('(');
	if(comma.IsEOS()) return 0;
	comma.GetString(imsi, sizeof(imsi));
	if(comma.IsEOS()) return 0;
	comma.GetString(imsi, sizeof(imsi));
	return atoi(imsi);
}

int getStringToItemCountToBuf(CString data, int nDataNo)
{
	int			len = (int)strlen(data);
	if(len <= 0) return 0;
	if(isAsciiData(getSecsDataNoToDataType(nDataNo))) return len;

	CommaBlockString	comma;
	char				imsi[20];
	int					count = 0;
	
	comma.Set(data);
	comma.SetBlockCode(',');
	while(1) {
		if(comma.IsEOS() || count >= MAX_ARRAY_COUNT) return count;
		comma.GetString(imsi, sizeof(imsi));
		count++;
	}
	return count;
}

bool getStringToDataValue(CString data, CString &val)
{
	if((int)strlen(data) <= 0) return false;

	CommaBlockString	comma;
	
	comma.Set(data);
	comma.SetBlockCode('=');
	if(comma.IsEOS()) return false;
	comma.GetString(val);
	if(comma.IsEOS()) return false;
	comma.GetString(val);		
	return true;
}

void setDefaultSfData(STREAM_FUNCTION_DATA *sf, int pos, BYTE cStream, BYTE cFunction)
{
	sf->bExist = true;
	sf->cStream = cStream;
	sf->cFunction = cFunction;
	sf->nList = 0;
	sf->nDataType = 0;// LIST
	sf->nFileNo = pos % MAX_STREAM_FUNCTION_DATA;
}


void getReadvalueString(SECS_REAL_DATA *list, CString *data, bool bTree)
{
	int			i;
	switch(list->nDataType)
	{
		case DATA_TYPE_BINARY :
		case DATA_TYPE_BOOLEAN :
		case DATA_TYPE_1_BYTE_SIGN_INTEGER : 
		case DATA_TYPE_1_BYTE_UNSIGN_INTEGER : 
			for(i = 0; i < list->nDataCount; i++) {
				if(i == 0 && bTree) data->AppendFormat(" = ");
				else data->AppendFormat(", ");
				if(list->data[i].bTagVal == true) data->AppendFormat("\\$%s", list->data[i].tag);
				else data->AppendFormat("%1d", list->data[i].val[0]);
			}
			break;
		case DATA_TYPE_ASCII : 			
		case DATA_TYPE_JIS_8 : 
			if(bTree) data->AppendFormat(" = ");
			else data->AppendFormat(", ");
			if(list->data[0].bTagVal == true) data->AppendFormat("\\$%s", list->data[0].tag);
			else data->AppendFormat("%s", list->data->string);
			break;
		case DATA_TYPE_2_BYTE_SIGN_INTEGER : 
		case DATA_TYPE_2_BYTE_UNSIGN_INTEGER : 
			for(i = 0; i < list->nDataCount; i++) {
				if(i == 0 && bTree) data->AppendFormat(" = ");
				else data->AppendFormat(", ");
				if(list->data[i].bTagVal == true) data->AppendFormat("\\$%s", list->data[i].tag);
				else data->AppendFormat("%1d", getWordVal(list->data[i].val));
			}
			break;
		case DATA_TYPE_4_BYTE_SIGN_INTEGER :
		case DATA_TYPE_4_BYTE_UNSIGN_INTEGER : 
			for(i = 0; i < list->nDataCount; i++) {
				if(i == 0 && bTree) data->AppendFormat(" = ");
				else data->AppendFormat(", ");
				if(list->data[i].bTagVal == true) data->AppendFormat("\\$%s", list->data[i].tag);
				else data->AppendFormat("%1ld", getDwordVal(list->data[i].val));
			}
			break;		
		case DATA_TYPE_8_BYTE_UNSIGN_INTEGER : 
		case DATA_TYPE_8_BYTE_SIGN_INTEGER : 
			for(i = 0; i < list->nDataCount; i++) {
				if(i == 0 && bTree) data->AppendFormat(" = ");
				else data->AppendFormat(", ");
				if(list->data[i].bTagVal == true) data->AppendFormat("\\$%s", list->data[i].tag);
				else data->AppendFormat("%1ld", get8ByteVal(list->data[i].val));
			}
			break;
		case DATA_TYPE_4_BYTE_FLOAT : 
			for(i = 0; i < list->nDataCount; i++) {
				if(i == 0 && bTree) data->AppendFormat(" = ");
				else data->AppendFormat(", ");
				if(list->data[i].bTagVal == true) data->AppendFormat("\\$%s", list->data[i].tag);
				else data->AppendFormat("%1f", getFloat4Val(list->data[i].val));
			}
			break;
		case DATA_TYPE_8_BYTE_FLOAT : 
			for(i = 0; i < list->nDataCount; i++) {
				if(i == 0 && bTree) data->AppendFormat(" = ");
				else data->AppendFormat(", ");
				if(list->data[i].bTagVal == true) data->AppendFormat("\\$%s", list->data[i].tag);
				else data->AppendFormat("%1f", getFloat8Val(list->data[i].val));
			}
			break;
		default : 
			data->Format("");;
			break;
	}
}


bool saveOneRealSfData(FILE	*out, SECS_REAL_DATA *list)
{
	CString	data;	
	int		pos = getDataTypeToBufNo(list->nDataType);
	if(pos < 0 || pos >= MAX_ITEM_TYPE) return false;

	data.Format("%s, %1d", itemType_buf[pos % MAX_ITEM_TYPE], list->nDataCount);
	getReadvalueString(list, &data, false);
	fprintf(out, "%s%c%c", data, CR, LF);
	return true;
}

void saveOneSfMemoryDataToFile(FILE	*out, SECS_DATA *list)
{
	int				i;
	
	if(list->nDataType == DATA_TYPE_LIST) {
		if(list->nList >= 0) fprintf(out, "%s, %1d%c%c", itemType_buf[0], list->nList, CR, LF);
		for(i = 0; i < list->nList; i++) saveOneSfMemoryDataToFile(out, (SECS_DATA *)&list->list[i]);
	}
	else saveOneRealSfData(out, &list->realData);
}

bool saveOneSfDataToFile(STREAM_FUNCTION_DATA *sf, char *filename)
{
	if(sf->nDataType == DATA_TYPE_LIST && sf->nList < 0) return false;
	if(sf->nDataType == DATA_UNKNOWN_TYPE) return false;

	FILE	*out = fopen(filename, "wb");
	if(out == NULL) return false;

	fprintf(out, "%1d.%1d%c%c", sf->cStream, sf->cFunction, CR, LF);
	if(sf->nDataType == DATA_TYPE_LIST) {
		if(sf->nList >= 0) fprintf(out, "%s, %1d%c%c", itemType_buf[0], sf->nList, CR, LF);
		for(int i = 0; i < sf->nList; i++) saveOneSfMemoryDataToFile(out, &sf->list[i]);
	}
	else saveOneRealSfData(out, &sf->realData);
	fclose(out);
	return true;
}

bool getOneRealSfDataWithoutHeader(SECS_REAL_DATA *realData, char *buf, int nDataType, int nDataSize)
{
	CommaBlockString	comma;
	CString				imsi;
	int					i, len;
	bool				bTag;
	
	if(nDataSize <= 0) return false;
	comma.Set(buf);
	if(comma.IsEOS()) return false;
	realData->nDataType = nDataType;
	realData->nDataCount = 0;
	switch(nDataType) {
		case DATA_TYPE_ASCII :
		case DATA_TYPE_JIS_8 :
			if(comma.IsEOS()) return false;
			comma.GetString(imsi);// data size
			len = imsi.GetLength();
			if(len <= 0) return false;

			realData->data = new SECS_ONE_DATA[1];
			memset(realData->data, 0, sizeof(realData->data));
			bTag = isGetTagData((char *)imsi.GetString());
			if(bTag) {
				realData->nDataCount = nDataSize;
				realData->data->string = new BYTE[nDataSize+1];
				realData->data->string[0] = 0;
				setOneTagStringData(&realData->data[0], (char *)imsi.GetString());
			}
			else {
				realData->nDataCount = len;
				realData->data->string = new BYTE[len+1];
				memcpy(realData->data->string, imsi, (int)strlen(imsi));
				realData->data->string[len] = 0;
			}
			realData->data->bTagVal = bTag;
			return true;
		case DATA_TYPE_BINARY :			
		case DATA_TYPE_BOOLEAN :
		case DATA_TYPE_8_BYTE_SIGN_INTEGER :
		case DATA_TYPE_1_BYTE_SIGN_INTEGER :
		case DATA_TYPE_2_BYTE_SIGN_INTEGER :
		case DATA_TYPE_4_BYTE_SIGN_INTEGER :
		case DATA_TYPE_8_BYTE_FLOAT :
		case DATA_TYPE_4_BYTE_FLOAT :
		case DATA_TYPE_8_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_1_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_2_BYTE_UNSIGN_INTEGER :
		case DATA_TYPE_4_BYTE_UNSIGN_INTEGER :
			realData->nDataCount = nDataSize;
			realData->data = new SECS_ONE_DATA[nDataSize];
			memset(realData->data, 0, sizeof(realData->data));
			for(i = 0; i < nDataSize; i++) {
				if(comma.IsEOS()) return true;
				comma.GetString(imsi);// data size
				setOneTagData(&realData->data[i], (char *)imsi.GetString(), nDataType);
			}
			return true;
	}
	return true;
}

WORD getWordVal(BYTE *data)
{
	return (WORD)data[0] * 0x100L + (WORD)data[1];
}


DWORD getDwordVal(BYTE *data)
{
	return (DWORD)data[0] * 0x1000000L + (DWORD)data[1] * 0x10000L + (DWORD)data[2] * 0x100L + (DWORD)data[3];
}

_int64 get8ByteVal(BYTE *data)
{
	return (_int64)getDwordVal(data) * 0x100000000L + (_int64)getDwordVal(&data[4]);
}

float getFloat4Val(BYTE *data)
{
	DWORD	val = getDwordVal(data);
	float	fVal;

	memcpy(&fVal, &val, 4);
	return fVal;
}

double getFloat8Val(BYTE *data)
{
	unsigned __int64	val = get8ByteVal(data);
	double				dVal;

	memcpy(&dVal, &val, 8);
	return dVal;
}

double getStringDoulbeVal(BYTE *data, WORD size)
{
	if(size <= 0) return 0.0;

	char		imsi[50];

	if(size >= 50) size = 49;
	memcpy(imsi, data, size);
	imsi[size] = 0;
	return atof(imsi);
}

void PokeValueAll(LOCAL_PORT_STRUCT *pt, int target, double val)
{
	PokeWORD(pt, target, (WORD)val);
	PokeDWORD(pt, target, (DWORD)val);
	PokeFLOAT(pt, target, (float)val);
	PokeDOUBLE(pt, target, (double)val);
	PokeINT64(pt, target, (_int64)val);
}

void PokeValueAll(LOCAL_PORT_STRUCT *pt, int target, WORD val)
{
	PokeWORD(pt, target, (WORD)val);
	PokeDWORD(pt, target, (DWORD)val);
	PokeFLOAT(pt, target, (float)val);
	PokeDOUBLE(pt, target, (double)val);
	PokeINT64(pt, target, (_int64)val);
}

void PokeValueAll(LOCAL_PORT_STRUCT *pt, int target, DWORD val)
{
	PokeWORD(pt, target, (WORD)val);
	PokeDWORD(pt, target, (DWORD)val);
	PokeFLOAT(pt, target, (float)val);
	PokeDOUBLE(pt, target, (double)val);
	PokeINT64(pt, target, (_int64)val);
}

void PokeValueAll(LOCAL_PORT_STRUCT *pt, int target, _int64 val)
{
	PokeWORD(pt, target, (WORD)val);
	PokeDWORD(pt, target, (DWORD)val);
	PokeFLOAT(pt, target, (float)val);
	PokeDOUBLE(pt, target, (double)val);
	PokeINT64(pt, target, (_int64)val);
}

void PokeValueAllAscii(LOCAL_PORT_STRUCT *pt, int target, BYTE *data, WORD size)
{
	char	buf[201];
	
	if(size <= 0) return;
	if(size > 200) 
		size = 200;
	memcpy(buf, data, size);
	buf[size] = 0;
	PokeSTRING(pt, target, buf);

	double		val = atof(buf);
	PokeWORD(pt, target, (WORD)val);
	PokeDWORD(pt, target, (DWORD)val);
	PokeFLOAT(pt, target, (float)val);
	PokeDOUBLE(pt, target, (double)val);
	PokeINT64(pt, target, (_int64)val);
}
