#pragma once
#include "afxcmn.h"
#include "SECS_HostDef.h"
#include "DialogEditAddSfData.h"
#include "afxwin.h"


// CDialogSfEditMain dialog

class CDialogSfEditMain : public CDialog
{
	DECLARE_DYNAMIC(CDialogSfEditMain)

public:
	CDialogSfEditMain(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDialogSfEditMain();

// Dialog Data
	enum { IDD = IDD_DIALOG_SF_EDIT_MAIN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();


	int GetSelectPosition();
	HTREEITEM GetSelectPositionTree();
	void getCurrReadData(CDialogEditAddSfData &dialog);
	void setOkReadData(CDialogEditAddSfData &dialog);

	//bool getStreamFunctionFileReal2(int no);
	void getStreamFunctionFile2();
	void deleteSfMemoryOne2(int no);
	void deleteSfMemory2();
	void getOneListDataFromTree(SECS_DATA *listData, HTREEITEM hItem, int &pos);
	bool getStreamFunctionTreeToMemory(int no);
	bool getTreeAllDataValue(HTREEITEM	hItem, int &nDataType, int &nDataSize, CString &buf);
	bool checkEqualStreamFunction(BYTE stream, BYTE function);
	int  getNextValidBufPos(int &stream, int &function);
	void setSfDataToList();
	void setSfDataToTree();
	void EnableDisable();
	void setTreeExpandAndCheckOneNode(HTREEITEM hItemParent);
	void setTreeExpandAndCheck();
	void setTreeExpandAndCheckCurr();
	HTREEITEM setOneDataTreeReal(HTREEITEM hItem, char *data, int nIndex);
	HTREEITEM addOneListDataTree(HTREEITEM hItem, int nDataSize, int nIndex);
	HTREEITEM addOneRealDataTree(HTREEITEM hItem, int nItemNo, CString val, int nIndex);
	void updateListDataTreeCount(HTREEITEM hItem, int inc);
	void updateListDataTreeRealData(HTREEITEM hItem, CString val);
	HTREEITEM addOneDataTree(HTREEITEM hItem, SECS_REAL_DATA *list, int pos);
	void makeSfMemoryDataTree(SECS_DATA *list, HTREEITEM hItem, int nIndex);
	//void getReadvalueString(SECS_REAL_DATA *list, CString *data);
	int getListPosToFileNo();
	int getValidSfMemory();
	void saveOrDeleteSfDataFile();

	void GetCurrentTag(int no);
	DWORD SearchTagNamePos();
	int GetSelectPositionTag();
	
	int		m_nPort;
	int		nReadStreamFunction;
	int		m_nMemPos;
	int		m_currPos;
	int		m_bChangeCurrTree;
	int		m_itemNo;
	int		m_itemNoAdd;
	DWORD	tagPos;
	int		nRadioSelection;
	CString m_tagName;
	CString m_itemCount;

	CComboBox m_itemType;
	CString m_itemValue;
	CListCtrl m_list;
	CTreeCtrl m_tree;
	CListCtrl m_tagList;
	CComboBox m_comboItemAdd;

protected:
	virtual void OnOK();
public:	
	afx_msg void OnBnClickedButtonEdit();
	afx_msg void OnBnClickedButtonAdd();
	afx_msg void OnBnClickedButtonDelete();
	afx_msg void OnNMDblclkListReadSchedule(NMHDR *pNMHDR, LRESULT *pResult);	
	afx_msg void OnTvnSelchangedTreeSfEdit(NMHDR *pNMHDR, LRESULT *pResult);	
	afx_msg void OnBnClickedButtonEditData();
	afx_msg void OnBnClickedButtonAddData();
	afx_msg void OnBnClickedButtonDeleteData();
	afx_msg void OnBnClickedButtonUpdateData();	
	afx_msg void OnCbnSelchangeComboItemType();	
	afx_msg void OnBnClickedRadioAnalogInput();
	afx_msg void OnBnClickedRadioAnalogOutput();
	afx_msg void OnBnClickedRadioDigitalInput();
	afx_msg void OnBnClickedRadioDigitalOutput();
	//afx_msg void OnBnClickedRadioStringTag();
	afx_msg void OnBnClickedButtonTagValueAdd();
	afx_msg void OnNMDblclkListTag(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMClickListReadSchedule(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedRadioTagString();
};
