// SECS_Host.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "SECS_Host.h"
#include "SECS_HostDef.h"

#include "DialogProtocolOption.h"
//#include "..\..\catlib\CatTag9.h"	// deleted 2016-09-22
//#include "..\..\catlib\CatTag.h"	// deleted 2016-09-22
#include "CatTag9.h"				// added 2016-09-22


char sWorkDir[MAX_PATH];


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

// CSECS_HostApp

BEGIN_MESSAGE_MAP(CSECS_HostApp, CWinApp)
END_MESSAGE_MAP()


// CSECS_HostApp construction

CSECS_HostApp::CSECS_HostApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CSECS_HostApp object

CSECS_HostApp theApp;


// CSECS_HostApp initialization

BOOL CSECS_HostApp::InitInstance()
{
	CWinApp::InitInstance();

	return TRUE;
}


extern "C" void DLLEXPORT ProtocolGetDriverTitle(char *title)
{
	strcpy(title, "SECS Host/Equipmemt");
}



static void getInitParameter(LOCAL_PORT_STRUCT *pt)
{
	CommaBlockString	comma;
	WORD				imsi;
	
	if(strlen(pt->sScanProtocolOption) > 0) {
		comma.Set(pt->sScanProtocolOption);	
		if(comma.IsEOS()) return;
		comma.GetWORD(imsi);
		localVars->bEquip = (imsi == 0) ? false : true;
		if(comma.IsEOS()) return;

		comma.GetWORD(imsi);
		localVars->bHsms = (imsi == 0) ? false : true;
		if(comma.IsEOS()) return;

		comma.GetWORD(imsi);
		localVars->nLinkTestTimeout = (imsi < 2 || imsi > 10000) ? 10 : imsi;
		if(comma.IsEOS()) return;

		comma.GetWORD(imsi);
		localVars->bUseConflictSolution = (imsi == 0) ? false : true;
		if(comma.IsEOS()) return;

		comma.GetWORD(imsi);
		localVars->bWaitSendOkSignal = (imsi == 0) ? false : true;
		if(comma.IsEOS()) return;

		//comma.GetWORD(imsi);
		//localVars->nResponseOkMemoryPos = (imsi > 65535) ? 2000 : imsi;// deleted by kdy 2014-11-07
		//if(comma.IsEOS()) return;
		
		comma.GetWORD(imsi);
		localVars->nResponseCheckTimeout = (imsi < 100 || imsi > 10000) ? 2000 : imsi;
		if(comma.IsEOS()) return;

		comma.GetString(localVars->sResponseOkTag, sizeof(localVars->sResponseOkTag));// added by kdy 2014-11-07
		if(comma.IsEOS()) return;

		comma.GetWORD(imsi);
		localVars->bSaveHeaderData = (imsi == 0) ? false : true; // add 2016-11-22 for stream, function, tns saving
		if(comma.IsEOS()) return;
	}
}

static void setStartTimeOutValue(LOCAL_PORT_STRUCT *pt)
{
	int					i, hap;
	SCAN_METHOD_STRUCT	*sm;
	
	hap = pt->nScanMethodHap;
	if(hap > MAX_READ_SCHEDULE) hap = MAX_READ_SCHEDULE;
	
	for(i = 0; i < hap; i++) {
		sm = &pt->scanMethod[i];
		if(sm->active == false || sm->extra2 == 0) continue;		
		localVars->timeout[i].SetTime(sm->extra2);
	}	
}

void getWaitOkTagFromFile(LOCAL_PORT_STRUCT *pt)// add by kdy 2014-11-19
{
	FILE				*in;
	CommaBlockString	comma;
	int					pos = 0;
	char				filename[MAXPATH];
	CString				buf;
	
	for(int i = 0; i < MAX_WAIT_OK_TAG; i++) localVars->waitOkData[i].cUse = 0;

	sprintf(filename, "%s\\SCAN\\waitOk%03d.ini", sWorkDir, pt->no);
	in = fopen(filename, "rb");
	if(in == NULL) return;

	while(TextGetOneLine(in, buf)) {
		if(buf.GetLength() <= 0) continue;
		if(pos >= MAX_WAIT_OK_TAG) break;

		memset(localVars->waitOkData[pos].tag, 0, (int)sizeof(localVars->waitOkData[pos].tag));
		comma.Set(buf);
		comma.GetBYTE(localVars->waitOkData[pos].cStream);
		if(comma.IsEOS()) {
			pos++;
			continue;
		}
		comma.GetBYTE(localVars->waitOkData[pos].cFunction);
		if(comma.IsEOS()) {
			pos++;
			continue;
		}
		localVars->waitOkData[pos].cUse = 1;
		comma.GetString(localVars->waitOkData[pos].tag, (int)sizeof(localVars->waitOkData[pos].tag));
		pos++;
	}
	fclose(in);
}

void ProcProtocolInit(HWND hwnd, LOCAL_PORT_STRUCT *pt)
{
	pt->hLocalProtocol = (HGLOBAL) new LOCAL_VARS_STRUCT;

	memset(localVars, 0, sizeof(LOCAL_VARS_STRUCT));
	AutoBaseIniGetProjectDirectory(sWorkDir);
	localVars->nBlockNo = 1;
	localVars->dTns = 1;
	localVars->bHsms = false;
	localVars->bEquip = false;
	localVars->nLinkTestTimeout = 10;
	localVars->bActiveDevice = (pt->device.nDeviceStyle >= 2 && pt->device.nDeviceStyle <= 5) ? true : false; // 2 = Com, 3 = Modem. 4 = TCP/IP, 5 = UDP/IP
	localVars->bUseConflictSolution = true;		// ENQ �浹 �� Host ��忡�� �纸�� �� ������?(������ true ��� ����, �ڷ� ��)
	localVars->bWaitSendOkSignal = false;		// add 2014-09-12 for receipe ������ ������ ���� �������α׷��� OK ��ȣ�� ���� ���ΰ�?
	//localVars->nResponseOkMemoryPos = 2000;		// add 2014-09-17 for receipe ������ ������ ���� memory pos, ���θ޸𸮴� waiting ���� �ܺΰ��� ���� �� ���� ������ �ȵ�, 2014-11-07 �ٽ� ����
	localVars->nResponseCheckTimeout = 2000;	// add 2014-09-12 for receipe ������ ������ ���� timeout
	strcpy(localVars->sResponseOkTag, "DI_0000");// added 2014-11-07
	localVars->bSaveHeaderData = false;			// add 2016-11-22 for stream, function, tns saving
	getInitParameter(pt);
	getStreamFunctionFile(pt);
	localVars->bHsmsTcpConnectionFlag = checkAndGetTcpIpConnectionTime(pt);
	localVars->nMinSize = (localVars->bHsms) ? 14 : 13;	
	setStartTimeOutValue(pt);
	getWaitOkTagFromFile(pt);// add by kdy 2014-11-19	
	//checkWaitOkSignal(pt);// test loop
}

void ProcProtocolUnInit(LOCAL_PORT_STRUCT *pt)
{
	//if(localVars->bHsmsConnect) makeAndSendSecsHsmsControl(pt, HSMS_SEPARATE_REQUEST);
	deleteSfMemory(pt);
	delete localVars;
}

extern "C" void DLLEXPORT ProtocolDrawMethodTitle(HDC hdc, int x, int y)
{
	TEXTMETRIC	tm;
	int			i, cxChar, startX = x;
	RECT		rect;
	int			count[6] = { 12, 15, 12, 12, 12, 55 };
	char		buf[6][50] = { "Destination ID,", "read Command,",  "Start Address,",  "buf address,",  "read Size", "Periodic Read Time(SECS Host/Equipmemt)" };

	GetTextMetrics(hdc, &tm);
	cxChar = (tm.tmHeight+tm.tmExternalLeading)/2;
	
	rect.left = startX;
	rect.top = y;
	rect.right = startX;
	rect.bottom = y + tm.tmHeight;

	for(i = 0; i < 6; i++) {
		rect.left = rect.right;
		rect.right += cxChar * count[i];
		if(i == 5) {					// ������ �� : ������ �������� ����
			DrawText(hdc, buf[i], (int)strlen(buf[i]), &rect, DT_LEFT);
		}
		else {
			DrawText(hdc, buf[i], (int)strlen(buf[i]), &rect, DT_CENTER);
		}
	}
}

void ProcProtocolDrawMethod(LOCAL_PORT_STRUCT *pt, HDC hdc, int x, int y, SCAN_METHOD_STRUCT *sm)
{
	TEXTMETRIC	tm;
	char		buf[80];
	int			cxChar, startX = x;
	RECT		rect;
	int			count[6] = { 12, 15, 12, 12, 12, 55 };
	
	GetTextMetrics(hdc, &tm);
	cxChar = (tm.tmHeight+tm.tmExternalLeading)/2;

	sprintf(buf, "%s", sm->sStation);
	rect.left = startX;
	rect.top = y;
	rect.right = startX + cxChar * count[0];
	rect.bottom = y + tm.tmHeight;
	DrawText(hdc, buf, (int)strlen(buf), &rect, DT_CENTER);
	
	rect.left = rect.right;
	rect.right += cxChar * count[1];
	sprintf(buf, "%s", sm->type);	
	DrawText(hdc, buf, (int)strlen(buf), &rect, DT_CENTER);

	if(sm->bHexAddress)
		sprintf(buf, "%3Xh", sm->address);
	else
		sprintf(buf, "%3d", sm->address);

	rect.left = rect.right;
	rect.right += cxChar * count[2];
	DrawText(hdc, buf, (int)strlen(buf), &rect, DT_CENTER);
	
	sprintf(buf, "%3d", sm->target);
	rect.left = rect.right;
	rect.right += cxChar * count[3];
	DrawText(hdc, buf, (int)strlen(buf), &rect, DT_CENTER);

	sprintf(buf, "%3d", sm->size);
	rect.left = rect.right;
	rect.right += cxChar * count[4];
	DrawText(hdc, buf, (int)strlen(buf), &rect, DT_CENTER);
	
	sprintf(buf, "%3d", sm->extra2);
	rect.left = rect.right + 8 * cxChar;   // ������ ���� ���������̹Ƿ� 8�� ���Ѵ�
	rect.right += cxChar * (count[5] + 8);
	DrawText(hdc, buf, (int)strlen(buf), &rect, DT_LEFT);
}

//static int imsiSaveVal = 1;// conflict test

bool checkEnqConflictSerial(LOCAL_PORT_STRUCT *pt)
{
	if(localVars->bUseConflictSolution == false) return false;
	if(localVars->bHsms || localVars->bEquip) return false; // �ø���, Host Mode �� �ƴ� ��
	if(pt->commRecvBuf[0] != ENQ) return false;				// ENQ �� �ƴϴ�.
	localVars->nStatus = READ_ENQ_STATUS;					// Equip ���� ������ �����͸� �б� ���� ��带 �����Ѵ�.
	//PokeWORD(pt, 50, imsiSaveVal++);						// conflict test save to WORD memory
	return true;
}


void checkStartCode(LOCAL_PORT_STRUCT *pt)
{
	if(pt->commCountCurr > 1) return;
	switch(localVars->nStatus) {
		case READ_ENQ_STATUS :
			if(pt->commRecvBuf[0] == ENQ) return;
			pt->commCountCurr = 0;	
			break;
		case READ_EOT_STATUS :
			if(pt->commRecvBuf[0] == EOT) return;
			if(checkEnqConflictSerial(pt)) return;
			//if((localVars->bHsms == false && localVars->bEquip == false) && // �ø���, Host Mode �� ��
			//	pt->commRecvBuf[0] == ENQ) {
			//		localVars->nStatus = READ_ENQ_STATUS;					// Equip ���� ������ �����͸� �б� ���� ��带 �����Ѵ�.
			//		return;
			//}
			pt->commCountCurr = 0;	
			break;
		case READ_ACK_STATUS :
		//case ACK_STATUS :
			if(pt->commRecvBuf[0] == ACK) return;
			pt->commCountCurr = 0;	
			break;
	}
}

WORD getBccData(BYTE *data, int	len)
{
	WORD		bcc = 0;
	int			i;

	for(i = 0; i < len; i++) bcc += data[i];
	return bcc;
}


void setInitRecvStatus(LOCAL_PORT_STRUCT *pt)
{
	if(localVars->bHsms) pt->commCountNeed = 4;
	else pt->commCountNeed = 1;
	pt->commCountCurr = 0;
	//if(bTimeReset) pt->timeout->Reset();
	localVars->bSize = false;
}

void setStartInitFlag(LOCAL_PORT_STRUCT *pt)
{
	localVars->bReadRequest = false;
	localVars->bReadOkFlag = false;
	localVars->bSendDataPacket = false;
	localVars->bSendControlCode = false;
	localVars->cSendHsmsControl = HSMS_DATA_CODE;
	localVars->nBlockNo = 1;
}


static void sendControlCode(LOCAL_PORT_STRUCT *pt, BYTE code)
{
	char	imsi[10];
	
	imsi[0] = code;
	PlcDeviceWriteContinue(&pt->device, imsi, 1);
	setInitRecvStatus(pt);
	DisplaySendCodeNextLine(pt->no);
}


int setDwordvalToBuf(BYTE *data, int buf_pos, DWORD val)
{
	WORD	imsi = HIWORD(val);
	data[buf_pos++] = HIBYTE(imsi);// System Byte
	data[buf_pos++] = LOBYTE(imsi);
	imsi = LOWORD(val);
	data[buf_pos++] = HIBYTE(imsi);
	data[buf_pos++] = LOBYTE(imsi);
	return buf_pos;
}

int makeSecsHeaderEquipAndStation(LOCAL_PORT_STRUCT *pt, BYTE *data, WORD station, int buf_pos)
{
	if(localVars->bHsms) data[buf_pos++] = HIBYTE(station);// hsms �� ���� host/equip ���� ����
	else {
		if(localVars->bEquip) data[buf_pos++] = HIBYTE(station) | 0x80;// ��� ID, MSB : 0 = Host, 1 = equip : B �κ�(header, 10 byte)
		else				  data[buf_pos++] = HIBYTE(station) & 0x7F;
	}
	data[buf_pos++] = LOBYTE(station);
	if((localVars->cFunction % 2) == 1)	data[buf_pos++] = localVars->cStream | 0x80;// Stream No, MSB : 0 = ���� �ʿ����, 1 = �����ʿ�
	else								data[buf_pos++] = localVars->cStream & 0x7F;	
	data[buf_pos++] = localVars->cFunction;// Function No
	return buf_pos;
}

static int makeSecsHeaderData(LOCAL_PORT_STRUCT *pt, BYTE *data, WORD station, bool bReadRequest)// add 2016-12-08, bool bReadRequest
{
	int			buf_pos = 0;
	
	data[buf_pos++] = buf_pos;// block length : A �κ� (size, 1byte)
	buf_pos = makeSecsHeaderEquipAndStation(pt, data, station, buf_pos);
	if(localVars->bSendEnd) data[buf_pos++] = HIBYTE(localVars->nBlockNo) | 0x80;// Block No, MSB : 0 = ���� ���� ����, 1 = end Block
	else					data[buf_pos++] = HIBYTE(localVars->nBlockNo) & 0x7F;// Block No, MSB : 0 = ���� ���� ����, 1 = end Block
	data[buf_pos++] = LOBYTE(localVars->nBlockNo);// Block No,	//localVars->dTns++;
	if(bReadRequest) {										// add 2016-12-08
		if(localVars->bSaveHeaderData) localVars->dTns++;// add 2016-12-05
	}
	return setDwordvalToBuf(data, buf_pos, localVars->dTns);
}



static int makeSecsCrcAndSize(BYTE *data, int buf_pos)
{
	if(buf_pos > 0) {
		data[0] = buf_pos-1;// block length : A �κ� (size, 1byte)
		WORD bcc = getBccData(&data[1], buf_pos-1);	// make BCC
		data[buf_pos++] = HIBYTE(bcc);// bcc
		data[buf_pos++] = LOBYTE(bcc);// bcc
	}
	return buf_pos;
}


static int getSavedBufData(LOCAL_PORT_STRUCT *pt, int buf_pos)
{
	int		start = (localVars->nBlockNo-1) * MAX_ONE_PACKET_DATA, size;

	localVars->bSendEnd = true;
	if(start < 0) return buf_pos;
	if(start + MAX_ONE_PACKET_DATA < localVars->nSendSave) {
		localVars->bSendEnd = false;
		size = MAX_ONE_PACKET_DATA;
	}
	else size = localVars->nSendSave - start;
	if(size <= 0) return buf_pos;
	memcpy((char *)&localVars->sendBuf[buf_pos], (char *)&localVars->saveBuf[start], size);
	return buf_pos + size;
}


static void makeDataReadBuf(LOCAL_PORT_STRUCT *pt, WORD station, char *device, bool bReadRequest)// add 2016-12-08, bool bReadRequest
{
	int			buf_pos = 0;
	
	if(localVars->nBlockNo == 1) {
		getStreamFunctionData(device, localVars->cStream, localVars->cFunction);
		localVars->nSendSave = makeSfMemoryDataToBuf(pt, localVars->saveBuf);
	}
	//PlcDeviceClear(&pt->device);	
	buf_pos = getSavedBufData(pt, 11);
	makeSecsHeaderData(pt, localVars->sendBuf, station, bReadRequest);// add 2016-12-08, bool bReadRequest
	buf_pos = makeSecsCrcAndSize(localVars->sendBuf, buf_pos);	
	if(buf_pos <= MAX_SECS_SEND_BUF) PlcDeviceWriteContinue(&pt->device, (char*)localVars->sendBuf, buf_pos);
	setInitRecvStatus(pt);
	DisplaySendCodeNextLine(pt->no);
}

void sendReadWriteRequestDataReal(LOCAL_PORT_STRUCT *pt, WORD station, char *type, bool bSerial)
{
	if(bSerial) makeDataReadBuf(pt, station, type, true);	// add 2016-12-08, true
	else makeDataReadBufHsms(pt, station, type, true);		// add 2016-12-08, true
	localVars->cSendStream = localVars->cStream;
	localVars->cSendFunction = localVars->cFunction;
	localVars->nSendStation = station;
	localVars->bSendDataPacket = true;
	localVars->bReadRequest = true;
	if(localVars->cFunction % 2 == 0) localVars->bReadRequest = false;// ¦�� function �� ���� �����Ͱ� ����
	//localVars->bReadWriteRequest = false;
}

void sendPeriodicReadOrSendData(LOCAL_PORT_STRUCT *pt, bool bSerial)
{
	SCAN_METHOD_STRUCT	*sm = &pt->scanMethod[localVars->nCurrentReadPos % pt->nScanMethodHap];
	sendReadWriteRequestDataReal(pt, sm->station, sm->type, bSerial);
}

int checkRecvCodeErrorSize(LOCAL_PORT_STRUCT *pt)
{
	//CString		message;
	WORD		bcc = 0;	
	
	switch(localVars->nStatus) {
		case READ_ENQ_STATUS :
			if(pt->commRecvBuf[0] != ENQ) return COMMUNICATION_CODE_BAD;
			return COMMUNICATION_OK;
			if(pt->commRecvBuf[0] != EOT) return COMMUNICATION_CODE_BAD;
			return COMMUNICATION_OK;
		case READ_BLOCK_DATA_STATUS :
			localVars->bEqualStation = false;
			if(pt->commCountCurr < localVars->nMinSize) {
				return COMMUNICATION_CODE_BAD;
				//message.Format("Received Data Size Too Short. Recv Size = %d, Need Size >= %d", pt->commCountCurr, localVars->nMinSize);
				//PlcScanSetErrorString(pt, (char*)(LPCSTR)message);
				//return COMMUNICATION_ERR_STRING_AND_CODEBAD;
			}
			localVars->bRespRequire = (pt->commRecvBuf[3] & 0x80) ? true : false;
			if(localVars->bRespRequire) {
				localVars->cRecvStream = (pt->commRecvBuf[3] & 0x7F);
				localVars->cRecvFunction = pt->commRecvBuf[4];
				if(localVars->cRecvFunction % 2 == 0) localVars->bRespRequire = false;
			}
			localVars->nRecvStation = getWordVal(&pt->commRecvBuf[1]) & 0x7FFF;
			if(localVars->bSendDataPacket) {
				localVars->bEqualStation = (localVars->nSendStation == localVars->nRecvStation) ? true : false;
			}
			localVars->dTns = getDwordVal(&pt->commRecvBuf[7]);
			bcc = getBccData(&pt->commRecvBuf[1], pt->commCountCurr-3);	// make BCC
			if(pt->commRecvBuf[pt->commCountCurr-2] * 0x100 + pt->commRecvBuf[pt->commCountCurr-1] != bcc) {
				return COMMUNICATION_CODE_BAD;
				//message.Format("Received Check Sum Error. Recv Sum = %02Xh, Need Sum = %02Xh", pt->commRecvBuf[pt->commCountCurr-2], bcc);
				//PlcScanSetErrorString(pt, (char*)(LPCSTR)message);
				//return COMMUNICATION_ERR_STRING_AND_CODEBAD;
			}
			break;
		//case ACK_STATUS :
		//	break;
		case READ_EOT_STATUS :			
			if(pt->commRecvBuf[0] != EOT) return COMMUNICATION_CODE_BAD;
			return COMMUNICATION_OK;
		case READ_ACK_STATUS :
			if(pt->commRecvBuf[0] != ACK) return COMMUNICATION_CODE_BAD;
			return COMMUNICATION_OK;
	}
	return COMMUNICATION_OK;
}


DWORD getSizeField(BYTE *data, BYTE cSize)
{
	switch(cSize) {
		case 1 : return (DWORD)data[0];
		case 2 : return (DWORD)getWordVal(data);
		case 3 : return (DWORD)data[0] * 0x10000L + (DWORD)getWordVal(&data[1]);
		default : return 0;
	}
}

static bool checkEndPos(int buf_pos, int totalCount)
{
	if(buf_pos > totalCount) return true;
	return false;
}

int readUserDataToMemory(LOCAL_PORT_STRUCT *pt, int &target, int &buf_pos)
{
	DWORD	i, dSize;
	WORD	size;
	BYTE	cDataType, cSize;	
	//LOCAL_VARS_STRUCT *lp = localVars;// test

	if(checkEndPos(buf_pos+2, localVars->readDataSt.nSavePos)) {
		//PokeValueAll(pt, target++, (WORD)(localVars->cRecvStream));// stream
		//PokeValueAll(pt, target++, (WORD)(localVars->cRecvFunction));// function
		return COMMUNICATION_OK;// �����Ͱ� ����
	}

	cDataType = localVars->recvBuf[buf_pos] / 4;
	cSize = localVars->recvBuf[buf_pos++] % 4;
	if(cSize == 0) return COMMUNICATION_OK;

	dSize = getSizeField(&localVars->recvBuf[buf_pos], cSize);
	//if(dSize == 0) return COMMUNICATION_OK;
	//PokeValueAll(pt, target++, (WORD)(cDataType));
	//PokeValueAll(pt, target++, (WORD)(dSize));
	buf_pos += cSize;

	switch(cDataType)
	{
		case DATA_TYPE_LIST	:
			for(i = 0; i < dSize; i++) {
				if(checkEndPos(buf_pos, localVars->readDataSt.nSavePos)) break;
				readUserDataToMemory(pt, target, buf_pos);
			}
			break;
		case DATA_TYPE_BINARY :
		case DATA_TYPE_BOOLEAN :
			for(i = 0; i < dSize; i++) {
				if(checkEndPos(buf_pos, localVars->readDataSt.nSavePos)) break;
				PokeValueAll(pt, target++, (WORD)localVars->recvBuf[buf_pos++]);
			}
			break;
		case DATA_TYPE_ASCII :
		case DATA_TYPE_JIS_8 :
			size = (WORD)dSize;
			if((buf_pos + size) > localVars->readDataSt.nSavePos) size = localVars->readDataSt.nSavePos-buf_pos;
			PokeValueAll(pt, target, getStringDoulbeVal(&localVars->recvBuf[buf_pos], size));
			PokeValueAllAscii(pt, target++, &localVars->recvBuf[buf_pos], size);
			buf_pos += dSize;
			break;
		case DATA_TYPE_1_BYTE_SIGN_INTEGER :
		case DATA_TYPE_1_BYTE_UNSIGN_INTEGER :
			for(i = 0; i < dSize; i++) {
				if(checkEndPos(buf_pos, localVars->readDataSt.nSavePos)) break;
				PokeValueAll(pt, target++, (WORD)localVars->recvBuf[buf_pos++]);
			}
			break;
		case DATA_TYPE_2_BYTE_SIGN_INTEGER :
		case DATA_TYPE_2_BYTE_UNSIGN_INTEGER :
			for(i = 0; i < dSize/2; i++, buf_pos += 2) {
				if(checkEndPos(buf_pos+1, localVars->readDataSt.nSavePos)) break;
				PokeValueAll(pt, target++, getWordVal(&localVars->recvBuf[buf_pos]));
			}
			break;
		case DATA_TYPE_4_BYTE_SIGN_INTEGER :
		case DATA_TYPE_4_BYTE_UNSIGN_INTEGER :
			for(i = 0; i < dSize/4; i++, buf_pos += 4) {
				if(checkEndPos(buf_pos+3, localVars->readDataSt.nSavePos)) break;
				PokeValueAll(pt, target++, getDwordVal(&localVars->recvBuf[buf_pos]));
			}
			break;		
		case DATA_TYPE_4_BYTE_FLOAT :
			for(i = 0; i < dSize/4; i++, buf_pos += 4) {
				if(checkEndPos(buf_pos+3, localVars->readDataSt.nSavePos)) break;
				PokeValueAll(pt, target++, (double)getFloat4Val(&localVars->recvBuf[buf_pos]));
			}
			break;
		case DATA_TYPE_8_BYTE_FLOAT :
			for(i = 0; i < dSize/8; i++, buf_pos += 8) {
				if(checkEndPos(buf_pos+7, localVars->readDataSt.nSavePos)) break;
				PokeValueAll(pt, target++, getFloat8Val(&localVars->recvBuf[buf_pos]));
			}
			break;
		case DATA_TYPE_8_BYTE_SIGN_INTEGER :
		case DATA_TYPE_8_BYTE_UNSIGN_INTEGER :
			for(i = 0; i < dSize/8; i++, buf_pos += 8) {
				if(checkEndPos(buf_pos+7, localVars->readDataSt.nSavePos)) break;
				PokeValueAll(pt, target++, get8ByteVal(&localVars->recvBuf[buf_pos]));
			}
			break;
		default : return 0;						// unknown data type
	}
	return COMMUNICATION_OK;
}

int getReadStartPos(LOCAL_PORT_STRUCT *pt, WORD station, BYTE cRecvStream, BYTE cRecvFunction)
{
	int					i;
	BYTE				cStream, cFunction;
	SCAN_METHOD_STRUCT	*sm;

	for(i = 0; i < pt->nScanMethodHap; i++) {
		sm = &pt->scanMethod[i];
		if(sm->station != station) continue;
		if(getStreamFunctionData(sm->type, cStream, cFunction) == false) continue;
		if(cStream != cRecvStream) continue;
		if(cFunction != cRecvFunction) continue;
		return sm->target;
	}
	return -1;
}

static void getAndSaveCurrentPacketData(LOCAL_PORT_STRUCT *pt, BYTE	cStream, BYTE cFunction)
{
	if(pt->commCountCurr < localVars->nMinSize) return;

	int dataLen = pt->commCountCurr - localVars->nMinSize;
	if(localVars->readDataSt.nPacketNo <= 1) {
		localVars->readDataSt.nStation = localVars->nRecvStation;
		localVars->readDataSt.nOldPacketNo = localVars->readDataSt.nPacketNo;
		localVars->readDataSt.cStream = cStream;
		localVars->readDataSt.cFunction = cFunction;
		localVars->readDataSt.nSavePos = 0;
		memcpy(&localVars->recvBuf[0], &pt->commRecvBuf[0], dataLen + 11);
		localVars->readDataSt.nSavePos += dataLen + 11;
		return;
	}
	else {
		if((WORD)(localVars->readDataSt.nOldPacketNo + 1) != localVars->readDataSt.nPacketNo) return;// packet no �� ���� �ʴ�.
	}
	
	if(localVars->readDataSt.nStation != localVars->nRecvStation) return;// ������ station �� ���� �ʴ�
	if(localVars->readDataSt.cStream != cStream || localVars->readDataSt.cFunction != cFunction) return;// ������ stream/function �� ���� �ʴ�
	if(localVars->readDataSt.nSavePos + dataLen > MAX_SECS_RECV_BUF) return;// ���̻� �����͸� ������ �޸𸮸� �غ����� �ʾҴ�.
	if(dataLen > 0) {
		memcpy(&localVars->recvBuf[localVars->readDataSt.nSavePos], &pt->commRecvBuf[11], dataLen);
		localVars->readDataSt.nSavePos += dataLen;
	}
	localVars->readDataSt.nOldPacketNo = localVars->readDataSt.nPacketNo;
}


int savePacketHeraderDataToMemory(LOCAL_PORT_STRUCT *pt, int target)// add 2016-11-22
{
	PokeValueAll(pt, target, (WORD)(localVars->cRecvStream));// stream
	PokeValueAll(pt, target+1, (WORD)(localVars->cRecvFunction));// function
	PokeValueAll(pt, target+2, localVars->dTns);// tns, system byte
	return target+3;
}

int readDataToMemory(LOCAL_PORT_STRUCT *pt)
{
	if(pt->commCountCurr < localVars->nMinSize) return COMMUNICATION_OK;

	int			buf_pos = 3, target = 0;
	BYTE		cStream, cFunction;

	localVars->bReadOkFlag = true;
	cStream = (pt->commRecvBuf[buf_pos++] & 0x7F);
	cFunction = pt->commRecvBuf[buf_pos++];
	target = getReadStartPos(pt, localVars->nRecvStation, cStream, cFunction);
	localVars->bEndPacket = (pt->commRecvBuf[buf_pos] & 0x80) ? true : false;
	localVars->readDataSt.nPacketNo = (pt->commRecvBuf[buf_pos] & 0x7F) * 0x100 + pt->commRecvBuf[buf_pos+1];
	if(localVars->bReadRequest) {
		localVars->bReadDone = (localVars->bEndPacket && localVars->bEqualStation &&
			localVars->cSendStream == cStream && (BYTE)(localVars->cSendFunction + 1) == cFunction) ? true : false;
	}
	if(target == -1) return COMMUNICATION_OK;
	
	getAndSaveCurrentPacketData(pt, cStream, cFunction);
	if(localVars->bEndPacket == false) return COMMUNICATION_OK;
	buf_pos += 6;// block 2byte, Tns 4Byte	

	if(localVars->bSaveHeaderData == true) target = savePacketHeraderDataToMemory(pt, target); // add 2016-11-22 for stream, function, tns saving
	readUserDataToMemory(pt, target, buf_pos);
	return COMMUNICATION_OK;
}




int checkEachReadScheduleTimeOut(LOCAL_PORT_STRUCT *pt)
{
	int					i, hap, pos;
	SCAN_METHOD_STRUCT	*sm;
	
	localVars->bReadWriteRequest = false;
	hap = pt->nScanMethodHap;
	if(hap > MAX_READ_SCHEDULE) hap = MAX_READ_SCHEDULE;
	pos = (localVars->nCurrentReadPos + 1) % hap;
	for(i = 0; i < hap; i++, pos = (pos + 1) % hap) {
		sm = &pt->scanMethod[pos];
		if(sm->active == false || sm->extra2 == 0) continue;
		if(localVars->timeout[pos].IsTimeOut(sm->extra2)) {
			localVars->timeout[pos].Reset();
			localVars->nCurrentReadPos = pos;
			localVars->bReadWriteRequest = true;
			return pos;
		}
	}
	return -1;
}

void checkReadEnaStatusSerial(LOCAL_PORT_STRUCT *pt)
{
	sendControlCode(pt, EOT);
	localVars->nStatus = READ_BLOCK_DATA_STATUS;
}

int checkReadBlockDataStatusSerial(LOCAL_PORT_STRUCT *pt, bool bRead)
{
	readDataToMemory(pt);
	sendControlCode(pt, ACK);
	if(localVars->bEndPacket == false) {
		localVars->nStatus = READ_ENQ_STATUS;
		setInitRecvStatus(pt);
		return COMMUNICATION_WAITING;
	}
	if(localVars->bRespRequire || localVars->bReadWriteRequest) {
		localVars->nStatus = READ_EOT_STATUS;
		sendControlCode(pt, ENQ);
		return COMMUNICATION_WAITING;
	}
	if(localVars->bReadDone && localVars->bReadRequest) return COMMUNICATION_OK;// ���ϴ� ������ ������ ��
	if(bRead) {
		if(localVars->bReadOkFlag && localVars->bSendDataPacket == false) return COMMUNICATION_OK;// Ư���� �����͸� �а�, �о�� �� ������ ���� ��
	}
	localVars->nStatus = READ_ENQ_STATUS;
	setInitRecvStatus(pt);
	return COMMUNICATION_WAITING;
}

bool TagSetCurr(const char *tag, double val);

bool checkWaitOkTagExist(LOCAL_PORT_STRUCT *pt)// add by kdy 2014-11-19
{
	int		i, len;

	//localVars->cRecvStream = 19;	//test
	//localVars->cRecvFunction = 25;//test

	memset(localVars->sCurrWaitOkTag, 0, (int)sizeof(localVars->sCurrWaitOkTag));
	for(i = 0; i < MAX_WAIT_OK_TAG; i++) {
		if(localVars->waitOkData[i].cUse == 0) continue;
		if(localVars->waitOkData[i].cStream != localVars->cRecvStream) continue;
		if(localVars->waitOkData[i].cFunction != localVars->cRecvFunction) continue;

		len = (int)strlen(localVars->waitOkData[i].tag);
		if(len <= 0) continue;
		if(len > (int)sizeof(localVars->sCurrWaitOkTag)) len = (int)sizeof(localVars->sCurrWaitOkTag);
		memcpy(localVars->sCurrWaitOkTag, localVars->waitOkData[i].tag, len);
		TagSetCurr(localVars->sCurrWaitOkTag, 1.0);
		return true;
	}

	len = (int)strlen(localVars->sResponseOkTag);
	if(len <= 0) return false;
	if(len > (int)sizeof(localVars->sCurrWaitOkTag)) len = (int)sizeof(localVars->sCurrWaitOkTag);
	memcpy(localVars->sCurrWaitOkTag, localVars->sResponseOkTag, len);
	TagSetCurr(localVars->sCurrWaitOkTag, 1.0);
	return true;
}

void checkWaitOkSignal(LOCAL_PORT_STRUCT *pt)									// add 2014-09-12 for receipe ������ ������ ���� �������α׷��� OK ��ȣ�� ���� ���ΰ�?
{
	CString		curr = "";
	TimeOutMiliSecClass	timeout;
	bool		flag = false;
	int			val;
	
	//if((int)strlen(localVars->sResponseOkTag) <= 0) return;
	//TagSetCurr(localVars->sResponseOkTag, 1.0);
	if(checkWaitOkTagExist(pt) == false) return;								// add by kdy 2014-11-19
	//PokeWORD(pt, localVars->nResponseOkMemoryPos, 1);							// �̰��� �޸� ���� ������α׷����� ������ �ð��� ���� �ʱ� ������ �ȵ�, 2014-11-07 ����
	timeout.Reset();
	if(localVars->nResponseCheckTimeout > 10000) localVars->nResponseCheckTimeout = 2000;

	while(1) {
		if(timeout.IsTimeOut(localVars->nResponseCheckTimeout)) return;
		//if(PeekValueWORD(pt, localVars->nResponseOkMemoryPos) != 1) // �̰��� �޸� ���� ������α׷����� ������ �ð��� ���� �ʱ� ������ �ȵ�, 2014-11-07 ����
		//if(Tag9GetCurr(localVars->sResponseOkTag, curr) == false) return;//  delete 2014-11-19
		if(Tag9GetCurr(localVars->sCurrWaitOkTag, curr) == false) return;// add by kdy 2014-11-19
		val = atoi(curr);
		if(val == 1) flag = true;			
		if(flag && val != 1) {
			//PokeWORD(pt, 1, 1);//test
			return;
		}
	}
}

int checkReadEotStatusSerial(LOCAL_PORT_STRUCT *pt, WORD station, char *device, bool bRead)
{
	localVars->nStatus = READ_ACK_STATUS;
	if(localVars->bRespRequire) {
		sprintf(localVars->sSendStream, "%1d.%1d", localVars->cRecvStream, localVars->cRecvFunction+1);
		if(localVars->bWaitSendOkSignal) checkWaitOkSignal(pt);						// add 2014-09-12 for receipe ������ ������ ���� �������α׷��� OK ��ȣ�� ���� ���ΰ�?
		makeDataReadBuf(pt, localVars->nRecvStation, localVars->sSendStream, false);// add 2016-12-08, true
		return COMMUNICATION_WAITING;
	}
	else if(localVars->bReadWriteRequest) {// ���� �����͸� ������ �Ѵ�
		if(bRead) sendPeriodicReadOrSendData(pt, true);
		else sendReadWriteRequestDataReal(pt, station, device, true);
		return COMMUNICATION_WAITING;
	}
	else return COMMUNICATION_OK_NOCOUNT;
}

int checkReadAckStatusSerial(LOCAL_PORT_STRUCT *pt)
{
	if(localVars->bSendEnd == false) {
		localVars->nBlockNo++;
		localVars->nStatus = READ_EOT_STATUS;
		sendControlCode(pt, ENQ);
		return COMMUNICATION_WAITING;
	}
	localVars->nBlockNo = 1;
	if(localVars->bRespRequire) localVars->bRespRequire = false;
	if(localVars->bSendDataPacket && localVars->bReadRequest == false) return COMMUNICATION_OK;// �����͸� ���°� ���� �����Ͱ� ���� ���

	if(localVars->bReadWriteRequest && localVars->bSendDataPacket == false) {// ���� �����͸� ������ �Ѵ�
		localVars->nStatus = READ_EOT_STATUS;
		sendControlCode(pt, ENQ);
		return COMMUNICATION_WAITING;
	}
	if(localVars->bSendDataPacket) {										// �б� ���� �����͸� ���°�, ������ �б⸦ �䱸�� ��
		if(localVars->bReadWriteRequest) localVars->bReadWriteRequest = false;
		localVars->nStatus = READ_ENQ_STATUS;
		setInitRecvStatus(pt);
		return COMMUNICATION_WAITING;
	}
	return COMMUNICATION_OK_NOCOUNT;
}



static bool getNeededPacketSize(LOCAL_PORT_STRUCT *pt)
{
	if(localVars->nStatus == READ_BLOCK_DATA_STATUS && localVars->bSize == false) {
		pt->commCountNeed = pt->commRecvBuf[0] + 3;
		localVars->bSize = true;
		if(pt->commCountCurr < pt->commCountNeed) return true;
	}
	return false;
}



//------------------------------------------------------------------------------
//      Scan Method �� �ִ� ������ �о ���ۿ� �����Ѵ�.
//------------------------------------------------------------------------------

extern "C" int DLLEXPORT ProtocolRead(LOCAL_PORT_STRUCT *pt, int pos)
{
	int  				count, retn;
	
	if(localVars->bHsms) return ProtocolReadHsms(pt);
	if(pt->bReadingFlag == OFF) {
		setStartInitFlag(pt);
		localVars->nStatus = READ_ENQ_STATUS;
		if(checkEachReadScheduleTimeOut(pt) != -1) {
			localVars->nStatus = READ_EOT_STATUS;
			sendControlCode(pt, ENQ);
		}
		setInitRecvStatus(pt);
		pt->timeout->Reset();
		pt->bReadingFlag = ON;
	}

	while(1) {
		if(pt->commCountCurr >= MAX_RECV_BUF) return COMMUNICATION_ERR_SIZE_TOO_BIG;
		if(pt->timeout->IsTimeOut(pt->MAX_TIME_OUT_READ)) {
			if(localVars->bReadDone && localVars->bReadRequest) return COMMUNICATION_OK;// ���ϴ� ������ ������ ��
			if(localVars->bReadOkFlag && localVars->bSendDataPacket == false) return COMMUNICATION_OK;// Ư���� �����͸� �а�, �о�� �� ������ ���� ��
			if(localVars->bReadWriteRequest == false && localVars->bSendDataPacket == false) return COMMUNICATION_OK_NOCOUNT;// �б��� ���ɵ� ����, ������ ���ɵ� ���� ��
			return COMMUNICATION_TIME_OUT;
		}		
		count = PlcDeviceReadContinue(&pt->device, (char*)&pt->commRecvBuf[pt->commCountCurr], 1);
		if(count == 0) {
			if(pt->commCountCurr == 0 && localVars->bReadWriteRequest == false && localVars->bSendDataPacket == false && localVars->nStatus == READ_ENQ_STATUS) return COMMUNICATION_OK_NOCOUNT;
			return COMMUNICATION_WAITING;
		}
		pt->commCountCurr += count;
		checkStartCode(pt);
		
		if(pt->commCountCurr >= pt->commCountNeed) {// �ʿ��� ����Ʈ ����ŭ ����Ÿ�� ��� �޾Ҵ�.			
			if(getNeededPacketSize(pt)) continue;
			DisplayRecvCodeNextLine(pt->no);
			retn = checkRecvCodeErrorSize(pt);
			if(retn != COMMUNICATION_OK) {
				setInitRecvStatus(pt);
				continue;
			}

			switch(localVars->nStatus) {
				case READ_ENQ_STATUS :
					checkReadEnaStatusSerial(pt);
					continue;
				case READ_BLOCK_DATA_STATUS :
					retn = checkReadBlockDataStatusSerial(pt, true);
					if(retn == COMMUNICATION_OK) return COMMUNICATION_OK;
					continue;
				case READ_EOT_STATUS :
					retn = checkReadEotStatusSerial(pt, 1, "", true);
					if(retn == COMMUNICATION_WAITING) continue;
					return COMMUNICATION_OK_NOCOUNT;// EOT �����͸� ����µ� ������ �����Ͱ� ����, ������ ���� �� ���� �����
				case READ_ACK_STATUS :
					retn = checkReadAckStatusSerial(pt);
					if(retn == COMMUNICATION_OK) return COMMUNICATION_OK;
					if(retn == COMMUNICATION_WAITING) continue;
					if(localVars->bReadOkFlag && localVars->bSendDataPacket == false) return COMMUNICATION_OK;// Ư���� �����͸� �а�, �о�� �� ������ ���� ��
					return COMMUNICATION_OK_NOCOUNT;// ACK�� ����µ� ������ �����Ͱ� ����, ������ ���� �� ���� �����
			}
			return COMMUNICATION_OK;
		}
	}
}

static int WriteWordSerial(LOCAL_PORT_STRUCT *pt, int station, char *device)
{
	int				count, retn;
	TimeOutClass	timeout;
	
	setStartInitFlag(pt);
	localVars->nStatus = READ_EOT_STATUS;
	localVars->bReadWriteRequest = true;
	sendControlCode(pt, ENQ);
	timeout.Reset();

	while(1) {
		if(pt->commCountCurr >= MAX_RECV_BUF) return COMMUNICATION_ERR_SIZE_TOO_BIG;
		if(timeout.IsTimeOut(pt->MAX_TIME_OUT_WRITE)) return COMMUNICATION_TIME_OUT;
		
		count = PlcDeviceReadContinue(&pt->device, (char*)&pt->commRecvBuf[pt->commCountCurr], 1);
		if(count == 0)	continue;
		pt->commCountCurr += count;
		checkStartCode(pt);
				
		// �ʿ��� ����Ʈ ����ŭ ����Ÿ�� ��� �޾Ҵ�.
		if(pt->commCountCurr >= pt->commCountNeed) {
			if(getNeededPacketSize(pt)) continue;
			DisplayRecvCodeNextLine(pt->no);
			retn = checkRecvCodeErrorSize(pt);
			if(retn != COMMUNICATION_OK) {
				setInitRecvStatus(pt);
				continue;
			}
			switch(localVars->nStatus) {
				case READ_ENQ_STATUS :					
					//timeout.Reset();
					checkReadEnaStatusSerial(pt);
					continue;
				case READ_BLOCK_DATA_STATUS :				
					//timeout.Reset();
					retn = checkReadBlockDataStatusSerial(pt, false);
					if(retn == COMMUNICATION_OK) return COMMUNICATION_OK;
					continue;
				case READ_EOT_STATUS :
					//timeout.Reset();
					retn = checkReadEotStatusSerial(pt, station, device, false);
					if(retn == COMMUNICATION_WAITING) continue;
					return COMMUNICATION_CODE_BAD;// EOT �����͸� ����µ� ������ �����Ͱ� ����, ������ ���� �� ���� �����
				case READ_ACK_STATUS :
					//timeout.Reset();
					retn = checkReadAckStatusSerial(pt);
					if(retn == COMMUNICATION_OK) return COMMUNICATION_OK;
					if(retn == COMMUNICATION_WAITING) continue;
					localVars->nStatus = READ_ENQ_STATUS;// ACK�� ����µ� ������ �����Ͱ� ����, ������ ���� �� ���� �����
					setInitRecvStatus(pt);
					continue;
			}
			return COMMUNICATION_OK;
		}
	}
}



// �� ���带 ����� ���� ����.
static int WriteWord(LOCAL_PORT_STRUCT *pt, int station, DWORD address, long double val, char *device, WORD pannel)
{
	if((int)strlen(device) <= 0) {
		PlcScanSetErrorString(pt, "Please Input Write Command. Command = 1.1, ....");
		return COMMUNICATION_ERR_STRING_AND_CODEBAD;
	}

	if(localVars->bHsms) return WriteWordHsms(pt, station, device);// HSMS protocol
	else return WriteWordSerial(pt, station, device);
}


//------------------------------------------------------------------------------
// �� ��Ʈ�� ����� ���� ����.
// �ϳ��� ����Ż�� �ϳ��� ���带 ����ϹǷ� WORD ���� ��İ� �����Ѵ�.
// ON �϶��� 0xFFFF, OFF �϶��� 0x0000�� �ּҿ� ���� �ȴ�.
//------------------------------------------------------------------------------

int ProcProtocolWriteBit(LOCAL_PORT_STRUCT *pt, int station, DWORD address, WORD flag, char *device, WORD pannel, char *sAddress)
{
	char buf[80];
	sprintf(buf, "%04X", address);
	address = atol(buf);

	return WriteWord(pt, station, address, (long double)flag, device, pannel);
	
}




//------------------------------------------------------------------------------
//      �� ���带 ����� ���� ����.
//------------------------------------------------------------------------------

int ProcProtocolWriteWord(LOCAL_PORT_STRUCT *pt, int station, DWORD address, long double value, char *device, WORD pannel, char *sAddress)
{
	char	buf[80];
	
	sprintf(buf, "%04X", address);
	address = atol(buf);
	return WriteWord(pt, station, address, value, device, pannel);
}



int ProcProtocolWriteBlock(LOCAL_PORT_STRUCT *pt, int station, DWORD address, BYTE *value, short array_size, BYTE array_type, char *device, WORD pannel, char *sAddress)
{
	CString buf;
	CString atype;
	
	if(array_type == 1)			atype = "byte";
	else if(array_type == 4)	atype = "ushort";
	else if(array_type == 6)	atype = "uint";
	else if(array_type == 8)	atype = "ulong";
	else if(array_type == 9)	atype = "float";
	else if(array_type == 10)	atype = "double";
	else if(array_type == 11)	atype = "string";
	else						atype = "unknown type";
	buf.Format("Block Write Array Type Input Error. Use Byte or String Array. \n(Input Array type = %s)", atype);
	PlcScanSetErrorString(pt, buf);	
	return COMMUNICATION_ERR_STRING;
}

class ChangeResource {
	HINSTANCE hInst;
public:
	ChangeResource();
	~ChangeResource();
};

ChangeResource::ChangeResource()
{
	hInst = AfxGetResourceHandle();
	AfxSetResourceHandle(theApp.m_hInstance);
}

ChangeResource::~ChangeResource()
{
	AfxSetResourceHandle(hInst);
}

static void getInitDialogParameter(char *option, CDialogProtocolOption &dialog)
{
	CommaBlockString	comma;
	WORD				imsi;
	
	if(strlen(option) > 0) {
		comma.Set(option);	
		if(comma.IsEOS()) return;
		comma.GetWORD(imsi);
		dialog.m_bEquip = (imsi == 0) ? false : true;
		if(comma.IsEOS()) return;

		comma.GetWORD(imsi);
		dialog.m_bHsms = (imsi == 0) ? false : true;
		if(comma.IsEOS()) return;

		comma.GetWORD(imsi);
		dialog.m_nLinkTestTime = (imsi < 2 || imsi > 10000) ? 10 : imsi;
		if(comma.IsEOS()) return;

		comma.GetWORD(imsi);
		dialog.m_bUseConflictSolution = (imsi == 0) ? false : true;
		if(comma.IsEOS()) return;

		comma.GetWORD(imsi);
		dialog.m_bWaitSendOkSignal = (imsi == 0) ? false : true;
		if(comma.IsEOS()) return;

		//comma.GetWORD(imsi);
		//dialog.m_nResponseOkMemoryPos = (imsi > 65535) ? 2000 : imsi;// deleted by kdy 2014-11-07
		//if(comma.IsEOS()) return;		

		comma.GetWORD(imsi);
		dialog.m_nCheckTimeout = (imsi < 100 || imsi > 10000) ? 2000 : imsi;
		if(comma.IsEOS()) return;

		comma.GetString(dialog.m_sResponseOkTag);// added by kdy 2014-11-07
		if(comma.IsEOS()) return;

		comma.GetWORD(imsi);
		dialog.m_bSaveHeaderData = (imsi == 0) ? false : true;// added 2016-11-22
		if(comma.IsEOS()) return;
	}
}

int ProcProtocolConfigOption(HWND hwnd, HWND hwndEdit, int port, char *option)
{
	ChangeResource			res;
	int						retn = 0;
	CDialogProtocolOption	dialog;
	
	dialog.m_hwndEdit = hwndEdit;
	dialog.m_nPort = port;
	dialog.m_bEquip = false;
	dialog.m_bHsms = false;
	dialog.m_nLinkTestTime = 10;
	dialog.m_bUseConflictSolution = true;
	dialog.m_bWaitSendOkSignal = false;
	//dialog.m_nResponseOkMemoryPos = 2000;		// deleted by kdy 2014-11-07
	dialog.m_nCheckTimeout = 2000;
	dialog.m_sResponseOkTag.Format("DI_0000");	// added 2014-11-07
	dialog.m_bSaveHeaderData = false;			// added 2016-11-22
	getInitDialogParameter(option, dialog);
	TagLoad9();
	
	retn = (int)dialog.DoModal();
	if(retn == IDOK) {
		//sprintf(option, "%d,%d,%d,%d,%d,%d,%d,", dialog.m_bEquip, dialog.m_bHsms, dialog.m_nLinkTestTime, dialog.m_bUseConflictSolution, dialog.m_bWaitSendOkSignal, dialog.m_nResponseOkMemoryPos, dialog.m_nCheckTimeout);// deleted by kdy 2014-11-07
		sprintf(option, "%d,%d,%d,%d,%d,%d,%s,%d,", dialog.m_bEquip, dialog.m_bHsms, dialog.m_nLinkTestTime, dialog.m_bUseConflictSolution, dialog.m_bWaitSendOkSignal, dialog.m_nCheckTimeout, dialog.m_sResponseOkTag, dialog.m_bSaveHeaderData);// added by kdy 2014-11-07, // added 2016-11-22, dialog.m_bSaveHeaderData
	}
	return retn;
}

