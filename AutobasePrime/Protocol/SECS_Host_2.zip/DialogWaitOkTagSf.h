#pragma once
#include "afxcmn.h"

#include "DialogSelectSfAndTag.h"
// CDialogWaitOkTagSf dialog

class CDialogWaitOkTagSf : public CDialog
{
	DECLARE_DYNAMIC(CDialogWaitOkTagSf)

public:
	CDialogWaitOkTagSf(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDialogWaitOkTagSf();

// Dialog Data
	enum { IDD = IDD_DIALOG_WAIT_OK_TAG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_list;
	virtual BOOL OnInitDialog();
protected:
	virtual void OnOK();
public:
	afx_msg void OnBnClickedButtonEdit();
	afx_msg void OnBnClickedButtonAdd();
	afx_msg void OnBnClickedButtonDelete();

	int		ptNo;

	int		GetSelectPosition();
	void	getWaitOkTagFromFileToList();
	void	getCurrReadData(int pos, CDialogSelectSfAndTag &dialog);
	void	saveWaitOkTagFromFileToList();
	bool	checkEqualStreamFunction(BYTE stream, BYTE function);
	afx_msg void OnNMDblclkListReadSchedule(NMHDR *pNMHDR, LRESULT *pResult);

	bool	bChange;
};
