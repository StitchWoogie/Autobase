#pragma once
#include "afxcmn.h"

#include "DialogReadSchedule.h"
// CDialogProtocolOption dialog

class CDialogProtocolOption : public CDialog
{
	DECLARE_DYNAMIC(CDialogProtocolOption)

public:
	CDialogProtocolOption(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDialogProtocolOption();

// Dialog Data
	enum { IDD = IDD_DIALOG_OPTION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_list;
	virtual BOOL OnInitDialog();
protected:
	virtual void OnOK();
public:
	afx_msg void OnBnClickedButtonEdit();
	afx_msg void OnBnClickedButtonAdd();
	afx_msg void OnBnClickedButtonDelete();
	afx_msg void OnNMDblclkListReadSchedule(NMHDR *pNMHDR, LRESULT *pResult);

	HWND		m_hwndEdit;
	int			m_nPort;
	BOOL		m_bEquip;
	BOOL		m_bHsms;

	int			m_tagPos;		// add 2014-11-07
	int			m_tagType;		// add 2014-11-07, 0 = AI, 1 = AO, 2 = DI,...
	
	int GetSelectPosition();
	BOOL GetReadSchedule();
	BOOL checkHexAddress(char *buf);
	DWORD HexBufToDec(char *buf);
	WORD getHexDecimalValue(WORD currPos, WORD listPos, BOOL &bHexValue);
	void getCurrReadData(CDialogReadSchedule &dialog, BOOL &bHexStation, BOOL &bHexAddress);
	void setOkReadData(CDialogReadSchedule &dialog, BOOL bHexStation, BOOL bHexAddress);
	void checkAllRadioButton();
	void EnableDisable();
	afx_msg void OnBnClickedButtonSfEdit();	
	afx_msg void OnBnClickedRadioHostMode();
	afx_msg void OnBnClickedRadioEquipMode();
	afx_msg void OnBnClickedRadioSerialMode();
	afx_msg void OnBnClickedRadioHsmsMode();
	UINT m_nLinkTestTime;
	CSpinButtonCtrl m_spinLinkTestTime;
	BOOL m_bUseConflictSolution;
	BOOL m_bWaitSendOkSignal;
	UINT m_nCheckTimeout;
	CSpinButtonCtrl m_spinCheckTimeout;
	afx_msg void OnBnClickedCheckUseResponseOk();
	//DWORD m_nResponseOkMemoryPos;
	//CSpinButtonCtrl m_spinResponseOkMemoryPos;
	afx_msg void OnBnClickedButtonStatusTag();
	CString m_sResponseOkTag;
	afx_msg void OnBnClickedButtonWaitOkForEachSf();
	BOOL m_bSaveHeaderData;
};
