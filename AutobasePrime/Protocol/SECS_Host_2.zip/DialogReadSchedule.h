#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CDialogReadSchedule dialog

class CDialogReadSchedule : public CDialog
{
	DECLARE_DYNAMIC(CDialogReadSchedule)

public:
	CDialogReadSchedule(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDialogReadSchedule();

// Dialog Data
	enum { IDD = IDD_DIALOG_READ_SCHEDULE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CComboBox m_comboMemory;
	UINT m_station;
	CSpinButtonCtrl m_spinStation;
	CComboBox m_comboStream;
	CComboBox m_comboFunction;
	DWORD m_bufAddr;
	CSpinButtonCtrl m_spinBufAddr;
	UINT m_readSize;
	CSpinButtonCtrl m_spinReadSize;
	virtual BOOL OnInitDialog();

	int		m_currPos;
	int		m_startAddr;
	BYTE	m_memory;
	BYTE	m_stream;
	BYTE	m_function;

	void EnableDisable();

protected:
	virtual void OnOK();
public:
	BOOL m_bUsePeriodicRead;
	DWORD m_periodicRead;
	CSpinButtonCtrl m_spinPeriodicRead;
	afx_msg void OnBnClickedCheckPeriodicRead();
};
