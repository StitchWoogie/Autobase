// DialogProtocolOption.cpp : implementation file
//

#include "stdafx.h"
#include "SECS_Host.h"
#include "DialogProtocolOption.h"
#include "DialogReadSchedule.h"
#include "DialogDeleteConfirm.h"
#include "DialogSfEditMain.h"
#include "DialogSelectTag.h"
#include "DialogWaitOkTagSf.h"

#include "..\..\PLC_SCAN\plc_scan.h"
#include "..\..\PLC_SCAN\DLL\\dll_lib\dll_lib.h"

#include <dataswap.h>
#include ".\dialogprotocoloption.h"


char		mem_buf[3][10] = { "READ", "DWORD", "FLOAT" };



// CDialogProtocolOption dialog

IMPLEMENT_DYNAMIC(CDialogProtocolOption, CDialog)
CDialogProtocolOption::CDialogProtocolOption(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogProtocolOption::IDD, pParent)
	, m_nLinkTestTime(0)
	, m_bUseConflictSolution(FALSE)
	, m_bWaitSendOkSignal(FALSE)
	, m_nCheckTimeout(2000)
	//, m_nResponseOkMemoryPos(2000)
	, m_sResponseOkTag(_T(""))
	, m_bSaveHeaderData(FALSE)
{
}

CDialogProtocolOption::~CDialogProtocolOption()
{
}

void CDialogProtocolOption::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_READ_SCHEDULE, m_list);
	DDX_Text(pDX, IDC_EDIT_LINK_TEST_TIME, m_nLinkTestTime);
	DDV_MinMaxUInt(pDX, m_nLinkTestTime, 2, 10000);
	DDX_Control(pDX, IDC_SPIN_SCHEDULE_LINK_TEST_TIME, m_spinLinkTestTime);
	DDX_Check(pDX, IDC_CHECK_CONFLICT_YIELD, m_bUseConflictSolution);
	DDX_Check(pDX, IDC_CHECK_USE_RESPONSE_OK, m_bWaitSendOkSignal);
	DDX_Text(pDX, IDC_EDIT_CHECK_TIMEOUT, m_nCheckTimeout);
	DDV_MinMaxUInt(pDX, m_nCheckTimeout, 100, 10000);
	DDX_Control(pDX, IDC_SPIN_CHECK_TIMEOUT, m_spinCheckTimeout);
	//DDX_Text(pDX, IDC_EDIT_STATUS_MEMORY_ADDRESS, m_nResponseOkMemoryPos);
	//DDV_MinMaxUInt(pDX, m_nResponseOkMemoryPos, 0, 65535);
	//DDX_Control(pDX, IDC_SPIN_STATUS_MEMORY_ADDRESS, m_spinResponseOkMemoryPos);
	DDX_Text(pDX, IDC_EDIT_STATUS_TAG_NAME, m_sResponseOkTag);
	DDX_Check(pDX, IDC_CHECK1, m_bSaveHeaderData);
}


BEGIN_MESSAGE_MAP(CDialogProtocolOption, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_EDIT, OnBnClickedButtonEdit)
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnBnClickedButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnBnClickedButtonDelete)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_READ_SCHEDULE, OnNMDblclkListReadSchedule)
	ON_BN_CLICKED(IDC_BUTTON_SF_EDIT, OnBnClickedButtonSfEdit)
	ON_BN_CLICKED(IDC_RADIO_HOST_MODE, OnBnClickedRadioHostMode)
	ON_BN_CLICKED(IDC_RADIO_EQUIP_MODE, OnBnClickedRadioEquipMode)
	ON_BN_CLICKED(IDC_RADIO_SERIAL_MODE, OnBnClickedRadioSerialMode)
	ON_BN_CLICKED(IDC_RADIO_HSMS_MODE, OnBnClickedRadioHsmsMode)
	ON_BN_CLICKED(IDC_CHECK_USE_RESPONSE_OK, OnBnClickedCheckUseResponseOk)	
	ON_BN_CLICKED(IDC_BUTTON_STATUS_TAG, OnBnClickedButtonStatusTag)
	ON_BN_CLICKED(IDC_BUTTON_WAIT_OK_FOR_EACH_SF, OnBnClickedButtonWaitOkForEachSf)
END_MESSAGE_MAP()


// CDialogProtocolOption message handlers

char checkReadCommand(char *buf)
{
	int			i;

	for(i = 0; i < 3; i++) 
		if(stricmp(buf, mem_buf[i]) == 0) return i;
	return -1;
}

/*char checkRealFunctionCommand(char *buf)
{
	int			i;

	for(i = 0; i < FUNCTION_LIMIT; i++) 
		if(strcmp(buf, real_func_buf[i]) == 0) return i;		
	
	return -1;
}

char checkFunctionCommand(char *buf)
{
	int			i;

	for(i = 0; i < FUNCTION_LIMIT; i++) 
		if(strncmp(buf, func_buf[i], strlen(func_buf[i])) == 0) return i;		
	
	return -1;
}

char getRealFunctionCommand(char *buf)
{
	int			i;

	for(i = 0; i < FUNCTION_LIMIT; i++) 
		if(stricmp(buf, func_buf[i]) == 0) return i;		
	
	return -1;
}*/



class SplitTextLine {
		CString save_data;
		int nPos;
	public:
		SplitTextLine();
		void Set(const char *buf);
		int GetOneLine(char *buf, int limit);
};

SplitTextLine::SplitTextLine()
{
	nPos = 0;
}

void SplitTextLine::Set(const char *buf)
{
	save_data = buf;
	nPos = 0;
}

int SplitTextLine::GetOneLine(char *buf, int limit)
{
	int fc;
	int bufpos = 0;

	while(1) {
		if(nPos >= (int)strlen(save_data))	break;
		//if(save_data[nPos] == NULL)	break;
		fc = save_data[nPos];
		nPos++;

		if(fc == 0x0d || fc == 0x0A) {                     // ���� ����
			if(fc == 0x0d) {
				//fgetc(in);
				nPos++;
			}
			buf[bufpos] = 0;
			return 1;
		}
		else {   			//
			if(bufpos < limit-1)
			buf[bufpos++] = fc;
		}
	}

	if(bufpos == 0)	return 0;

	buf[bufpos] = 0;

	return 1;
}


BOOL CDialogProtocolOption::GetReadSchedule()
{
	CommaBlockString	comma;
	int					i, pos;
	char				buf[200], imsi[50];//, funcImsi[50];
	StackChar 			string(30000);

	::GetWindowText(m_hwndEdit, string.data, 30000);
	
	SplitTextLine split;
	split.Set(string.data);
	pos = 0;

	while(1) {
		if(!split.GetOneLine(buf, sizeof(buf))) break;
		comma.Set(buf);
		comma.GetString(imsi, sizeof(imsi));
		if(checkReadCommand(imsi) == -1) continue;
		m_list.InsertItem(pos, imsi);
		for(i = 1; i < 7; i++) {	// node, type, start addr, target addr, size, 
			comma.GetString(imsi, sizeof(imsi));
			//if(i == 6) continue;	// sm->extra2 = ������

			/*if(i == 2) {			// function
				strcpy(funcImsi, imsi);
				j = checkRealFunctionCommand(imsi);
				if(j >= 0 && j < FUNCTION_LIMIT) m_list.SetItemText(pos, i, func_buf[j]);
				else m_list.SetItemText(pos, i, imsi);				
			}
			else*/
				m_list.SetItemText(pos, i, imsi);

		}
		pos++;
		if(pos > 1000) break;
	}	
	return TRUE;
}


int CDialogProtocolOption::GetSelectPosition()
{
	int		i;

	for(i = 0; i < m_list.GetItemCount(); i++) {
		if(m_list.GetItemState(i, LVIS_SELECTED)) {
			return i;
		}
	}

	return -1;
}



// CDialogProtocolOption message handlers

BOOL CDialogProtocolOption::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// TODO:  Add extra initialization here
	m_list.InsertColumn(0, "Memory Type", LVCFMT_CENTER, 100);
	m_list.InsertColumn(1, "Station", LVCFMT_CENTER, 70);
	m_list.InsertColumn(2, "Read Command", LVCFMT_CENTER, 140);
	m_list.InsertColumn(3, "Start Addr", LVCFMT_CENTER, 80);
	m_list.InsertColumn(4, "Buf Addr", LVCFMT_CENTER, 70);
	m_list.InsertColumn(5, "Read Size", LVCFMT_CENTER, 80);
	m_list.InsertColumn(6, "Periodic Read", LVCFMT_CENTER, 120);
	GetReadSchedule();
	checkAllRadioButton();
	m_spinLinkTestTime.SetRange(2, 10000);
	m_spinCheckTimeout.SetRange(100, 10000);
	//m_spinResponseOkMemoryPos.SetRange32(0, 65535);
	EnableDisable();
	m_tagPos = 0;		// add 2014-11-07
	m_tagType = 2;		// DI, add 2014-11-07
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CDialogProtocolOption::checkHexAddress(char *buf)
{
	int		i, len;
	
	len = (int)strlen(buf);
	for(i = 0; i < len; i++) {
		if(buf[i] == 'h' || buf[i] == 'H') return TRUE;
	}
	return FALSE;
}

static DWORD hexMul(int pos)
{
	int		i;
	DWORD	val = 1;

	if(pos > 8) return 1;

	for(i = 1; i < pos; i++) val *= 16;

	return val;
}

DWORD CDialogProtocolOption::HexBufToDec(char *buf)
{
	int		i, len, pos;
	DWORD	val = 0;

	
	len = (int)strlen(buf);
	for(i = 0; i < len; i++) {
		if(buf[i] >= '0' && buf[i] <= '9') continue;
		if(buf[i] >= 'a' && buf[i] <= 'f') continue;
		if(buf[i] >= 'A' && buf[i] <= 'F') continue;
		break;
	}
	len = i;
	
	for(i = 0, pos = len; i < len; i++, pos--) {
		if(buf[i] >= '0' && buf[i] <= '9') val += hexMul(pos) * (DWORD)(buf[i]-'0');
		if(buf[i] >= 'a' && buf[i] <= 'f') val += hexMul(pos) * (DWORD)(buf[i]-'a'+10);
		if(buf[i] >= 'A' && buf[i] <= 'F') val += hexMul(pos) * (DWORD)(buf[i]-'A'+10);		
	}
	return val;
}

WORD CDialogProtocolOption::getHexDecimalValue(WORD currPos, WORD listPos, BOOL &bHexValue)
{
	char		imsi[30];
	WORD		val;
	
	m_list.GetItemText(currPos, listPos, imsi, sizeof(imsi));
	bHexValue = checkHexAddress(imsi);
	if(bHexValue) val = (WORD)HexBufToDec(imsi);
	else		  val = (WORD)atoi(imsi);
	return val;
}

void CDialogProtocolOption::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class
	int					i, len;
	int					readType, bufAddr, readSize;
	long				extra2;
	CString				string;
	char				imsi[30], nodeNo[30], function[50], startAddr[30];
	StackChar 			buf(30000);
	
	memset(buf.data, 0, sizeof(buf.data));
	for(i = 0, len = 0; i < m_list.GetItemCount(); i++) {
		m_list.GetItemText(i, 0, imsi, sizeof(imsi));
		readType = checkReadCommand(imsi);
		m_list.GetItemText(i, 1, nodeNo, sizeof(nodeNo));
		m_list.GetItemText(i, 2, function, sizeof(function));
		//j = getRealFunctionCommand(function);
		//if(j >= 0 && j < FUNCTION_LIMIT) strcpy(function, real_func_buf[j]);
		m_list.GetItemText(i, 3, startAddr, sizeof(startAddr));
		string = m_list.GetItemText(i, 4);
		bufAddr = atoi(string);
		string = m_list.GetItemText(i, 5);
		readSize = atoi(string);
		string = m_list.GetItemText(i, 6);
		extra2 = atol(string);
		
		if((readType % 3) == 0) 
			sprintf(&buf.data[len],	"%s,%6s,%6s,%6s,%5d,%4d,%4d,\r\n", mem_buf[readType % 3], nodeNo, function, startAddr, bufAddr, readSize, extra2);
		else
			sprintf(&buf.data[len],	"%s,%5s,%6s,%6s,%5d,%4d,%4d,\r\n", mem_buf[readType % 3], nodeNo, function, startAddr, bufAddr, readSize, extra2);
		
		len = (int)strlen(buf.data);
		if(len > 29960) len = 0;
	}
	::SetWindowText(m_hwndEdit, buf.data);

	if(IsDlgButtonChecked(IDC_RADIO_EQUIP_MODE)) m_bEquip = true;
	else m_bEquip = false;
	if(IsDlgButtonChecked(IDC_RADIO_HSMS_MODE)) m_bHsms = true;
	else m_bHsms = false;
	CDialog::OnOK();
}

bool getStreamFunctionData(char *device, BYTE &cStream, BYTE &cFunction);

void CDialogProtocolOption::getCurrReadData(CDialogReadSchedule &dialog, BOOL &bHexStation, BOOL &bHexAddress)
{
	CString					buf;
	char					imsi[50];
	int						i;

	m_list.GetItemText(dialog.m_currPos, 0, imsi, sizeof(imsi));
	i = checkReadCommand(imsi);
	dialog.m_memory = i % 3;
	dialog.m_station = (BYTE)getHexDecimalValue(dialog.m_currPos, 1, bHexStation);
	m_list.GetItemText(dialog.m_currPos, 2, imsi, sizeof(imsi));
	//i = checkFunctionCommand(imsi);
	//dialog.m_function = (i >= 0 && i < FUNCTION_LIMIT) ? i : 6;
	getStreamFunctionData(imsi, dialog.m_stream, dialog.m_function);
	//if(dialog.m_stream >= 1) dialog.m_stream--;
	//if(dialog.m_function >= 1) dialog.m_function--;
	dialog.m_startAddr = getHexDecimalValue(dialog.m_currPos, 3, bHexAddress);
	buf = m_list.GetItemText(dialog.m_currPos, 4);
	dialog.m_bufAddr = atoi(buf);
	buf = m_list.GetItemText(dialog.m_currPos, 5);
	dialog.m_readSize = atoi(buf);
	buf = m_list.GetItemText(dialog.m_currPos, 6);
	dialog.m_periodicRead = atol(buf);
	dialog.m_bUsePeriodicRead = (dialog.m_periodicRead <= 0) ? false : true;
}


void CDialogProtocolOption::setOkReadData(CDialogReadSchedule &dialog, BOOL bHexStation, BOOL bHexAddress)
{
	CString					buf;	

	if(bHexStation)	buf.Format("%Xh", dialog.m_station);
	else            buf.Format("%d", dialog.m_station);
	m_list.SetItemText(dialog.m_currPos, 1, buf);
	//m_list.SetItemText(dialog.m_currPos, 2, func_buf[dialog.m_function%FUNCTION_LIMIT]);
	buf.Format("%1d.%1d", dialog.m_stream, dialog.m_function);
	m_list.SetItemText(dialog.m_currPos, 2, buf);
	if(bHexAddress)	buf.Format("%Xh", dialog.m_startAddr);
	else            buf.Format("%d", dialog.m_startAddr);
	m_list.SetItemText(dialog.m_currPos, 3, buf);
	buf.Format("%d", dialog.m_bufAddr);
	m_list.SetItemText(dialog.m_currPos, 4, buf);
	buf.Format("%d", dialog.m_readSize);
	m_list.SetItemText(dialog.m_currPos, 5, buf);
	buf.Format("%d", dialog.m_periodicRead);
	m_list.SetItemText(dialog.m_currPos, 6, buf);
}


void CDialogProtocolOption::OnBnClickedButtonEdit()
{
	// TODO: Add your control notification handler code here
	CDialogReadSchedule		dialog;
	BOOL					bHexStation, bHexAddress;	

	dialog.m_currPos = GetSelectPosition();
	if(dialog.m_currPos == -1) {
		MessageBox("Select One Read Schedule.", "Select Error");
		return;
	}
	getCurrReadData(dialog, bHexStation, bHexAddress);	

	int retn = (int)dialog.DoModal();
	if(retn == IDOK) {
		m_list.SetItemText(dialog.m_currPos, 0, mem_buf[dialog.m_memory%3]);
		setOkReadData(dialog, bHexStation, bHexAddress);		
	}
}

void CDialogProtocolOption::OnBnClickedButtonAdd()
{
	// TODO: Add your control notification handler code here
	CDialogReadSchedule		dialog;
	BOOL					bHexStation = FALSE, bHexAddress = FALSE;
	
	dialog.m_currPos = GetSelectPosition();	
	if(dialog.m_currPos == -1) {
		dialog.m_memory = 0;
		dialog.m_station = 1;
		dialog.m_stream = 1;
		dialog.m_function = 1;
		dialog.m_startAddr = 0;
		dialog.m_bufAddr = 0;
		dialog.m_readSize = 1;
		dialog.m_periodicRead = 0;
		dialog.m_bUsePeriodicRead = (dialog.m_periodicRead <= 0) ? false : true;
	}
	else {
		getCurrReadData(dialog, bHexStation, bHexAddress);	
	}
	dialog.m_currPos = m_list.GetItemCount();	

	int retn = (int)dialog.DoModal();
	if(retn == IDOK) {
		m_list.InsertItem(dialog.m_currPos, mem_buf[dialog.m_memory%3]);		
		setOkReadData(dialog, bHexStation, bHexAddress);		
	}
}

void CDialogProtocolOption::OnBnClickedButtonDelete()
{
	// TODO: Add your control notification handler code here
	CDialogDeleteConfirm	dialog;
	CString					buf;
	char					imsi[50];
	BOOL					bHexStation, bHexAddress;
	int						readType, nodeNo, startAddr, bufAddr, readSize;
	DWORD					periodicRead;
	
	dialog.m_currPos = GetSelectPosition();
	if(dialog.m_currPos == -1) {
		MessageBox("Select One Read Schedule.", "Select Error");
		return;
	}
	
	m_list.GetItemText(dialog.m_currPos, 0, imsi, sizeof(imsi));
	readType = checkReadCommand(imsi);
	nodeNo = getHexDecimalValue(dialog.m_currPos, 1, bHexStation);
	startAddr = getHexDecimalValue(dialog.m_currPos, 3, bHexAddress);	
	m_list.GetItemText(dialog.m_currPos, 2, imsi, sizeof(imsi));
	buf = m_list.GetItemText(dialog.m_currPos, 4);
	bufAddr = atoi(buf);
	buf = m_list.GetItemText(dialog.m_currPos, 5);
	readSize = atoi(buf);
	buf = m_list.GetItemText(dialog.m_currPos, 6);
	periodicRead = atol(buf);
	dialog.m_bMessageChange = false;
	
	dialog.readSchBuf.Format("%s,   %8d,   %8s,   %8d,   %8d,   %8d,   %8ld,", mem_buf[readType % 3], nodeNo, imsi, startAddr, bufAddr, readSize, periodicRead);
		
	int retn = (int)dialog.DoModal();
	if(retn == IDOK) {
		m_list.DeleteItem(dialog.m_currPos);
	}
}

void CDialogProtocolOption::OnNMDblclkListReadSchedule(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	OnBnClickedButtonEdit();
	*pResult = 0;
}

void CDialogProtocolOption::OnBnClickedButtonSfEdit()
{
	// TODO: Add your control notification handler code here
	CDialogSfEditMain		dialog;

	dialog.m_nPort = m_nPort;
	int retn = (int)dialog.DoModal();
	if(retn == IDOK) {		
	}
	dialog.deleteSfMemory2();
}

void CDialogProtocolOption::checkAllRadioButton()
{
	if(m_bEquip) CheckRadioButton(IDC_RADIO_HOST_MODE, IDC_RADIO_EQUIP_MODE, IDC_RADIO_EQUIP_MODE);	
	else CheckRadioButton(IDC_RADIO_HOST_MODE, IDC_RADIO_EQUIP_MODE, IDC_RADIO_HOST_MODE);	
	if(m_bHsms) CheckRadioButton(IDC_RADIO_SERIAL_MODE, IDC_RADIO_HSMS_MODE, IDC_RADIO_HSMS_MODE);	
	else CheckRadioButton(IDC_RADIO_SERIAL_MODE, IDC_RADIO_HSMS_MODE, IDC_RADIO_SERIAL_MODE);
}

void CDialogProtocolOption::OnBnClickedRadioHostMode()
{
	// TODO: Add your control notification handler code here
	m_bEquip = false;
	checkAllRadioButton();
	EnableDisable();
}

void CDialogProtocolOption::OnBnClickedRadioEquipMode()
{
	// TODO: Add your control notification handler code here
	m_bEquip = true;
	checkAllRadioButton();
	EnableDisable();
}

void CDialogProtocolOption::OnBnClickedRadioSerialMode()
{
	// TODO: Add your control notification handler code here
	m_bHsms = false;
	checkAllRadioButton();
	EnableDisable();
}

void CDialogProtocolOption::OnBnClickedRadioHsmsMode()
{
	// TODO: Add your control notification handler code here
	m_bHsms = true;
	checkAllRadioButton();
	EnableDisable();
}


void CDialogProtocolOption::EnableDisable()
{
	GetDlgItem(IDC_EDIT_LINK_TEST_TIME)->EnableWindow(m_bHsms);
	GetDlgItem(IDC_SPIN_SCHEDULE_LINK_TEST_TIME)->EnableWindow(m_bHsms);	
	if(m_bEquip == false && m_bHsms == false) {
		GetDlgItem(IDC_CHECK_CONFLICT_YIELD)->EnableWindow(true);
		GetDlgItem(IDC_TEXT_ENQ_CONTENTION)->EnableWindow(true);
	}
	else {
		GetDlgItem(IDC_CHECK_CONFLICT_YIELD)->EnableWindow(false);
		GetDlgItem(IDC_TEXT_ENQ_CONTENTION)->EnableWindow(false);
	}
	bool	flag = (m_bWaitSendOkSignal) ? true : false;
	GetDlgItem(IDC_BUTTON_STATUS_TAG)->EnableWindow(flag);
	//GetDlgItem(IDC_EDIT_STATUS_TAG_NAME)->EnableWindow(flag);
	GetDlgItem(IDC_EDIT_CHECK_TIMEOUT)->EnableWindow(flag);
	GetDlgItem(IDC_SPIN_CHECK_TIMEOUT)->EnableWindow(flag);
	GetDlgItem(IDC_BUTTON_WAIT_OK_FOR_EACH_SF)->EnableWindow(flag);
}

void CDialogProtocolOption::OnBnClickedCheckUseResponseOk()
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	EnableDisable();
}


void CDialogProtocolOption::OnBnClickedButtonStatusTag()
{
	// TODO: Add your control notification handler code here
	CDialogSelectTag	dialog;

	dialog.m_currPos = m_tagPos;
	dialog.m_tagType = m_tagType;
	if(dialog.DoModal() != IDOK) return;
	m_tagPos = dialog.m_currPos;
	m_tagType = dialog.m_tagType;
	m_sResponseOkTag.Format("%s", dialog.mTagName);
	UpdateData(FALSE);
}

void CDialogProtocolOption::OnBnClickedButtonWaitOkForEachSf()
{
	// TODO: Add your control notification handler code here
	CDialogWaitOkTagSf	dialog;

	dialog.ptNo = m_nPort;
	if(dialog.DoModal() != IDOK) return;
	
}
