#pragma once
#include "afxwin.h"


// CDialogEditAddSfData dialog

class CDialogEditAddSfData : public CDialog
{
	DECLARE_DYNAMIC(CDialogEditAddSfData)

public:
	CDialogEditAddSfData(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDialogEditAddSfData();

// Dialog Data
	enum { IDD = IDD_DIALOG_EDIT_SF };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CComboBox m_comboStream;
	CComboBox m_comboFunction;
	virtual BOOL OnInitDialog();

	int		m_currPos;
	BYTE	m_stream;
	BYTE	m_function;

protected:
	virtual void OnOK();
};
