#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CDialogSelectSfAndTag dialog

class CDialogSelectSfAndTag : public CDialog
{
	DECLARE_DYNAMIC(CDialogSelectSfAndTag)

public:
	CDialogSelectSfAndTag(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDialogSelectSfAndTag();

// Dialog Data
	enum { IDD = IDD_DIALOG_SELECT_SF_AND_TAG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
protected:
	virtual void OnOK();
public:
	CListCtrl m_list;
	CComboBox m_comboStream;
	CComboBox m_comboFunction;

	BYTE	m_stream;
	BYTE	m_function;
	void	checkCurrPos();
	bool	isTagTypeMached(int nTagType);
	void	GetCurrSelPosFromTagName();
	void	GetCurrentTag();
	int		GetSelectPosition();

	int			m_tagType;	// 0 = AI, 1= AO, 2= DI, ...
	int			m_currSel;
	char		mTagName[80];
	//char		mTagDesc[80];
	afx_msg void OnBnClickedRadioAnalogInput();
	afx_msg void OnBnClickedRadioDigitalInput();
	afx_msg void OnNMDblclkListSelectTag(NMHDR *pNMHDR, LRESULT *pResult);
};
