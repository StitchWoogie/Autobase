#include "stdafx.h"
#include "SECS_HostDef.h"



/*bool getStreamFunctionFileReal(LOCAL_PORT_STRUCT *pt, int no)
{
	FILE				*in;
	CommaBlockString	comma;
	int					i, pos = 0, nDataType, nDataSize;
	char				imsi[41], filename[MAXPATH];
	CString				buf;
	
	sprintf(filename, "%s\\SCAN\\%03d\\SF%03d.ini", sWorkDir, pt->no, no);
	in = fopen(filename, "rb");
	if(in == NULL) return false;
	if(getStreamFunctionNoFormFile(in, localVars->sfData[no].cStream, localVars->sfData[no].cFunction) == false) {
		fclose(in);	
		return false;
	}

	while(TextGetOneLine(in, buf)) {		
		if(pos++ > 1000) break;
		if(buf.GetLength() <= 0) continue;

		comma.Set(buf);
		if(comma.IsEOS()) continue;
		comma.GetString(imsi, sizeof(imsi));
		if((int)strlen(imsi) <= 0) continue;
		nDataType = getSecsDataType(imsi);
		if(nDataType == DATA_UNKNOWN_TYPE) continue;

		//if(pos == 0) {
		//	getStreamFunctionData(imsi, localVars->sfData[no].cStream, localVars->sfData[no].cFunction);
		//	pos++;
		//	continue;
		//}
		
		comma.GetInt(nDataSize);
		localVars->sfData[no].nList = 0;
		if(nDataSize <= 0) continue;
		localVars->sfData[no].nDataType = nDataType;
		
		if(nDataType == DATA_TYPE_LIST) {
			localVars->sfData[no].list = (SECS_DATA *)calloc(nDataSize, sizeof(struct SECS_DATA));
			localVars->sfData[no].nList = nDataSize;
			for(i = 0; i < nDataSize; i++) getOneListData((SECS_DATA *)&localVars->sfData[no].list[i], in, pos);
		}
		else {
			getOneRealSfData(&localVars->sfData[no].realData, (char *)buf.GetString(), nDataType, nDataSize);			
		}
		localVars->sfData[no].bExist = true;
	}
	fclose(in);	
	return true;
}*/



void getStreamFunctionFile(LOCAL_PORT_STRUCT *pt)
{
	int		i;

	localVars->nReadStreamFunction = 0;
	for(i = 0; i < MAX_STREAM_FUNCTION_DATA; i++) {
		if(getStreamFunctionFileReal(&localVars->sfData[i], pt->no, i)) localVars->nReadStreamFunction++;
	}
}

void deleteSfMemoryStringBuf(SECS_REAL_DATA *data)
{
	if(data->nDataCount <= 0) return;

	if(isAsciiData(data->nDataType)) {
		if(data->data->string != NULL) delete data->data->string;
	}
	if(data->data != NULL) delete data->data;
}

void deleteSfMemoryReal(SECS_DATA *listData)
{
	if(listData->nDataType != DATA_TYPE_LIST) deleteSfMemoryStringBuf(&listData->realData);
	else {		
		if(listData->nList <= 0) return;
		SECS_DATA	*list;
		for(int i = 0; i < listData->nList; i++) {
			list = &listData->list[i];
			deleteSfMemoryReal(list);
		}
		delete listData->list;
		listData->list = NULL;
	}
	
}

void deleteSfMemoryOne(LOCAL_PORT_STRUCT *pt, int no)
{
	int			nList;

	if(no < 0 || no >= MAX_STREAM_FUNCTION_DATA || localVars->sfData[no].bExist == false) return;
	if(localVars->sfData[no].nDataType != DATA_TYPE_LIST) deleteSfMemoryStringBuf(&localVars->sfData[no].realData);
	for(nList = 0; nList < localVars->sfData[no].nList; nList++) deleteSfMemoryReal(&localVars->sfData[no].list[nList]);
	if(localVars->sfData[no].nList > 0) delete localVars->sfData[no].list;
	localVars->sfData[no].bExist = false;
}

void deleteSfMemory(LOCAL_PORT_STRUCT *pt)
{
	for(int i = 0; i < MAX_STREAM_FUNCTION_DATA; i++) deleteSfMemoryOne(pt, i);		
}
