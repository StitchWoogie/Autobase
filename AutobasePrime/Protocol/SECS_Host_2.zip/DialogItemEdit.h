#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CDialogItemEdit dialog

class CDialogItemEdit : public CDialog
{
	DECLARE_DYNAMIC(CDialogItemEdit)

public:
	CDialogItemEdit(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDialogItemEdit();

// Dialog Data

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CComboBox m_itemType;
	virtual BOOL OnInitDialog();

	void GetCurrentTag();
	DWORD SearchTagNamePos();
	int GetSelectPosition();
	void EnableDisable();

	int		m_itemNo;
	int		m_itemNewNo;
	int		nRadioSelection;
	CString m_tagName;
	CString m_allValue;
	DWORD	tagPos;

protected:
	virtual void OnOK();
public:
	CListCtrl m_list;
	afx_msg void OnNMDblclkListTag(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedRadioAi();
	afx_msg void OnBnClickedRadioAo();
	afx_msg void OnBnClickedRadioDi();
	afx_msg void OnBnClickedRadioDo();
	afx_msg void OnBnClickedRadioSt();	
	afx_msg void OnCbnSelchangeComboItemType();
	afx_msg void OnBnClickedButtonAddData();
	afx_msg void OnBnClickedButtonDeleteData();
	afx_msg void OnBnClickedButtonTagAdd();
	CString m_CurrValue;
};
