#pragma once
#include "afxwin.h"


// CDialogDeleteConfirm dialog

class CDialogDeleteConfirm : public CDialog
{
	DECLARE_DYNAMIC(CDialogDeleteConfirm)

public:
	CDialogDeleteConfirm(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDialogDeleteConfirm();

// Dialog Data
	enum { IDD = IDD_DIALOG_DELETE_CONFIRM };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CStatic m_text;
	CStatic m_textMessage;
	virtual BOOL OnInitDialog();

	int				m_currPos;
	CString			readSchBuf;
	CString			MessageText;
	bool			m_bMessageChange;
};
