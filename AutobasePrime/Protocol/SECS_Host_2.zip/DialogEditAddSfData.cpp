// DialogEditAddSfData.cpp : implementation file
//

#include "stdafx.h"
#include "SECS_Host.h"
#include "SECS_HostDef.h"
#include "DialogEditAddSfData.h"


// CDialogEditAddSfData dialog

IMPLEMENT_DYNAMIC(CDialogEditAddSfData, CDialog)
CDialogEditAddSfData::CDialogEditAddSfData(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogEditAddSfData::IDD, pParent)
{
}

CDialogEditAddSfData::~CDialogEditAddSfData()
{
}

void CDialogEditAddSfData::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_FUNCTION, m_comboStream);
	DDX_Control(pDX, IDC_COMBO_FUNCTION2, m_comboFunction);
}


BEGIN_MESSAGE_MAP(CDialogEditAddSfData, CDialog)
END_MESSAGE_MAP()


// CDialogEditAddSfData message handlers

BOOL CDialogEditAddSfData::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	int			i;
	char		imsi[10];

	for(i = 0; i < MAX_STREAM_COUNT; i++) {
		sprintf(imsi, "%03d", i);
		m_comboStream.AddString(imsi);
	}
	m_comboStream.SetCurSel(m_stream%MAX_STREAM_COUNT);
	for(i = 0; i < MAX_FUNCTION_COUNT; i++) {
		sprintf(imsi, "%03d", i);
		m_comboFunction.AddString(imsi);
	}
	m_comboFunction.SetCurSel(m_function%MAX_FUNCTION_COUNT);
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDialogEditAddSfData::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class
	m_stream = m_comboStream.GetCurSel();
	m_function = m_comboFunction.GetCurSel();
	//if(m_stream < MAX_STREAM_COUNT) m_stream++;
	//if(m_function < MAX_FUNCTION_COUNT) m_function++;
	CDialog::OnOK();
}
