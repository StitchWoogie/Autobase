// DialogSfEditMain.cpp : implementation file
//

#include "stdafx.h"
#include <io.h>
#include "SECS_Host.h"
#include "SECS_HostDef.h"
#include "DialogSfEditMain.h"
#include "DialogEditAddSfData.h"
#include "DialogDeleteConfirm.h"
#include "DialogItemEdit.h"
#include "..\..\catlib\CatTag9.h"
#include "..\..\catlib\CatTag.h"
#include ".\dialogsfeditmain.h"


extern char sWorkDir[MAX_PATH];
static STREAM_FUNCTION_DATA sfData[MAX_STREAM_FUNCTION_DATA];


char	itemType_buf[MAX_ITEM_TYPE][10] = { "LIST", "BIN", "BOOL", "ASCII", "JIS", "INT8", "INT16", "INT32", "INT64", "UINT8", "UINT16", "UINT32", "UINT64", "FLOAT32", "FLOAT64" };

// CDialogSfEditMain dialog

IMPLEMENT_DYNAMIC(CDialogSfEditMain, CDialog)
CDialogSfEditMain::CDialogSfEditMain(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogSfEditMain::IDD, pParent)
	, m_itemValue(_T(""))
	, m_itemCount(_T(""))
{
}

CDialogSfEditMain::~CDialogSfEditMain()
{
}

void CDialogSfEditMain::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_READ_SCHEDULE, m_list);
	DDX_Control(pDX, IDC_TREE_SF_EDIT, m_tree);
	DDX_Control(pDX, IDC_COMBO_ITEM_SELECTED, m_itemType);
	DDX_Text(pDX, IDC_EDIT_ITEM_VALUE, m_itemValue);
	DDX_Text(pDX, IDC_EDIT_ITEM_COUNT, m_itemCount);
	DDX_Control(pDX, IDC_COMBO_ITEM_TYPE, m_comboItemAdd);
	DDX_Control(pDX, IDC_LIST_TAG, m_tagList);
}


BEGIN_MESSAGE_MAP(CDialogSfEditMain, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_EDIT, OnBnClickedButtonEdit)
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnBnClickedButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnBnClickedButtonDelete)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_READ_SCHEDULE, OnNMDblclkListReadSchedule)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE_SF_EDIT, OnTvnSelchangedTreeSfEdit)
	//ON_BN_CLICKED(IDC_BUTTON_EDIT_DATA, OnBnClickedButtonEditData)
	ON_BN_CLICKED(IDC_BUTTON_ADD_DATA, OnBnClickedButtonAddData)
	ON_BN_CLICKED(IDC_BUTTON_DELETE_DATA, OnBnClickedButtonDeleteData)
	ON_BN_CLICKED(IDC_BUTTON_UPDATE_DATA, OnBnClickedButtonUpdateData)
	ON_CBN_SELCHANGE(IDC_COMBO_ITEM_TYPE, OnCbnSelchangeComboItemType)
	ON_BN_CLICKED(IDC_RADIO_ANALOG_INPUT, OnBnClickedRadioAnalogInput)
	ON_BN_CLICKED(IDC_RADIO_ANALOG_OUTPUT, OnBnClickedRadioAnalogOutput)
	ON_BN_CLICKED(IDC_RADIO_DIGITAL_INPUT, OnBnClickedRadioDigitalInput)
	ON_BN_CLICKED(IDC_RADIO_DIGITAL_OUTPUT, OnBnClickedRadioDigitalOutput)	
	ON_BN_CLICKED(IDC_BUTTON_TAG_VALUE_ADD, OnBnClickedButtonTagValueAdd)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_TAG, OnNMDblclkListTag)
	ON_NOTIFY(NM_CLICK, IDC_LIST_READ_SCHEDULE, OnNMClickListReadSchedule)
	ON_BN_CLICKED(IDC_RADIO_TAG_STRING, OnBnClickedRadioTagString)
END_MESSAGE_MAP()


// CDialogSfEditMain message handlers

void CDialogSfEditMain::setTreeExpandAndCheckOneNode(HTREEITEM hItemParent)
{
	if(hItemParent == NULL) return;	
	m_tree.Expand(hItemParent, TVE_EXPAND);
	m_tree.EnsureVisible(hItemParent);
	if(m_tree.ItemHasChildren(hItemParent) == false) return;

	HTREEITEM		hItem = m_tree.GetChildItem(hItemParent);
	int				pos = 0;
	while(1) {
		if(pos++ > 2000) break;		// changed 2016-08-26, 1000->2000
		if(pos == 1) setTreeExpandAndCheckOneNode(hItem);
		else {
			hItem = m_tree.GetNextItem(hItem, TVGN_NEXT);
			if(hItem == NULL) break;
			setTreeExpandAndCheckOneNode(hItem);
		}
	}	
}

void CDialogSfEditMain::setTreeExpandAndCheck()
{
	HTREEITEM hItemParent = m_tree.GetRootItem();
	if(hItemParent == NULL) return;
	m_tree.Expand(hItemParent, TVE_EXPAND);
	m_tree.EnsureVisible(hItemParent);
	if(m_tree.ItemHasChildren(hItemParent) == false) {
		m_tree.SelectItem(hItemParent);
		return;
	}

	HTREEITEM		hItem = m_tree.GetChildItem(hItemParent);
	int				pos = 0;
	while(1) {
		if(pos++ > 2000) break;		// changed 2016-08-26, 1000->2000
		if(pos == 1) setTreeExpandAndCheckOneNode(hItemParent);
		else {
			hItem = m_tree.GetNextItem(hItem, TVGN_NEXT);
			if(hItem == NULL) break;
			setTreeExpandAndCheckOneNode(hItem);
		}
	}	
	m_tree.SelectItem(hItemParent);
}

void CDialogSfEditMain::setTreeExpandAndCheckCurr()
{
	HTREEITEM hItemParent = m_tree.GetSelectedItem();
	if(hItemParent == NULL) return;
	m_tree.Expand(hItemParent, TVE_EXPAND);
	m_tree.EnsureVisible(hItemParent);
	if(m_tree.ItemHasChildren(hItemParent) == false) {
		m_tree.SelectItem(hItemParent);
		return;
	}

	HTREEITEM		hItem = m_tree.GetChildItem(hItemParent);
	int				pos = 0;
	while(1) {
		if(pos++ > 2000) break;		// changed 2016-08-26, 1000->2000
		if(pos == 1) setTreeExpandAndCheckOneNode(hItemParent);
		else {
			hItem = m_tree.GetNextItem(hItem, TVGN_NEXT);
			if(hItem == NULL) break;
			setTreeExpandAndCheckOneNode(hItem);
		}
	}	
	m_tree.SelectItem(hItemParent);
}

BOOL CDialogSfEditMain::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	AutoBaseIniGetProjectDirectory(sWorkDir);
	m_list.InsertColumn(0, "No.", LVCFMT_CENTER, 100);
	m_list.InsertColumn(1, "Stream/Function", LVCFMT_CENTER, 150);
	m_tagList.InsertColumn(0, "No.", LVCFMT_CENTER, 70);
	m_tagList.InsertColumn(1, "Tag Name", LVCFMT_LEFT, 200);
	m_tagList.InsertColumn(2, "Tag Description", LVCFMT_LEFT, 200);	
	for(int i = 0; i < MAX_ITEM_TYPE; i++) m_itemType.AddString(itemType_buf[i]);
	for(int i = 0; i < MAX_ITEM_TYPE; i++) m_comboItemAdd.AddString(itemType_buf[i]);
	
	m_currPos = 0;
	m_itemNoAdd = 0;
	getStreamFunctionFile2();
	setSfDataToList();
	setSfDataToTree();
	m_itemType.SetCurSel(m_itemNo%MAX_ITEM_TYPE);
	m_comboItemAdd.SetCurSel(m_itemNoAdd%MAX_ITEM_TYPE);
	GetCurrentTag(0);
	
	m_list.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
	m_list.EnsureVisible(0, false);
	m_tagList.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
	m_tagList.EnsureVisible(0, false);
	CheckRadioButton(IDC_RADIO_ANALOG_INPUT, IDC_RADIO_TAG_STRING, IDC_RADIO_ANALOG_INPUT);
	EnableDisable();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDialogSfEditMain::saveOrDeleteSfDataFile()
{
	char		filename[MAXPATH];

	sprintf(filename, "%s\\SCAN\\%03d", sWorkDir, m_nPort);
	if(_access(filename, 0) == -1) CreateDirectory(filename, NULL);

	for(int i = 0; i < MAX_STREAM_FUNCTION_DATA; i++) {
		if(sfData[i].nFileNo < 0 || sfData[i].nFileNo >= MAX_STREAM_FUNCTION_DATA || sfData[i].bChange == false) continue;
		if(sfData[i].bExist == false) {			
			sprintf(filename, "%s\\SCAN\\%03d\\SF%03d.ini", sWorkDir, m_nPort, sfData[i].nFileNo);
			if(_access(filename, 0) != -1) DeleteFile(filename);
		}
		else {
			sprintf(filename, "%s\\SCAN\\%03d\\SF%03d.ini", sWorkDir, m_nPort, sfData[i].nFileNo);
			saveOneSfDataToFile(&sfData[i], filename);
		}
	}
}

void CDialogSfEditMain::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_bChangeCurrTree) {
		deleteSfMemoryOne2(m_nMemPos);
		getStreamFunctionTreeToMemory(m_nMemPos);
		if(m_nMemPos >= 0 && m_nMemPos < MAX_STREAM_FUNCTION_DATA) sfData[m_nMemPos].bChange = true;
	}
	saveOrDeleteSfDataFile();
	CDialog::OnOK();
}

int CDialogSfEditMain::getNextValidBufPos(int &stream, int &function)
{	
	if(function >= MAX_FUNCTION_COUNT-1) {
		stream++;
		function = 0;
	}
	else function++;
	if(stream >= MAX_STREAM_COUNT) return -1;

	for(int i = 0; i < MAX_STREAM_FUNCTION_DATA; i++) {
		if(sfData[i].bExist == false) continue;
		if((BYTE)stream == sfData[i].cStream && (BYTE)function == sfData[i].cFunction) return i;
	}
	return -1;
}

void CDialogSfEditMain::setSfDataToList()
{
	int			memPos, pos = 0, stream = 0, function = 0;
	char		imsi[20];

	//for(i = 0, pos = 0; i < MAX_STREAM_FUNCTION_DATA; i++) {
	while(1) {
		memPos = getNextValidBufPos(stream, function);
		if(stream >= MAX_STREAM_COUNT) break;
		if(memPos < 0 || memPos >= MAX_STREAM_FUNCTION_DATA) continue;
		if(sfData[memPos].bExist == false) continue;

		sprintf(imsi, "%03d", pos+1);
		m_list.InsertItem(pos, imsi);
		sprintf(imsi, "%1d.%1d", sfData[memPos].cStream, sfData[memPos].cFunction);
		m_list.SetItemText(pos, 1, imsi);
		if(pos++ >= MAX_STREAM_FUNCTION_DATA) break;
	}
}

HTREEITEM CDialogSfEditMain::setOneDataTreeReal(HTREEITEM hItem, char *data, int nIndex)
{
	TVINSERTSTRUCT		tvins;
	TVITEM				item;

	item.mask = TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE;
	item.pszText = data;
	item.iImage = 0;
	item.iSelectedImage = 0;
	if(nIndex == 0) tvins.hInsertAfter = TVI_FIRST;
	else tvins.hInsertAfter = TVI_LAST;
	
	tvins.item = item;
	if(nIndex == 0) tvins.hParent = TVI_ROOT;
	else tvins.hParent = hItem;
	return m_tree.InsertItem(&tvins);
}


HTREEITEM CDialogSfEditMain::addOneListDataTree(HTREEITEM hItem, int nDataSize, int nIndex)
{
	char	imsi[20];

	sprintf(imsi, "LIST(%01d)", nDataSize);
	return setOneDataTreeReal(hItem, imsi, nIndex);
}

HTREEITEM CDialogSfEditMain::addOneRealDataTree(HTREEITEM hItem, int nItemNo, CString val, int nIndex)
{
	CString		imsi;

	if(val.GetLength() <= 0) {
		val = "0";
		if(isAsciiData(getSecsDataNoToDataType(nItemNo))) val = "test";
		//MessageBox("Please Input Item Value.", "Item Value Input Error");
		//return NULL;
	}

	//val = setStringDataDeleteEmptyData(val);
	int	count = getStringToItemCountToBuf(val, nItemNo);
	if(count < 0) count = 0;

	//if(val.GetLength() > 0) 
		imsi.Format("%s(%01d) = %s", itemType_buf[nItemNo % MAX_ITEM_TYPE], count, val);
	//else
	//	imsi.Format("%s(%01d)", itemType_buf[nItemNo % MAX_ITEM_TYPE], nDataSize);
	return setOneDataTreeReal(hItem, (char *)imsi.GetString(), nIndex);
}

void CDialogSfEditMain::updateListDataTreeCount(HTREEITEM hItem, int inc)
{
	if(hItem == NULL) return;

	int			count, itemNo;
	CString		data, val = "", buf = m_tree.GetItemText(hItem);
		
	itemNo = getSecsDataTypeNo((char *)buf.GetString());
	count = getStringToItemCount(buf);
	count += inc;
	if(count < 0) count = 0;
	if(itemNo == 0) {
		data.Format("%s(%01d)", itemType_buf[itemNo % MAX_ITEM_TYPE], count);
	}
	else {
		if(getStringToDataValue(buf, val)) data.Format("%s(%01d) = %s", itemType_buf[itemNo % MAX_ITEM_TYPE], count, val);
		else data.Format("%s(%01d)", itemType_buf[itemNo % MAX_ITEM_TYPE], count);
	}
	m_tree.SetItemText(hItem, data);
}

void CDialogSfEditMain::updateListDataTreeRealData(HTREEITEM hItem, CString val)
{
	if(hItem == NULL) return;

	int			count, itemNo;
	CString		data, buf = m_tree.GetItemText(hItem);	
		
	itemNo = getSecsDataTypeNo((char *)buf.GetString());
	if(itemNo == 0) return;// list

	val = setStringDataDeleteEmptyData(val);
	count = getStringToItemCountToBuf(val, itemNo);
	if(count < 0) count = 0;
	if(val.GetLength() <= 0) data.Format("%s(%01d)", itemType_buf[itemNo % MAX_ITEM_TYPE], count);
	else data.Format("%s(%01d) = %s", itemType_buf[itemNo % MAX_ITEM_TYPE], count, val);
	m_tree.SetItemText(hItem, data);
}




HTREEITEM CDialogSfEditMain::addOneDataTree(HTREEITEM hItem, SECS_REAL_DATA *list, int nIndex)
{
	CString	data;
	int		pos = getDataTypeToBufNo(list->nDataType);

	if(pos >= 0 && pos < MAX_ITEM_TYPE) data.Format("%s(%01d)", itemType_buf[pos % MAX_ITEM_TYPE], list->nDataCount);
	else data.Format("Unknown(%01d)", list->nDataCount);
	getReadvalueString(list, &data, true);
	return setOneDataTreeReal(hItem, data.GetBuffer(), nIndex);
}

void CDialogSfEditMain::makeSfMemoryDataTree(SECS_DATA *list, HTREEITEM hItem, int nIndex)
{
	int				i;
	HTREEITEM		hItemChild = NULL;

	if(list->nDataType == DATA_TYPE_LIST) {
		if(list->nList < 0) return;
		hItemChild = addOneListDataTree(hItem, list->nList, nIndex++);
		//nIndex++;
		for(i = 0; i < list->nList; i++) makeSfMemoryDataTree((SECS_DATA *)&list->list[i], hItemChild, nIndex);
	}
	else addOneDataTree(hItem, &list->realData, nIndex);
}

int CDialogSfEditMain::getListPosToFileNo()
{
	char		imsi[80];
	BYTE		cStream, cFunction;
	
	m_list.GetItemText(m_currPos, 1, imsi, sizeof(imsi));
	if(getStreamFunctionData(imsi, cStream, cFunction) == false) return -1;

	for(int i = 0; i < MAX_STREAM_FUNCTION_DATA; i++) {
		if(sfData[i].bExist == false) continue;
		if(sfData[i].cStream != cStream) continue;
		if(sfData[i].cFunction != cFunction) continue;		
		if(sfData[i].nFileNo != -1) return sfData[i].nFileNo;
	}
	return -1;
}

void CDialogSfEditMain::setSfDataToTree()
{
	m_tree.DeleteAllItems();
	m_bChangeCurrTree = false;

	m_nMemPos = getListPosToFileNo();
	if(m_nMemPos < 0 || m_nMemPos >= MAX_STREAM_FUNCTION_DATA) return;
	
	HTREEITEM		hItem = NULL;
	int				nIndex = 0;
		
	if(sfData[m_nMemPos].nDataType == DATA_TYPE_LIST) {
		if(sfData[m_nMemPos].nList > 0) hItem = addOneListDataTree(hItem, sfData[m_nMemPos].nList, nIndex++);
		for(int i = 0; i < sfData[m_nMemPos].nList; i++) makeSfMemoryDataTree(&sfData[m_nMemPos].list[i], hItem, nIndex);
	}
	else {
		addOneDataTree(hItem, &sfData[m_nMemPos].realData, nIndex);
	}
	setTreeExpandAndCheck();
}


void CDialogSfEditMain::getStreamFunctionFile2()
{
	int		i;

	nReadStreamFunction = 0;
	for(i = 0; i < MAX_STREAM_FUNCTION_DATA; i++) {
		sfData[i].bChange = false;
		sfData[i].nFileNo = -1;
		if(getStreamFunctionFileReal(&sfData[i], m_nPort, i)) nReadStreamFunction++;
	}
}


void CDialogSfEditMain::deleteSfMemoryOne2(int no)
{
	int			nList;

	if(no < 0 || no >= MAX_STREAM_FUNCTION_DATA || sfData[no].bExist == false) return;
	if(sfData[no].nDataType != DATA_TYPE_LIST) deleteSfMemoryStringBuf(&sfData[no].realData);
	for(nList = 0; nList < sfData[no].nList; nList++) deleteSfMemoryReal(&sfData[no].list[nList]);
	if(sfData[no].nList > 0) delete sfData[no].list;
	sfData[no].bExist = false;
}

void CDialogSfEditMain::deleteSfMemory2()
{
	for(int i = 0; i < MAX_STREAM_FUNCTION_DATA; i++) deleteSfMemoryOne2(i);
}



bool CDialogSfEditMain::getTreeAllDataValue(HTREEITEM	hItem, int &nDataType, int &nDataSize, CString &buf)
{
	if(hItem == NULL) return false;

	CString		data;
	data = m_tree.GetItemText(hItem);
	nDataType = getSecsDataType((char *)data.GetString());
	if(nDataType == DATA_UNKNOWN_TYPE) return false;
	nDataSize = getStringToItemCount(data);
	if(nDataType == DATA_TYPE_LIST) {
		if(nDataSize < 0) return false;
	}
	else {
		if(nDataSize <= 0) return false;
	}

	buf = "";
	if(getStringToDataValue(data, buf) == false) buf = "";
	return true;
}

void CDialogSfEditMain::getOneListDataFromTree(SECS_DATA *listData, HTREEITEM hItem, int &pos)
{
	int					i, nDataType, nDataSize;
	CString				buf;
	
	pos++;
	if(pos > 2000) return;		// changed 2016-08-26, 1000->2000
	if(getTreeAllDataValue(hItem, nDataType, nDataSize, buf) == false) return;
		
	listData->nList = 0;
	listData->nDataType = nDataType;
	if(nDataType == DATA_TYPE_LIST) {
		listData->nList = nDataSize;
		if(nDataSize > 0) {
			listData->list = (SECS_DATA *)calloc(nDataSize, sizeof(struct SECS_DATA));		
			hItem = m_tree.GetChildItem(hItem);
			for(i = 0; i < nDataSize; i++) {
				if(i == 0) getOneListDataFromTree((SECS_DATA *)&listData->list[i], hItem, pos);	
				else {
					hItem = m_tree.GetNextItem(hItem, TVGN_NEXT);
					getOneListDataFromTree((SECS_DATA *)&listData->list[i], hItem, pos);
				}
			}
		}		
	}
	else getOneRealSfDataWithoutHeader(&listData->realData, (char *)buf.GetString(), nDataType, nDataSize);
}


bool CDialogSfEditMain::getStreamFunctionTreeToMemory(int no)
{
	if(m_tree.GetCount() <= 0) {
		sfData[no].nList = 0;
		sfData[no].nDataType = DATA_TYPE_LIST;
		sfData[no].bExist = true;
		return true;
	}

	if(no < 0 || no >= MAX_STREAM_FUNCTION_DATA || sfData[no].bExist == true) return false;

	int					i, pos = 0, nDataType, nDataSize;
	HTREEITEM			hItem = NULL;
	CString				buf;	
	
	hItem = m_tree.GetRootItem();
	if(getTreeAllDataValue(hItem, nDataType, nDataSize, buf) == false) return false;
	
	sfData[no].nList = 0;
	sfData[no].nDataType = nDataType;
	if(nDataType == DATA_TYPE_LIST) {
		sfData[no].nList = nDataSize;
		if(nDataSize > 0) {
			sfData[no].list = (SECS_DATA *)calloc(nDataSize, sizeof(struct SECS_DATA));		
			hItem = m_tree.GetChildItem(hItem);
			if(hItem == NULL) return false;
			for(i = 0; i < nDataSize; i++) {
				if(i == 0) getOneListDataFromTree((SECS_DATA *)&sfData[no].list[i], hItem, pos);
				else {
					hItem = m_tree.GetNextItem(hItem, TVGN_NEXT);
					getOneListDataFromTree((SECS_DATA *)&sfData[no].list[i], hItem, pos);
				}
			}
		}
	}
	else getOneRealSfDataWithoutHeader(&sfData[no].realData, (char *)buf.GetString(), nDataType, nDataSize);
	sfData[no].bExist = true;
	return true;
}


int CDialogSfEditMain::GetSelectPosition()
{
	int		i;

	for(i = 0; i < m_list.GetItemCount(); i++) {
		if(m_list.GetItemState(i, LVIS_SELECTED)) {
			return i;
		}
	}

	return -1;
}

void CDialogSfEditMain::getCurrReadData(CDialogEditAddSfData &dialog)
{
	char					imsi[50];
	
	m_list.GetItemText(dialog.m_currPos, 1, imsi, sizeof(imsi));
	getStreamFunctionData(imsi, dialog.m_stream, dialog.m_function);
	//if(dialog.m_stream >= 1) dialog.m_stream--;
	//if(dialog.m_function >= 1) dialog.m_function--;
}

void CDialogSfEditMain::setOkReadData(CDialogEditAddSfData &dialog)
{
	CString					buf;	

	buf.Format("%1d.%1d", dialog.m_stream, dialog.m_function);
	m_list.SetItemText(dialog.m_currPos, 1, buf);
}

bool CDialogSfEditMain::checkEqualStreamFunction(BYTE stream, BYTE function)
{
	int		i;

	for(i = 0; i <= MAX_STREAM_FUNCTION_DATA; i++) {
		if(sfData[i].bExist == false) continue;
		if(sfData[i].cStream == stream && sfData[i].cFunction == function) return true;	
	}
	return false;
}

int CDialogSfEditMain::getValidSfMemory()
{
	for(int i = 0; i < MAX_STREAM_FUNCTION_DATA; i++) {
		if(sfData[i].bExist) continue;
		return i;
	}
	return -1;
}


void CDialogSfEditMain::OnBnClickedButtonEdit()
{
	// TODO: Add your control notification handler code here
	CDialogEditAddSfData		dialog;
	
	dialog.m_currPos = GetSelectPosition();
	if(dialog.m_currPos == -1) {
		MessageBox("Select One Stream/Function Data.", "Select Error");
		return;
	}
	if(m_nMemPos < 0 || m_nMemPos >= MAX_STREAM_FUNCTION_DATA) {
		MessageBox("Stream/Function Memory Selection Error.", "Memory Selection Error");
		return;
	}
	//if(dialog.m_currPos >= MAX_STREAM_FUNCTION_DATA) {
	//	MessageBox("Stream/Function Input Data Array Overflow.", "Array Overflow");
	//	return;
	//}
	getCurrReadData(dialog);

	char		imsi[50];
	BYTE		oldStream, oldFunction;
	m_list.GetItemText(dialog.m_currPos, 1, imsi, sizeof(imsi));
	getStreamFunctionData(imsi, oldStream, oldFunction);	

	int retn = (int)dialog.DoModal();
	if(retn == IDOK) {
		if(oldStream == dialog.m_stream && oldFunction == dialog.m_function) return;
		if(checkEqualStreamFunction(dialog.m_stream, dialog.m_function)) {
			MessageBox("EqualStream/Function Exist.", "Stream/unction Input Error");
			return;
		}
		setOkReadData(dialog);
		sfData[m_nMemPos % MAX_STREAM_FUNCTION_DATA].cStream = dialog.m_stream;
		sfData[m_nMemPos % MAX_STREAM_FUNCTION_DATA].cFunction = dialog.m_function;
		sfData[m_nMemPos].bChange = true;
	}
}

void CDialogSfEditMain::OnBnClickedButtonAdd()
{
	// TODO: Add your control notification handler code here
	CDialogEditAddSfData	dialog;

	if((m_list.GetItemCount() + 1) >= MAX_STREAM_FUNCTION_DATA) {
		MessageBox("Stream/Function Input Data Array Overflow.", "Array Overflow");
		return;
	}
	dialog.m_currPos = GetSelectPosition();	
	if(dialog.m_currPos == -1) {
		dialog.m_stream = 1;// stream = 1
		dialog.m_function = 2;// stream = 2
	}
	else {
		getCurrReadData(dialog);
	}
	dialog.m_currPos = m_list.GetItemCount();	

	int retn = (int)dialog.DoModal();
	if(retn == IDOK) {
		if(checkEqualStreamFunction(dialog.m_stream, dialog.m_function)) {
			MessageBox("EqualStream/Function Exist.", "Stream/unction Input Error");
			return;
		}
		char	imsi[20];

		sprintf(imsi, "%03d", dialog.m_currPos+1);
		m_list.InsertItem(dialog.m_currPos, imsi);
		setOkReadData(dialog);

		int	pos = getValidSfMemory();
		if(pos == -1) {
			MessageBox("Stream/Function Memory Full.", "Memory Error");
			return;
		}
		setDefaultSfData(&sfData[pos % MAX_STREAM_FUNCTION_DATA], pos, dialog.m_stream, dialog.m_function);
		if(m_list.GetItemCount() == 1) {
			m_currPos = 0;
			m_list.SetItemState(m_currPos, LVIS_SELECTED, LVIS_SELECTED);
			setSfDataToTree();
		}
		sfData[pos].bChange = true;
	}
}

void CDialogSfEditMain::OnBnClickedButtonDelete()
{
	// TODO: Add your control notification handler code here
	CDialogDeleteConfirm	dialog;
	CString					buf;
	
	dialog.m_currPos = GetSelectPosition();
	if(dialog.m_currPos == -1) {
		MessageBox("Select One Stream/Function Data.", "Selection Error");
		return;
	}
	if(m_nMemPos < 0 || m_nMemPos >= MAX_STREAM_FUNCTION_DATA) {
		MessageBox("Stream/Function Memory Selection Error.", "Memory Selection Error");
		return;
	}
		
	dialog.m_bMessageChange = true;
	dialog.MessageText.Format("Are Sure Sure Delete Selected Stream/Function ?");
	buf = m_list.GetItemText(dialog.m_currPos, 1);
	dialog.readSchBuf.Format("Stream.Function = %s", buf);
		
	int retn = (int)dialog.DoModal();
	if(retn == IDOK) {
		deleteSfMemoryOne2(m_nMemPos);
		sfData[m_nMemPos].bChange = true;
		m_list.DeleteItem(dialog.m_currPos);
		m_currPos = dialog.m_currPos;
		if(m_list.GetItemCount() <= 0) {
			m_tree.DeleteAllItems();
			m_currPos = -1;
		}
		else {
			if(m_currPos >= m_list.GetItemCount()) m_currPos = m_list.GetItemCount()-1;
			m_list.SetItemState(m_currPos, LVIS_SELECTED, LVIS_SELECTED);
			setSfDataToTree();
		}		
	}
}

void CDialogSfEditMain::OnNMClickListReadSchedule(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	int			oldPos = m_currPos;

	m_currPos = GetSelectPosition();
	if(oldPos == m_currPos) return;
	
	if(m_nMemPos >= 0 && m_nMemPos < MAX_STREAM_FUNCTION_DATA) {
		if(m_bChangeCurrTree) {
			deleteSfMemoryOne2(m_nMemPos);
			getStreamFunctionTreeToMemory(m_nMemPos);
			sfData[m_nMemPos].bChange = true;
		}
	}
	setSfDataToTree();
	EnableDisable();
	*pResult = 0;
}

void CDialogSfEditMain::OnNMDblclkListReadSchedule(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	OnBnClickedButtonEdit();
	*pResult = 0;
}

void CDialogSfEditMain::EnableDisable()
{
	if(m_itemNo == 0) {
		GetDlgItem(IDC_BUTTON_UPDATE_DATA)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_ADD_DATA)->EnableWindow(true);		
		GetDlgItem(IDC_COMBO_ITEM_TYPE)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_TAG_VALUE_ADD)->EnableWindow(false);
	}
	else {
		GetDlgItem(IDC_BUTTON_UPDATE_DATA)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_ADD_DATA)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_ITEM_VALUE)->EnableWindow(true);
		GetDlgItem(IDC_COMBO_ITEM_TYPE)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_TAG_VALUE_ADD)->EnableWindow(true);
	}
	if(m_tree.GetCount() <= 0) {
		GetDlgItem(IDC_COMBO_ITEM_TYPE)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_ADD_DATA)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_UPDATE_DATA)->EnableWindow(false);
	}

	if(m_itemNoAdd == 0) {
		GetDlgItem(IDC_EDIT_ITEM_VALUE)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_TAG_VALUE_ADD)->EnableWindow(false);
	}
	else {
		GetDlgItem(IDC_EDIT_ITEM_VALUE)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_TAG_VALUE_ADD)->EnableWindow(true);
	}
}

void CDialogSfEditMain::OnTvnSelchangedTreeSfEdit(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	// TODO: Add your control notification handler code here
	HTREEITEM		hItem = pNMTreeView->itemNew.hItem;
	CString			val, cText = m_tree.GetItemText(hItem);
	int				count;
	
	m_itemNo = getSecsDataTypeNo((char *)cText.GetString());
	m_itemNoAdd = m_itemNo;
	m_itemType.SetCurSel(m_itemNo%MAX_ITEM_TYPE);
	m_comboItemAdd.SetCurSel(m_itemNoAdd%MAX_ITEM_TYPE);
	count = getStringToItemCount(cText);
	if(count >= 0) m_itemCount.Format("%1d", count);
	else m_itemCount.Format("");
	if(getStringToDataValue(cText, val)) m_itemValue.Format("%s", val);
	else m_itemValue.Format("");	
	UpdateData(false);
	EnableDisable();
	*pResult = 0;
}

HTREEITEM CDialogSfEditMain::GetSelectPositionTree()
{
	return m_tree.GetSelectedItem();	
}


void CDialogSfEditMain::OnBnClickedButtonAddData()
{
	// TODO: Add your control notification handler code here
	HTREEITEM				hItem = NULL;
	int						pos, count = m_tree.GetCount();

	pos = GetSelectPosition();
	if(pos == -1) {
		MessageBox("Please Select One Stream/Function Data.", "Selection Error");
		return;
	}

	m_itemNo = m_itemType.GetCurSel();
	m_itemNoAdd = m_comboItemAdd.GetCurSel();
	if(count != 0) {
		hItem = GetSelectPositionTree();
		if(hItem == NULL) {
			MessageBox("Select One Item Data.", "Selection Error");
			return;
		}
		if(m_itemNoAdd == 0) {
			addOneListDataTree(hItem, 0, 1);
			updateListDataTreeCount(hItem, 1);
		}
		else {
			UpdateData(true);
			if(addOneRealDataTree(hItem, m_itemNoAdd, m_itemValue, 1) != NULL) updateListDataTreeCount(hItem, 1);
		}		
	}
	else {
		if(m_itemNoAdd == 0) hItem = addOneListDataTree(hItem, 0, 0);
		else {
			UpdateData(true);
			hItem = addOneRealDataTree(hItem, m_itemNoAdd, m_itemValue, 0);
		}
	}
	setTreeExpandAndCheckCurr();
	if(m_tree.GetSelectedItem() == NULL) m_tree.SelectItem(hItem);
	m_bChangeCurrTree = true;
}

void CDialogSfEditMain::OnBnClickedButtonDeleteData()
{
	// TODO: Add your control notification handler code here	
	HTREEITEM		hItem = GetSelectPositionTree();
	if(hItem == NULL) {
		MessageBox("Select One Item Data.", "Selection Error");
		return;
	}

	/*CDialogDeleteConfirm	dialog;
	CString					buf = m_tree.GetItemText(hItem);
		
	dialog.m_bMessageChange = true;
	dialog.MessageText.Format("Are Sure Sure Delete Selected Item Data ?");
	dialog.readSchBuf.Format("Item Data = %s", buf);
		
	int retn = (int)dialog.DoModal();
	if(retn == IDOK) {
		HTREEITEM		hItemParent = m_tree.GetParentItem(hItem);
		if(hItemParent != NULL) updateListDataTreeCount(hItemParent, -1);*/
		HTREEITEM		hItemParent = m_tree.GetParentItem(hItem);
		m_tree.DeleteItem(hItem);
		updateListDataTreeCount(hItemParent, -1);
	//}
	EnableDisable();
	m_bChangeCurrTree = true;
}

void CDialogSfEditMain::OnBnClickedButtonUpdateData()
{
	// TODO: Add your control notification handler code here
	HTREEITEM		hItem = GetSelectPositionTree();
	if(hItem == NULL) {
		MessageBox("Select One Item Data.", "Selection Error");
		return;
	}

	UpdateData(true);
	if(m_itemValue.GetLength() <= 0) {
		MessageBox("Please Input Item Value.", "Item Value Input Error");
		return;
	}

	CString					buf = m_tree.GetItemText(hItem);
	if(m_itemValue == buf) return;
	updateListDataTreeRealData(hItem, m_itemValue);	
	m_bChangeCurrTree = true;
}


void CDialogSfEditMain::OnCbnSelchangeComboItemType()
{
	// TODO: Add your control notification handler code here
	m_itemNoAdd = m_comboItemAdd.GetCurSel();
	UpdateData(true);
	EnableDisable();
}


void CDialogSfEditMain::GetCurrentTag(int no)
{
	TagPublicStruct		*tp;
	char				buf[81];
	DWORD				i, pos = 0, tagType = TAG_TYPE_AI;
	
	if(no == nRadioSelection) return;
	nRadioSelection = no;

	if(nRadioSelection == 1) tagType = TAG_TYPE_AO;
	else if(nRadioSelection == 2) tagType = TAG_TYPE_DI;
	else if(nRadioSelection == 3) tagType = TAG_TYPE_DO;
	else if(nRadioSelection == 4) tagType = TAG_TYPE_ST;
	else tagType = TAG_TYPE_AI;

	m_tagList.DeleteAllItems();
	for(i = 0; i < blockTagList9.GetCount(); i++) {
		tp = (TagPublicStruct*)blockTagList9.GetPtr(i);
		if(tp->nTagType == tagType) {
			sprintf(buf, "%05d", pos);
			m_tagList.InsertItem(pos, buf);
			m_tagList.SetItemText(pos, 1, tp->tag);
			m_tagList.SetItemText(pos, 2, tp->description);
			pos++;			
		}
	}
}

DWORD CDialogSfEditMain::SearchTagNamePos()
{
	if(m_tagName.IsEmpty()) return 0;

	TagPublicStruct		*tp;
	DWORD				i, pos = 0;
	
	for(i = 0; i < blockTagList9.GetCount(); i++) {
		tp = (TagPublicStruct*)blockTagList9.GetPtr(i);
		if(tp->nTagType == TAG_TYPE_AI) {
			if(m_tagName == tp->tag) return pos;
			pos++;
		}
	}
	return 0;
}

int CDialogSfEditMain::GetSelectPositionTag()
{
	int		i;

	for(i = 0; i < m_tagList.GetItemCount(); i++) {
		if(m_tagList.GetItemState(i, LVIS_SELECTED)) {
			return i;
		}
	}

	return -1;
}


void CDialogSfEditMain::OnBnClickedRadioAnalogInput()
{
	// TODO: Add your control notification handler code here
	GetCurrentTag(0);
}


void CDialogSfEditMain::OnBnClickedRadioAnalogOutput()
{
	// TODO: Add your control notification handler code here
	GetCurrentTag(1);
}

void CDialogSfEditMain::OnBnClickedRadioDigitalInput()
{
	// TODO: Add your control notification handler code here
	GetCurrentTag(2);
}

void CDialogSfEditMain::OnBnClickedRadioDigitalOutput()
{
	// TODO: Add your control notification handler code here
	GetCurrentTag(3);
}

void CDialogSfEditMain::OnBnClickedRadioTagString()
{
	// TODO: Add your control notification handler code here
	GetCurrentTag(4);
}



void CDialogSfEditMain::OnBnClickedButtonTagValueAdd()
{
	// TODO: Add your control notification handler code here
	int pos = GetSelectPositionTag();
	if(pos == -1) return;
	m_itemNo = m_itemType.GetCurSel();
	m_itemNoAdd = m_comboItemAdd.GetCurSel();
	if(m_itemNo == MAX_ITEM_TYPE) return;
	if(m_itemNoAdd == 0 || m_itemNoAdd == MAX_ITEM_TYPE) return;

	//HTREEITEM		hItem = GetSelectPositionTree();
	//if(hItem == NULL) {
	//	MessageBox("Select One Item Data.", "Selection Error");
	//	return;
	//}
	//CString		data = m_tree.GetItemText(hItem);
	CString		buf = m_tagList.GetItemText(pos, 1);
	//if(data.GetLength() <= 0 || 
		if(buf.GetLength() <= 0) return;
	
	if(isAsciiData(getSecsDataNoToDataType(m_itemNoAdd))) m_itemValue.Format("\\$%s", buf);
	else {
		UpdateData(true);
		if(m_itemValue.GetLength() <= 0) m_itemValue.Format("\\$%s", buf);
		else m_itemValue.AppendFormat(", \\$%s", buf);
	}
	if(m_itemNo == m_itemNoAdd) {
		HTREEITEM		hItem = GetSelectPositionTree();
		if(hItem != NULL) {
			CString		data = m_tree.GetItemText(hItem);
			updateListDataTreeRealData(hItem, m_itemValue);
			m_bChangeCurrTree = true;
		}
	}
	UpdateData(false);
}

void CDialogSfEditMain::OnNMDblclkListTag(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	OnBnClickedButtonTagValueAdd();
	*pResult = 0;
}

