// DialogItemEdit.cpp : implementation file
//

#include "stdafx.h"
#include "SECS_Host.h"
#include "SECS_HostDef.h"
#include "DialogItemEdit.h"
#include "..\..\catlib\CatTag9.h"
#include "..\..\catlib\CatTag.h"


// CDialogItemEdit dialog

IMPLEMENT_DYNAMIC(CDialogItemEdit, CDialog)
CDialogItemEdit::CDialogItemEdit(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogItemEdit::IDD, pParent)
	, m_allValue(_T(""))
	, m_CurrValue(_T(""))
{
}

CDialogItemEdit::~CDialogItemEdit()
{
}

void CDialogItemEdit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_ITEM_TYPE, m_itemType);
	DDX_Control(pDX, IDC_LIST_TAG, m_list);
	DDX_Text(pDX, IDC_EDIT_ITEM_TOTAL_VALUE, m_allValue);
	DDX_Text(pDX, IDC_EDIT_ITEM_CURR_VALUE, m_CurrValue);
}


BEGIN_MESSAGE_MAP(CDialogItemEdit, CDialog)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_TAG, OnNMDblclkListTag)
	ON_BN_CLICKED(IDC_RADIO_ANALOG_INPUT, OnBnClickedRadioAi)
	ON_BN_CLICKED(IDC_RADIO_ANALOG_OUTPUT, OnBnClickedRadioAo)
	ON_BN_CLICKED(IDC_RADIO_DIGITAL_INPUT, OnBnClickedRadioDi)
	ON_BN_CLICKED(IDC_RADIO_DIGITAL_OUTPUT, OnBnClickedRadioDo)
	ON_BN_CLICKED(IDC_RADIO_STRING_TAG, OnBnClickedRadioSt)
	ON_CBN_SELCHANGE(IDC_COMBO_ITEM_TYPE, OnCbnSelchangeComboItemType)
	ON_BN_CLICKED(IDC_BUTTON_ADD_DATA, OnBnClickedButtonAddData)
	ON_BN_CLICKED(IDC_BUTTON_DELETE_DATA, OnBnClickedButtonDeleteData)
	ON_BN_CLICKED(IDC_BUTTON_TAG_ADD, OnBnClickedButtonTagAdd)
END_MESSAGE_MAP()


// CDialogItemEdit message handlers


void CDialogItemEdit::GetCurrentTag()
{
	TagPublicStruct		*tp;
	char				buf[81];
	DWORD				i, pos = 0, tagType = TAG_TYPE_AI;
	
	if(nRadioSelection == 1) tagType = TAG_TYPE_AO;
	else if(nRadioSelection == 2) tagType = TAG_TYPE_DI;
	else if(nRadioSelection == 3) tagType = TAG_TYPE_DO;
	else if(nRadioSelection == 4) tagType = TAG_TYPE_ST;
	else tagType = TAG_TYPE_AI;

	for(i = 0; i < blockTagList9.GetCount(); i++) {
		tp = (TagPublicStruct*)blockTagList9.GetPtr(i);
		if(tp->nTagType == tagType) {
			sprintf(buf, "%05d", pos);
			m_list.InsertItem(pos, buf);
			m_list.SetItemText(pos, 1, tp->tag);
			m_list.SetItemText(pos, 2, tp->description);
			pos++;			
		}
	}
}

DWORD CDialogItemEdit::SearchTagNamePos()
{
	if(m_tagName.IsEmpty()) return 0;

	TagPublicStruct		*tp;
	DWORD				i, pos = 0;
	
	for(i = 0; i < blockTagList9.GetCount(); i++) {
		tp = (TagPublicStruct*)blockTagList9.GetPtr(i);
		if(tp->nTagType == TAG_TYPE_AI) {
			if(m_tagName == tp->tag) return pos;
			pos++;
		}
	}
	return 0;
}

int CDialogItemEdit::GetSelectPosition()
{
	int		i;

	for(i = 0; i < m_list.GetItemCount(); i++) {
		if(m_list.GetItemState(i, LVIS_SELECTED)) {
			return i;
		}
	}

	return -1;
}

BOOL CDialogItemEdit::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	m_itemNewNo = 0;
	if(m_itemNo == 0) {
		for(int i = 0; i < MAX_ITEM_TYPE; i++) m_itemType.AddString(itemType_buf[i]);
	}
	else {
		m_itemType.AddString(itemType_buf[m_itemNo]);
	}
	m_itemType.SetCurSel(0);

	m_list.InsertColumn(0, "No.", LVCFMT_CENTER, 60);
	m_list.InsertColumn(1, "Tag Name", LVCFMT_LEFT, 180);
	m_list.InsertColumn(2, "Tag Description", LVCFMT_LEFT, 180);	
	nRadioSelection = 0;
	GetCurrentTag();
	
	//tagPos = SearchTagNamePos();
	m_list.SetItemState(tagPos, LVIS_SELECTED, LVIS_SELECTED);
	m_list.EnsureVisible(tagPos, false);
	CheckRadioButton(IDC_RADIO_ANALOG_INPUT, IDC_RADIO_STRING_TAG, IDC_RADIO_ANALOG_INPUT);
	EnableDisable();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDialogItemEdit::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class

	CDialog::OnOK();
}

void CDialogItemEdit::OnNMDblclkListTag(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	OnBnClickedButtonTagAdd();
	*pResult = 0;
}

void CDialogItemEdit::OnBnClickedRadioAi()
{
	// TODO: Add your control notification handler code here
	if(nRadioSelection == 0) return;
	nRadioSelection = 0;
	m_list.DeleteAllItems();
	GetCurrentTag();
}

void CDialogItemEdit::OnBnClickedRadioAo()
{
	// TODO: Add your control notification handler code here
	if(nRadioSelection == 1) return;
	nRadioSelection = 1;
	m_list.DeleteAllItems();
	GetCurrentTag();
}

void CDialogItemEdit::OnBnClickedRadioDi()
{
	// TODO: Add your control notification handler code here
	if(nRadioSelection == 2) return;
	nRadioSelection = 2;
	m_list.DeleteAllItems();
	GetCurrentTag();
}

void CDialogItemEdit::OnBnClickedRadioDo()
{
	// TODO: Add your control notification handler code here
	if(nRadioSelection == 3) return;
	nRadioSelection = 3;
	m_list.DeleteAllItems();
	GetCurrentTag();
}

void CDialogItemEdit::OnBnClickedRadioSt()
{
	// TODO: Add your control notification handler code here
	if(nRadioSelection == 4) return;
	nRadioSelection = 4;
	m_list.DeleteAllItems();
	GetCurrentTag();
}

void CDialogItemEdit::EnableDisable()
{	
	bool		flag = (m_itemNo == 0 && m_itemNewNo == 0) ? false : true;

	GetDlgItem(IDC_EDIT_ITEM_COUNT)->EnableWindow(flag);
	GetDlgItem(IDC_SPIN_ADD_EDIT_POS)->EnableWindow(flag);
	GetDlgItem(IDC_EDIT_ITEM_CURR_VALUE)->EnableWindow(flag);
}
void CDialogItemEdit::OnCbnSelchangeComboItemType()
{
	// TODO: Add your control notification handler code here
	m_itemNewNo = m_itemType.GetCurSel();
	EnableDisable();
}

void CDialogItemEdit::OnBnClickedButtonAddData()
{
	// TODO: Add your control notification handler code here
}

void CDialogItemEdit::OnBnClickedButtonDeleteData()
{
	// TODO: Add your control notification handler code here
}

void CDialogItemEdit::OnBnClickedButtonTagAdd()
{
	// TODO: Add your control notification handler code here
	int pos = GetSelectPosition();
	if(pos == -1) return;

	CString buf = m_list.GetItemText(pos, 1);
	m_CurrValue.Format("$%s", buf);
	UpdateData(false);
}
