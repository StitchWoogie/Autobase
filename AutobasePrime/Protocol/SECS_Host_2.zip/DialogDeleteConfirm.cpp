// DialogDeleteConfirm.cpp : implementation file
//

#include "stdafx.h"
#include "SECS_Host.h"
#include "DialogDeleteConfirm.h"


// CDialogDeleteConfirm dialog

IMPLEMENT_DYNAMIC(CDialogDeleteConfirm, CDialog)
CDialogDeleteConfirm::CDialogDeleteConfirm(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogDeleteConfirm::IDD, pParent)
{
}

CDialogDeleteConfirm::~CDialogDeleteConfirm()
{
}

void CDialogDeleteConfirm::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TEXT_READ_SCHEDULE, m_text);
	DDX_Control(pDX, IDC_TEXT_DELETE_CONFIRM, m_textMessage);
}


BEGIN_MESSAGE_MAP(CDialogDeleteConfirm, CDialog)
END_MESSAGE_MAP()


// CDialogDeleteConfirm message handlers

BOOL CDialogDeleteConfirm::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	if(m_bMessageChange) {
		SetWindowText("Stream/Function Delete Confirm");
		m_textMessage.SetWindowText(MessageText);
	}
	m_text.SetWindowText(readSchBuf);
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
