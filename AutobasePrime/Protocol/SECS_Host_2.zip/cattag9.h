// TAG size O.K
#if	!defined (__CATTAG9_H)
#define __CATTAG9_H

#if	!defined (__COMPILER_HPP)
#include <compiler.hpp>
#endif

#if	!defined (__TOOLS_H)
#include <tools.h>
#endif

typedef struct {
	int		nTagType;
	char	tag[80];			// changeded 2016-09-22, 40 -> 80
	char	description[80];
} TagPublicStruct;

extern Block blockTagList9;

void TagLoad9();

#endif




